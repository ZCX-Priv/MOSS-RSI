/**
 * Fixed registry of official model CLI tools, shared by the Host runtime
 * (probe + install + uninstall + repair) and the Desktop panel (display).
 * Pure data: no Node or browser APIs, so both sides and the test suite import
 * it unchanged.
 *
 * The registry is fail-closed by design: installer sources are fixed (the
 * official npm registry, the vendor's published installer script) and clients
 * can only name a registry id and one of that tool's declared install methods
 * — never an arbitrary package, URL or command. Versions are not pinned:
 * installs take each vendor's latest release (`@latest`, the vendor script's
 * own `latest`), and the executor trusts entries by publisher signature or
 * registry-attested digest rather than by version.
 *
 * Every tool declares `installMethods`: the complete, closed list of ways this
 * plugin may obtain the tool. `manager` / `installArgs` / `uninstallArgs` on the
 * tool itself stay the default (first) method, so existing callers and tests
 * keep working. Script methods are never piped straight into an interpreter:
 * the runtime downloads the vendor script, checks it still is that script, and
 * runs the staged copy (same pattern as the MiniMax Windows installer).
 */

/** npm registry every fixed npm method installs from unless the user overrides it. */
export const DEFAULT_NPM_REGISTRY = 'https://registry.npmjs.org/'

/** Shared shape of a "package manager" method: argv only, no script staging. */
function packageManagerMethod(id, label, manager, spec, { registryFlag = '--registry=', command = 'install', extraArgs = [] } = {}) {
  return Object.freeze({
    id,
    label,
    kind: 'package-manager',
    manager,
    spec,
    registryFlag,
    installArgs: Object.freeze([command, '-g', spec, ...extraArgs]),
    uninstallArgs: Object.freeze(['uninstall', '-g', spec.replace(/@latest$/, '')]),
    /** The resolver binds npm prefix or pnpm global-dir/global-bin-dir. */
    supportsInstallDir: true,
    supportsRegistry: true,
  })
}

/** Vendor installer script run from a verified local copy. */
function scriptMethod(id, label, {
  shell, scriptUrl, verify, installArg = [], env = [], platforms,
  supportsInstallDir = false, installDirEnv = '', installDirSuffix = '',
  defaultScriptInstallDir, defaultScriptInstallDirEnv, scriptBinaryNames,
  registryEnv, installDirSubdir, legacySharedInstallDir = false, sharedDefaultBin = false, uninstallUnsupportedReason, scriptFallbackUrls, extraArgs = [],
}) {
  return Object.freeze({
    id,
    label,
    kind: 'script',
    shell,
    scriptUrl,
    verify,
    /** Passed after the staged script path; empty means the script takes no argument. */
    installArgs: Object.freeze(installArg),
    /** Environment the vendor script itself documents for this install. */
    env: Object.freeze(env),
    platforms: Object.freeze(platforms),
    /** Whether the vendor script honours a caller-chosen directory at all. */
    supportsInstallDir,
    installDirEnv,
    installDirSuffix,
    ...(installDirSubdir ? { installDirSubdir } : {}),
    ...(legacySharedInstallDir ? { legacySharedInstallDir: true } : {}),
    ...(sharedDefaultBin ? { sharedDefaultBin: true } : {}),
    ...(uninstallUnsupportedReason ? { uninstallUnsupportedReason } : {}),
    ...(defaultScriptInstallDir ? { defaultScriptInstallDir } : {}),
    ...(defaultScriptInstallDirEnv ? { defaultScriptInstallDirEnv } : {}),
    ...(scriptBinaryNames ? { scriptBinaryNames: Object.freeze(scriptBinaryNames) } : {}),
    ...(scriptFallbackUrls ? { scriptFallbackUrls: Object.freeze(scriptFallbackUrls) } : {}),
    ...(registryEnv ? { registryEnv } : {}),
    ...(extraArgs.length ? { extraArgs: Object.freeze(extraArgs) } : {}),
    supportsRegistry: Boolean(registryEnv),
  })
}

export const OFFICIAL_TOOLS = Object.freeze([
  Object.freeze({
    id: 'kimi-code',
    label: 'Kimi Code · Node',
    vendor: 'Moonshot AI',
    purpose: 'Kimi 官方编程 CLI，提供 kimi 命令与 ACP 会话。',
    package: '@moonshot-ai/kimi-code',
    manager: 'npm',
    installArgs: ['install', '-g', '@moonshot-ai/kimi-code@latest', '--registry=https://registry.npmjs.org/'],
    uninstallArgs: ['uninstall', '-g', '@moonshot-ai/kimi-code'],
    probeExecutables: ['kimi'],
    probeNote: 'kimi 与旧 Python 版 kimi-cli 同名；请核对可执行文件来源和版本。',
    providerHints: ['moonshot', 'kimi'],
    scriptBinaryNames: Object.freeze(['kimi', 'kimi.exe']),
    defaultScriptInstallDir: '.kimi-code/bin',
    installMethods: Object.freeze([
      packageManagerMethod('npm', 'npm', 'npm', '@moonshot-ai/kimi-code@latest'),
      packageManagerMethod('pnpm', 'pnpm', 'pnpm', '@moonshot-ai/kimi-code@latest'),
      scriptMethod('script-bash', 'curl | bash', {
        shell: 'bash', scriptUrl: 'https://code.kimi.com/kimi-code/install.sh',
        platforms: ['linux', 'darwin'], supportsInstallDir: true,
        installDirEnv: 'KIMI_INSTALL_DIR', installDirSuffix: 'bin',
        installDirSubdir: 'kimi-code', legacySharedInstallDir: true,
        env: ['KIMI_INSTALL_DIR'],
        scriptBinaryNames: ['kimi'],
        verify: Object.freeze({ mustInclude: ['kimi-code', 'code.kimi.com/kimi-code'] }),
      }),
      scriptMethod('script-powershell', 'irm | iex', {
        shell: 'powershell', scriptUrl: 'https://code.kimi.com/kimi-code/install.ps1',
        platforms: ['win32'], supportsInstallDir: true,
        installDirEnv: 'KIMI_INSTALL_DIR', installDirSuffix: 'bin',
        installDirSubdir: 'kimi-code', legacySharedInstallDir: true,
        env: ['KIMI_INSTALL_DIR'],
        scriptBinaryNames: ['kimi.exe'],
        verify: Object.freeze({ mustInclude: ['kimi-code', 'code.kimi.com/kimi-code'] }),
      }),
    ]),
  }),
  Object.freeze({
    id: 'claude-code',
    label: 'Claude Code',
    vendor: 'Anthropic',
    purpose: 'Anthropic 官方编程 CLI，提供 claude 命令。',
    package: '@anthropic-ai/claude-code',
    manager: 'npm',
    installArgs: ['install', '-g', '@anthropic-ai/claude-code@latest', '--registry=https://registry.npmjs.org/'],
    uninstallArgs: ['uninstall', '-g', '@anthropic-ai/claude-code'],
    probeExecutables: ['claude'],
    providerHints: ['anthropic', 'claude'],
    scriptBinaryNames: Object.freeze(['claude', 'claude.exe']),
    defaultScriptInstallDir: '.local/bin',
    installMethods: Object.freeze([
      packageManagerMethod('npm', 'npm', 'npm', '@anthropic-ai/claude-code@latest'),
      packageManagerMethod('pnpm', 'pnpm', 'pnpm', '@anthropic-ai/claude-code@latest', {
        command: 'add',
        extraArgs: ['--ignore-scripts=false', '--allow-build=@anthropic-ai/claude-code'],
      }),
      // The native installer has no directory argument. npm/pnpm support a prefix.
      scriptMethod('script-bash', 'curl | bash', {
        shell: 'bash', scriptUrl: 'https://claude.ai/install.sh',
        scriptFallbackUrls: ['https://downloads.claude.ai/claude-code-releases/bootstrap.sh'],
        platforms: ['linux', 'darwin'],
        scriptBinaryNames: ['claude'],
        sharedDefaultBin: true,
        verify: Object.freeze({ mustInclude: ['downloads.claude.ai/claude-code-releases', 'manifest.json'] }),
      }),
      scriptMethod('script-powershell', 'irm | iex', {
        shell: 'powershell', scriptUrl: 'https://claude.ai/install.ps1',
        scriptFallbackUrls: ['https://downloads.claude.ai/claude-code-releases/bootstrap.ps1'],
        platforms: ['win32'],
        scriptBinaryNames: ['claude.exe'],
        sharedDefaultBin: true,
        verify: Object.freeze({ mustInclude: ['downloads.claude.ai/claude-code-releases', 'manifest.json'] }),
      }),
    ]),
  }),
  Object.freeze({
    id: 'codex',
    label: 'Codex CLI',
    vendor: 'OpenAI',
    purpose: 'OpenAI 官方编程 CLI，提供 codex 命令。',
    package: '@openai/codex',
    manager: 'npm',
    installArgs: ['install', '-g', '@openai/codex@latest', '--registry=https://registry.npmjs.org/'],
    uninstallArgs: ['uninstall', '-g', '@openai/codex'],
    probeExecutables: ['codex'],
    probeNote: 'Codex 版本横幅由适配层宽匹配；安装时取 npm 最新版。',
    // The unified task service registers this CLI as an explicit task backend (cli/codex).
    taskBackend: true,
    providerHints: ['openai', 'gpt', 'codex'],
    scriptBinaryNames: Object.freeze(['codex', 'codex.exe']),
    defaultScriptInstallDir: '.local/bin',
    installMethods: Object.freeze([
      packageManagerMethod('npm', 'npm', 'npm', '@openai/codex@latest'),
      packageManagerMethod('pnpm', 'pnpm', 'pnpm', '@openai/codex@latest'),
      scriptMethod('script-sh', 'curl | sh', {
        shell: 'sh', scriptUrl: 'https://chatgpt.com/codex/install.sh',
        platforms: ['linux', 'darwin'], supportsInstallDir: true,
        installDirEnv: 'CODEX_INSTALL_DIR', env: ['CODEX_INSTALL_DIR'],
        installDirSubdir: 'codex/bin', legacySharedInstallDir: true,
        sharedDefaultBin: true,
        scriptBinaryNames: ['codex'],
        verify: Object.freeze({ mustInclude: ['releases.openai.com/codex', 'CODEX_INSTALL_DIR'] }),
      }),
      scriptMethod('script-powershell', 'irm | iex', {
        shell: 'powershell', scriptUrl: 'https://chatgpt.com/codex/install.ps1',
        platforms: ['win32'], supportsInstallDir: true,
        installDirEnv: 'CODEX_INSTALL_DIR', env: ['CODEX_INSTALL_DIR'],
        defaultScriptInstallDirEnv: 'LOCALAPPDATA',
        defaultScriptInstallDir: 'Programs/OpenAI/Codex/bin',
        installDirSubdir: 'codex/bin',
        uninstallUnsupportedReason: 'Codex 官方 Windows 脚本使用目录联接和版本化资源；请按官方卸载说明移除，插件不会删除联接目标。',
        // The Windows bin directory is a junction to the versioned payload.
        scriptBinaryNames: ['codex.exe'],
        verify: Object.freeze({ mustInclude: ['releases.openai.com/codex', 'CODEX_INSTALL_DIR'] }),
      }),
    ]),
  }),
  Object.freeze({
    id: 'minimax-code',
    label: 'MiniMax Code',
    vendor: 'MiniMax',
    purpose: 'MiniMax 官方编程 CLI，提供 mcode 命令。',
    package: '@minimax-ai/code',
    manager: 'npm',
    installArgs: ['install', '-g', '@minimax-ai/code@latest', '--registry=https://registry.npmjs.org/', '--ignore-scripts=false', '--include=optional', '--allow-scripts=@minimax-ai/code,better-sqlite3'],
    uninstallArgs: ['uninstall', '-g', '@minimax-ai/code'],
    probeExecutables: ['mcode'],
    providerHints: ['minimax'],
    defaultMethodsByPlatform: Object.freeze({ win32: 'script-powershell' }),
    scriptBinaryNames: Object.freeze(['mcode', 'mcode-tools']),
    defaultScriptInstallDir: '.minimax-code/bin',
    installMethods: Object.freeze([
      packageManagerMethod('npm', 'npm', 'npm', '@minimax-ai/code@latest', {
        extraArgs: ['--ignore-scripts=false', '--include=optional', '--allow-scripts=@minimax-ai/code,better-sqlite3'],
      }),
      packageManagerMethod('pnpm', 'pnpm', 'pnpm', '@minimax-ai/code@latest', {
        command: 'add',
        extraArgs: ['--ignore-scripts=false', '--allow-build=@minimax-ai/code', '--allow-build=better-sqlite3'],
      }),
      scriptMethod('script-bash', 'curl | bash', {
        shell: 'bash', scriptUrl: 'https://filecdn.minimax.chat/public/install.sh',
        platforms: ['linux', 'darwin'], supportsInstallDir: true,
        installDirEnv: 'MCODE_INSTALL_DIR', installDirSuffix: 'bin',
        installDirSubdir: 'minimax-code', legacySharedInstallDir: true,
        registryEnv: 'MCODE_NPM_REGISTRY', env: ['MCODE_INSTALL_DIR', 'MCODE_NPM_REGISTRY'],
        verify: Object.freeze({ mustInclude: ['MiniMax Code CLI', '@minimax-ai/code'] }),
      }),
      scriptMethod('script-powershell', 'irm | iex', {
        shell: 'powershell', scriptUrl: 'https://filecdn.minimax.chat/public/install.ps1',
        platforms: ['win32'], supportsInstallDir: true,
        installDirEnv: 'MCODE_INSTALL_DIR',
        installDirSubdir: 'minimax-code', legacySharedInstallDir: true,
        registryEnv: 'MCODE_NPM_REGISTRY', env: ['MCODE_INSTALL_DIR', 'MCODE_NPM_REGISTRY'],
        defaultScriptInstallDir: '.minimax-code',
        scriptBinaryNames: ['mcode.cmd', 'mcode.ps1', 'mcode-tools.cmd', 'mcode-tools.ps1'],
        verify: Object.freeze({ mustInclude: ['MiniMax Code CLI', '@minimax-ai/code'] }),
      }),
    ]),
  }),
  Object.freeze({
    id: 'mimo-code',
    label: 'MiMo Code',
    vendor: 'XiaoMi',
    purpose: '小米 MiMo 官方编程 CLI，提供 mimo 命令。',
    package: '@mimo-ai/cli',
    manager: 'npm',
    installArgs: ['install', '-g', '@mimo-ai/cli@latest', '--registry=https://registry.npmjs.org/'],
    uninstallArgs: ['uninstall', '-g', '@mimo-ai/cli'],
    probeExecutables: ['mimo'],
    providerHints: ['mimo', 'xiaomi'],
    scriptBinaryNames: Object.freeze(['mimo', 'mimo.exe']),
    defaultScriptInstallDir: '.mimocode/bin',
    installMethods: Object.freeze([
      packageManagerMethod('npm', 'npm', 'npm', '@mimo-ai/cli@latest'),
      packageManagerMethod('pnpm', 'pnpm', 'pnpm', '@mimo-ai/cli@latest'),
      scriptMethod('script-bash', 'curl | bash', {
        shell: 'bash', scriptUrl: 'https://mimo.xiaomi.com/install',
        platforms: ['linux', 'darwin'],
        scriptBinaryNames: ['mimo'],
        verify: Object.freeze({ mustInclude: ['mimo.xiaomi.com', '.mimocode'] }),
      }),
      scriptMethod('script-powershell', 'irm | iex', {
        shell: 'powershell', scriptUrl: 'https://mimo.xiaomi.com/install.ps1',
        platforms: ['win32'], supportsInstallDir: true,
        installDirEnv: 'MIMOCODE_INSTALL_DIR', env: ['MIMOCODE_INSTALL_DIR'],
        installDirSubdir: 'mimo-code', legacySharedInstallDir: true,
        scriptBinaryNames: ['mimo.exe'],
        verify: Object.freeze({ mustInclude: ['mimo.xiaomi.com', '.mimocode'] }),
      }),
    ]),
  }),
  Object.freeze({
    id: 'grok-build',
    label: 'Grok Build',
    vendor: 'xAI',
    purpose: 'xAI 官方编程 CLI，提供 grok 命令与 ACP 会话。',
    package: '@xai-official/grok',
    manager: 'npm',
    installArgs: ['install', '-g', '@xai-official/grok@latest', '--registry=https://registry.npmjs.org/'],
    uninstallArgs: ['uninstall', '-g', '@xai-official/grok'],
    probeExecutables: ['grok'],
    providerHints: ['xai', 'grok'],
    scriptBinaryNames: Object.freeze(['grok', 'agent', 'grok.exe', 'agent.exe', 'grove.exe', 'grove-fsmonitor.exe', 'grove-credential.exe']),
    defaultScriptInstallDir: '.grok/bin',
    pathProfileMarkers: Object.freeze(['# >>> grok installer >>>', '# <<< grok installer <<<']),
    installMethods: Object.freeze([
      packageManagerMethod('npm', 'npm', 'npm', '@xai-official/grok@latest'),
      packageManagerMethod('pnpm', 'pnpm', 'pnpm', '@xai-official/grok@latest'),
      scriptMethod('script-bash', 'curl | bash', {
        shell: 'bash', scriptUrl: 'https://x.ai/cli/install.sh',
        platforms: ['linux', 'darwin'], supportsInstallDir: true,
        installDirEnv: 'GROK_BIN_DIR', env: ['GROK_BIN_DIR'],
        installDirSubdir: 'grok-build', legacySharedInstallDir: true,
        scriptBinaryNames: ['grok', 'agent'],
        verify: Object.freeze({ mustInclude: ['Grok CLI installer', 'x.ai/cli'] }),
      }),
      scriptMethod('script-powershell', 'irm | iex', {
        shell: 'powershell', scriptUrl: 'https://x.ai/cli/install.ps1',
        platforms: ['win32'], supportsInstallDir: true,
        installDirEnv: 'GROK_BIN_DIR', env: ['GROK_BIN_DIR'],
        installDirSubdir: 'grok-build', legacySharedInstallDir: true,
        scriptBinaryNames: ['grok.exe', 'agent.exe', 'grove.exe', 'grove-fsmonitor.exe', 'grove-credential.exe'],
        verify: Object.freeze({ mustInclude: ['Grok CLI installer', 'x.ai/cli'] }),
      }),
    ]),
  }),
  Object.freeze({
    id: 'gemini',
    label: 'Gemini CLI',
    vendor: 'Google',
    purpose: 'Google 官方 Gemini CLI，无界面模式使用 gemini -p。',
    package: '@google/gemini-cli',
    manager: 'npm',
    installArgs: ['install', '-g', '@google/gemini-cli@latest', '--registry=https://registry.npmjs.org/'],
    uninstallArgs: ['uninstall', '-g', '@google/gemini-cli'],
    probeExecutables: ['gemini'],
    providerHints: ['gemini', 'google'],
    // Headless runs go through the task adapter. The signed sandbox runner does
    // not launch this CLI; a missing or failed process falls back to the API.
    headlessAdapter: true,
    installMethods: Object.freeze([
      packageManagerMethod('npm', 'npm', 'npm', '@google/gemini-cli@latest'),
      packageManagerMethod('pnpm', 'pnpm', 'pnpm', '@google/gemini-cli@latest'),
    ]),
  }),
  Object.freeze({
    id: 'opencode',
    label: 'OpenCode',
    vendor: 'anomalyco / SST',
    purpose: '开源终端编程代理，提供 opencode 命令；npm/pnpm 安装 OpenCode 2，旧版脚本安装 OpenCode 1。',
    package: '@opencode/cli',
    manager: 'npm',
    installArgs: ['install', '-g', '@opencode/cli@latest', '--registry=https://registry.npmjs.org/'],
    uninstallArgs: ['uninstall', '-g', '@opencode/cli'],
    probeExecutables: ['opencode'],
    probeNote: 'npm/pnpm 使用 OpenCode 2 官方包 @opencode/cli；旧版 V1 脚本固定安装到 ~/.opencode/bin，不能读取已迁移的 V2 数据库。',
    providerHints: ['opencode', 'anomalyco'],
    /** File an uninstall may delete, when the copy came from a script install. */
    scriptBinaryNames: Object.freeze(['opencode', 'opencode.exe']),
    /** Where the vendor script puts the binary when the user sets no directory. */
    defaultScriptInstallDir: '.opencode/bin',
    installMethods: Object.freeze([
      packageManagerMethod('npm', 'npm', 'npm', '@opencode/cli@latest'),
      packageManagerMethod('pnpm', 'pnpm', 'pnpm', '@opencode/cli@latest'),
      // The published script hardcodes $HOME/.opencode/bin, so it cannot honour
      // a custom install directory; the npm/pnpm methods above can.
      scriptMethod('script-bash', 'curl | bash（OpenCode 1）', {
        shell: 'bash',
        scriptUrl: 'https://opencode.ai/install',
        platforms: ['linux', 'darwin'],
        // The published script hardcodes $HOME/.opencode/bin, so it cannot honour
        // a custom install directory; the npm/pnpm methods above can.
        supportsInstallDir: false,
        verify: Object.freeze({
          mustInclude: ['anomalyco/opencode', 'opencode.ai'],
          mustNotInclude: ['static-openapi.stepfun.com'],
        }),
      }),
    ]),
  }),
  Object.freeze({
    id: 'stepcode',
    label: 'Step Code',
    vendor: 'StepFun 阶跃星辰',
    purpose: '阶跃星辰开源终端编程代理，提供 step 命令；官方只发布安装脚本，没有 npm 包。',
    manager: 'script-installer',
    installArgs: [],
    uninstallArgs: [],
    probeExecutables: ['step'],
    probeNote: 'step 命令来自阶跃官方安装脚本，校验和写入 ~/.stepcode；配置与凭据同在该目录，卸载只删除可执行文件。',
    providerHints: ['stepfun', 'stepcode'],
    scriptBinaryNames: Object.freeze(['step', 'step.exe']),
    defaultScriptInstallDir: '.stepcode/bin',
    /** The vendor installer writes this marked block into the shell profile. */
    pathProfileMarkers: Object.freeze(['# stepcode']),
    installMethods: Object.freeze([
      scriptMethod('script-bash', 'curl | bash', {
        shell: 'bash',
        scriptUrl: 'https://static-openapi.stepfun.com/stepcode/install.sh',
        platforms: ['linux', 'darwin'],
        installArg: ['--install-dir'],
        env: ['STEP_INSTALL_DIR', 'STEP_RELEASE_BASE_URL'],
        supportsInstallDir: true,
        // The installer replaces its runtime directories, including the entire
        // node_modules tree on Windows. It must own a dedicated directory.
        installDirSubdir: 'stepcode', legacySharedInstallDir: true,
        verify: Object.freeze({
          mustInclude: ['static-openapi.stepfun.com', 'stepcode installer'],
          mustNotInclude: ['anomalyco/opencode'],
        }),
      }),
      scriptMethod('script-powershell', 'irm | iex', {
        shell: 'powershell',
        scriptUrl: 'https://static-openapi.stepfun.com/stepcode/install.ps1',
        platforms: ['win32'],
        installArg: ['-InstallDir'],
        env: ['STEP_INSTALL_DIR', 'STEP_RELEASE_BASE_URL'],
        supportsInstallDir: true,
        installDirSubdir: 'stepcode', legacySharedInstallDir: true,
        verify: Object.freeze({
          mustInclude: ['static-openapi.stepfun.com', 'stepcode'],
          mustNotInclude: ['anomalyco/opencode'],
        }),
      }),
    ]),
  }),
  Object.freeze({
    id: 'pi',
    label: 'Pi',
    vendor: 'Earendil Works',
    purpose: 'Pi 编程代理，提供 pi 命令；支持 npm/pnpm 安装，要求 Node.js 22.19 及以上。',
    manager: 'npm',
    package: '@earendil-works/pi-coding-agent',
    installArgs: ['install', '-g', '@earendil-works/pi-coding-agent@latest', '--ignore-scripts', '--registry=https://registry.npmjs.org/'],
    uninstallArgs: ['uninstall', '-g', '@earendil-works/pi-coding-agent'],
    probeExecutables: ['pi'],
    probeNote: '使用官方 Pi 包及其声明的命令入口；普通安装无需生命周期脚本，登录请在 Pi 中输入 /login。',
    providerHints: ['earendil-works', 'pi-coding-agent'],
    installMethods: Object.freeze([
      packageManagerMethod('npm', 'npm', 'npm', '@earendil-works/pi-coding-agent@latest', { extraArgs: ['--ignore-scripts'] }),
      packageManagerMethod('pnpm', 'pnpm', 'pnpm', '@earendil-works/pi-coding-agent@latest', { extraArgs: ['--ignore-scripts'] }),
    ]),
  }),
  Object.freeze({
    id: 'hermes',
    label: 'Hermes Agent',
    vendor: 'Nous Research',
    purpose: 'Nous Research 的 Hermes Agent；支持 Windows 与 POSIX 官方源码安装器和交互终端。',
    manager: 'script-installer',
    installArgs: [],
    uninstallArgs: [],
    probeExecutables: ['hermes'],
    probeNote: '支持官方源码脚本安装；自定义源码安装到统一根/hermes-agent，插件使用该源码的 .hermes/bin 入口。配置、登录和历史保留原位置。桌面/MSIX 别名暂不用于此入口。登录使用 hermes auth。',
    providerHints: ['hermes', 'nousresearch'],
    scriptBinaryNames: Object.freeze(['hermes', 'hermes.exe']),
    installMethods: Object.freeze([
      scriptMethod('script-bash', 'curl | bash', {
        shell: 'bash', scriptUrl: 'https://hermes-agent.nousresearch.com/install.sh',
        platforms: ['linux', 'darwin'], supportsInstallDir: true, sharedDefaultBin: true,
        installDirSubdir: 'hermes-agent', installDirSuffix: '.hermes/bin', installArg: ['--dir'],
        extraArgs: ['--non-interactive'],
        verify: Object.freeze({ mustInclude: ['https://github.com/NousResearch/hermes-agent.git', 'hermes_cli/source_completion.py'] }),
        uninstallUnsupportedReason: '请在官方工具终端运行 hermes uninstall 卸载源码安装；保留配置与历史时按向导选择。桌面/MSIX 安装请使用系统应用管理。',
      }),
      scriptMethod('script-powershell', 'irm | iex', {
        shell: 'powershell', scriptUrl: 'https://hermes-agent.nousresearch.com/install.ps1',
        platforms: ['win32'], supportsInstallDir: true,
        installDirSubdir: 'hermes-agent', installDirSuffix: '.hermes/bin', installArg: ['-InstallDir'],
        extraArgs: ['-NonInteractive'],
        verify: Object.freeze({ mustInclude: ['https://github.com/NousResearch/hermes-agent.git', 'hermes_cli/source_completion.py'] }),
        uninstallUnsupportedReason: '请在官方工具终端运行 hermes uninstall 卸载源码安装；保留配置与历史时按向导选择。桌面/MSIX 安装请使用系统应用管理。',
      }),
    ]),
  }),
  Object.freeze({
    id: 'zcode',
    label: 'ZCode CLI',
    vendor: 'Z.ai · Alice-Marx 社区抽取版',
    purpose: 'ZCode 独立命令行发行版，包含 TUI、Web 和 Agent，无需 Electron；由 Alice-Marx/zcode-cli 社区维护。',
    package: '@ljwei-stak/zcode-cli',
    manager: 'github-release',
    installArgs: [],
    uninstallArgs: [],
    probeExecutables: ['zcode'],
    probeNote: '支持 GitHub Release（SHA256）或 npm 安装；需要 Node.js 24.14.0 或更新的 Node 24。',
    providerHints: ['zai', 'z.ai', 'zcode', 'glm', 'zhipu', 'bigmodel'],
    installMethods: Object.freeze([Object.freeze({
      id: 'github-release', label: 'GitHub Release · SHA256', kind: 'archive',
      manager: 'github-release', repository: 'Alice-Marx/zcode-cli',
      platforms: Object.freeze(['win32', 'linux', 'darwin']),
      supportsInstallDir: true, supportsRegistry: false,
      installArgs: Object.freeze([]), uninstallArgs: Object.freeze([]),
    }), packageManagerMethod('npm', 'npm', 'npm', '@ljwei-stak/zcode-cli@latest')]),
  }),
  Object.freeze({
    id: 'dsh-tui',
    label: 'dsh-TUI · DeepSeek',
    vendor: 'ccch1mneyyy',
    purpose: 'DeepSeek Harness 的终端 TUI：像素鲸鱼、实时状态、时间回退、会话管理，直接复用 DSH 的模型、工具与会话。',
    package: '@deepseek-harness-tui/dsh-tui',
    manager: 'npm',
    installArgs: ['install', '-g', '@deepseek-harness-tui/dsh-tui@latest', '--registry=https://registry.npmjs.org/'],
    uninstallArgs: ['uninstall', '-g', '@deepseek-harness-tui/dsh-tui'],
    probeExecutables: ['dsh-tui', 'dst'],
    probeNote: '包同时提供 dsh-tui 与 dst 两个命令，二者指向同一入口；需要 Node 22.19 或 24 以上。',
    // No headless mode: the Host drives it through the managed terminal instead.
    tuiPrompt: true,
    providerHints: ['deepseek'],
    installMethods: Object.freeze([
      packageManagerMethod('npm', 'npm', 'npm', '@deepseek-harness-tui/dsh-tui@latest'),
      packageManagerMethod('pnpm', 'pnpm', 'pnpm', '@deepseek-harness-tui/dsh-tui@latest'),
    ]),
  }),
])

const TOOL_BY_ID = new Map(OFFICIAL_TOOLS.map(tool => [tool.id, tool]))

export function getOfficialTool(id) {
  return TOOL_BY_ID.get(String(id ?? '').trim()) ?? null
}

/** Conservative keyword mapping from a catalog provider id/name to a tool. */
export function toolForProvider(provider) {
  const value = String(provider ?? '').trim().toLowerCase()
  if (!value) return null
  for (const tool of OFFICIAL_TOOLS) {
    if (tool.providerHints.some(hint => value.includes(hint))) return tool
  }
  return null
}

/** Every installation method declared by a tool. */
export function installMethodsFor(tool) {
  return Array.isArray(tool?.installMethods) ? tool.installMethods : []
}

/** One closed method id of one tool; null when the tool does not offer it. */
export function installMethodFor(tool, methodId) {
  const wanted = String(methodId ?? '').trim()
  if (!wanted) return null
  // 0.17.1 saved Codex's POSIX installer as script-bash. The vendor uses sh;
  // preserve that saved choice while returning the current declared method.
  const canonical = tool?.id === 'codex' && wanted === 'script-bash' ? 'script-sh' : wanted
  return installMethodsFor(tool).find(method => method.id === canonical) ?? null
}

/** The tool's default method, kept identical to `manager` / `installArgs`. */
export function defaultInstallMethod(tool) {
  return installMethodsFor(tool)[0] ?? null
}

/** Why a method cannot run here, or null when the current platform can run it. */
export function installMethodBlockReason(method, platform = 'linux') {
  if (!method?.platforms) return null
  return method.platforms.includes(platform) ? null : `此安装方式仅支持 ${method.platforms.join(' / ')}。`
}

/**
 * A method able to place the tool in the user's chosen directory. npm and pnpm
 * bind their global directories; vendor scripts declare an argument or environment binding.
 */
export function methodHonoursInstallDir(method) {
  return method?.supportsInstallDir === true
}

/** Human-readable install command line for one registry entry (default method). */
export function installCommandLine(tool) {
  if (!tool || tool.unsupported) return null
  return installCommandLineFor(tool, defaultInstallMethod(tool))
}

/** Human-readable command line for one specific method of one tool. */
export function installCommandLineFor(tool, method) {
  if (!tool || tool.unsupported) return null
  if (!method) return null
  if (method.kind === 'archive') return '下载 Alice-Marx/zcode-cli 最新 GitHub Release（校验 SHA256 后安装）'
  if (method.kind === 'script') {
    if (method.extraArgs?.length) {
      const args = method.extraArgs.join(' ')
      return method.shell === 'powershell'
        ? `& ([scriptblock]::Create((irm ${method.scriptUrl}))) ${args}`
        : `curl -fsSL ${method.scriptUrl} | ${method.shell} -s -- ${args}`
    }
    const piped = method.shell === 'powershell' ? `irm ${method.scriptUrl} | iex` : `curl -fsSL ${method.scriptUrl} | ${method.shell}`
    return piped
  }
  return `${method.manager} ${method.installArgs.join(' ')}`
}

/** Human-readable uninstall command line, or null when removal is not a command. */
export function uninstallCommandLineFor(tool, method) {
  if (!tool || tool.unsupported || !method) return null
  if (method.uninstallUnsupportedReason) return method.uninstallUnsupportedReason
  if (method.kind === 'archive') return '删除插件安装的 ZCode CLI 运行目录（保留配置与会话）'
  if (method.kind === 'script') return '删除官方安装的可执行文件（保留配置与登录信息）'
  return `${method.manager} ${method.uninstallArgs.join(' ')}`
}
