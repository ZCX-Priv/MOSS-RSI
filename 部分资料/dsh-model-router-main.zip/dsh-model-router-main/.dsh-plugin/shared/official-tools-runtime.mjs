/**
 * Host-side probe and install runtime for the official tool registry.
 *
 * The DeepSeek Harness plugin host runs as a full Node module, so probing,
 * installing, uninstalling and repairing official CLIs uses node:child_process
 * directly. Every command is built exclusively from the fixed registry plus the
 * user's own Host-side settings: callers supply a tool id and one of that tool's
 * declared method ids — never a package name, executable or argument. Installs
 * are serialized (npm global state must not interleave), output is kept as a
 * bounded tail, and success is always confirmed by a fresh probe rather than the
 * installer's exit code. When a newer release is known, a probe that is still
 * older fails the job instead of reporting success.
 */
import { spawn } from 'node:child_process'
import { mkdir, mkdtemp, readFile, realpath, rename, rm, stat, writeFile } from 'node:fs/promises'
import { homedir, tmpdir } from 'node:os'
import { dirname, isAbsolute, join, posix, relative, resolve, sep, win32 } from 'node:path'
import {
  DEFAULT_NPM_REGISTRY,
  defaultInstallMethod,
  getOfficialTool,
  installMethodFor,
  installCommandLine,
  OFFICIAL_TOOLS,
} from './official-tool-registry.mjs'
import {
  expandInstallDir,
  resolveInstallLocation,
  resolveLegacyScriptLocation,
  resolveInstallPlan,
  resolveUninstallPlan,
} from './tool-install-preferences.mjs'
import { discoverZCodeBundle } from './zcode-bundle.mjs'
import { installZCodeCli, uninstallZCodeCli } from './zcode-installer.mjs'
import { prepareZCodeNpmShims } from './zcode-npm-shims.mjs'
import { compareReleaseVersions, latestVersions } from './latest-versions.mjs'
import { versionStillOlder } from './version-order.mjs'

const PROBE_TIMEOUT_MS = 8_000
const INSTALL_TIMEOUT_MS = 900_000
const UNINSTALL_TIMEOUT_MS = 300_000
const OUTPUT_LINE_CAP = 120
const IS_WINDOWS = process.platform === 'win32'
const CREATE_NO_WINDOW = 0x0800_0000
const MINIMAX_INSTALLER_URL = 'https://filecdn.minimax.chat/public/install.ps1'
const MAX_INSTALLER_BYTES = 200_000
/** Windows ships where.exe in System32; POSIX which is ubiquitous. */
const LOCATOR = IS_WINDOWS ? 'where' : 'which'
/** Cached probe results keep plan generation fast; installs invalidate them. */
const probeCache = new Map()
const PROBE_CACHE_MS = 60_000
const installJobs = new Map()
let installChain = Promise.resolve()
const CLAUDE_UPDATE_TIMEOUT_MS = 180_000

/** Non-interactive updater for a native Claude Code install. npm does not move that copy. */
export const CLAUDE_UPDATE_ARGS = Object.freeze(['update'])

/**
 * Host-side install preferences (install directory, npm source, per-tool method
 * and script source). Refreshed on apply and live config updates, so a client
 * can only ever pick a method id — these addresses never arrive over the wire.
 */
let preferences = { installDir: '', registry: '', methods: {}, scriptUrls: {}, allowScriptInstall: true }

export function setInstallPreferences(next) {
  if (next && typeof next === 'object') {
    const previous = JSON.stringify(preferences)
    preferences = { ...preferences, ...next,
      methods: { ...(next.methods ?? preferences.methods) },
      scriptUrls: { ...(next.scriptUrls ?? preferences.scriptUrls) },
    }
    // A new directory needs its own PATH entry before the next probe runs.
    if (previous !== JSON.stringify(preferences)) {
      prefixPromise = null
      probeCache.clear()
    }
  }
  return preferences
}

export function installPreferences() {
  return { ...preferences, methods: { ...preferences.methods }, scriptUrls: { ...preferences.scriptUrls } }
}

/** The machine this Host runs on; the plan resolver needs both to be explicit. */
export function currentInstallOptions() {
  return { platform: process.platform, home: homedir(), env: process.env }
}

/** The selected tool's command directory, ahead of unrelated copies on PATH. */
export function preferredToolDirectories(toolId, selectedPreferences = preferences, options = currentInstallOptions()) {
  const tool = getOfficialTool(toolId)
  if (!tool || tool.unsupported) return []
  try {
    const plan = resolveInstallPlan(tool, undefined, {
      ...selectedPreferences,
      // Keep a deliberately selected existing script copy visible, while the
      // automatic method still honors the switch and can select npm instead.
      allowScriptInstall: installMethodFor(tool, selectedPreferences.methods?.[tool.id])?.kind === 'script' ? true : selectedPreferences.allowScriptInstall,
    }, options)
    return plan.binDir ? [plan.binDir] : []
  } catch { return [] }
}

/** A deliberate method/source/directory choice must never invoke a different updater. */
export function usesConfiguredInstallPlan(toolId, selectedPreferences = preferences, methodId) {
  return Boolean(methodId || selectedPreferences.installDir || selectedPreferences.methods?.[toolId]
    || selectedPreferences.scriptUrls?.[toolId] || selectedPreferences.allowScriptInstall === false
    || (selectedPreferences.registry && selectedPreferences.registry !== DEFAULT_NPM_REGISTRY))
}

/**
 * Spawn shape for a fixed registry command.
 *
 * Windows needs `shell: true` so `npm.cmd` / `where.exe` resolve. Node itself
 * wraps that as `cmd.exe /d /s /c`. Pre-quoting every argument (0.16.2) made
 * cmd strip the wrong quotes and launch `node` against a missing script:
 * `MODULE_NOT_FOUND` at `executeUserEntryPoint` with an empty requireStack.
 * That failed `npm config get prefix`, `--version`, and `npm install -g` for
 * every official tool. Keep bare tokens separate; quote only a path/value that
 * cmd would split or interpret as an operator.
 */
export function shellSpawnSpec(executable, args = [], { useShell = false } = {}) {
  const quote = value => {
    const text = String(value)
    if (!/[\s&|<>()^!%"]/.test(text)) return text
    return `"${text.replace(/(\\*)"/g, '$1$1\\"').replace(/(\\+)$/, '$1$1')}"`
  }
  return {
    file: useShell && IS_WINDOWS ? quote(executable) : String(executable),
    args: useShell && IS_WINDOWS ? (args ?? []).map(quote) : [...(args ?? [])],
    shell: Boolean(useShell),
  }
}

/** Decode a CLI banner. Native Windows exes often write UTF-16 to a pipe. */
export function decodeProcessOutput(value) {
  const bytes = Buffer.isBuffer(value) ? value : Buffer.from(value ?? '')
  if (bytes.length >= 2 && bytes[0] === 0xFF && bytes[1] === 0xFE) {
    return bytes.toString('utf16le').replace(/^\uFEFF/, '')
  }
  if (bytes.length >= 2 && bytes[0] === 0xFE && bytes[1] === 0xFF) {
    const swapped = Buffer.from(bytes)
    swapped.swap16()
    return swapped.toString('utf16le').replace(/^\uFEFF/, '')
  }
  const sample = bytes.subarray(0, Math.min(bytes.length, 64))
  let zeros = 0
  for (let index = 1; index < sample.length; index += 2) if (sample[index] === 0) zeros += 1
  const pairs = Math.floor(sample.length / 2)
  if (pairs >= 4 && zeros >= pairs * 0.6) return bytes.toString('utf16le').replace(/\u0000/g, '')
  return bytes.toString('utf8').replace(/^\uFEFF/, '')
}

/** Absolute paths printed by `where` / `which`, one per line. */
export function locatorPaths(stdout) {
  return String(stdout ?? '').split(/\r?\n/).map(line => line.trim().replace(/^"|"$/g, '')).filter(line => {
    if (!line || /^INFO:/i.test(line)) return false
    return isAbsolute(line)
  })
}

/** Visible failure when the installer exited cleanly but the probed copy is still older. */
export function staleInstallMessage(label, installedVersion, latestVersion) {
  return `${label} 的更新没有生效：检测到的版本仍是 ${installedVersion}，低于最新 ${latestVersion}。PATH 上可能有另一份更早的安装。请查看本行安装日志。`
}

/**
 * Which updater to run. `order` is compareReleaseVersions(installed, latest):
 * -1 older, 0 same, 1 newer, null when either version is unknown.
 */
export function officialUpdatePlan({ toolId, installed, order, platform, configured = false }) {
  if (installed && order === 1) return 'refuse-downgrade'
  if (installed && order === 0) return 'already-current'
  if (configured) return 'registry-install'
  if (installed && order === -1 && toolId === 'claude-code') return 'claude-update-then-registry'
  if (installed && (order === -1 || order === null) && toolId === 'minimax-code' && platform === 'win32') {
    return 'minimax-official-installer'
  }
  return 'registry-install'
}

async function trustedExecutionReadiness(toolId, options) {
  // Loaded only during an install to avoid coupling fast version probes to
  // the executor. The executor itself uses this runtime for PATH discovery.
  const { officialToolReadiness } = await import('./official-tool-executor.mjs')
  return officialToolReadiness(toolId, process.cwd(), options)
}

function runCapture(executable, args, { timeoutMs, onOutput, useShell = false, signal, env } = {}) {
  return new Promise(resolve => {
    if (signal?.aborted) {
      resolve({ ok: false, code: null, stdout: '', stderr: '', timedOut: false, cancelled: true })
      return
    }
    const stdoutChunks = []
    const stderrChunks = []
    const decoded = chunks => decodeProcessOutput(Buffer.concat(chunks))
    const pushChunk = (chunks, data) => {
      const buf = Buffer.isBuffer(data) ? data : Buffer.from(data)
      chunks.push(buf)
      let total = chunks.reduce((sum, chunk) => sum + chunk.length, 0)
      while (total > 64_000 && chunks.length > 1) total -= chunks.shift().length
      return decodeProcessOutput(buf)
    }
    let settled = false
    let stopReason = null
    let child
    try {
      const spec = shellSpawnSpec(executable, args, { useShell })
      child = spawn(spec.file, spec.args, {
        stdio: ['ignore', 'pipe', 'pipe'],
        windowsHide: true,
        // Windows npm CLIs install as .cmd shims; only cmd.exe can execute
        // them. Safe here because every executable and argument comes from
        // the fixed registry — caller input never reaches this boundary.
        shell: spec.shell,
        ...(env ? { env } : {}),
      })
    } catch (error) {
      resolve({ ok: false, code: null, stdout: '', stderr: String(error?.message ?? error), timedOut: false, cancelled: false })
      return
    }
    let graceTimer
    const finish = result => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      clearTimeout(graceTimer)
      signal?.removeEventListener('abort', onAbort)
      resolve(result)
    }
    const stop = reason => {
      if (settled || stopReason) return
      stopReason = reason
      if (IS_WINDOWS && useShell && Number.isInteger(child.pid)) {
        try {
          const killer = spawn('taskkill', ['/PID', String(child.pid), '/T', '/F'], {
            windowsHide: true,
            stdio: 'ignore',
          })
          killer.on('error', () => { try { child.kill('SIGTERM') } catch { /* already gone */ } })
          killer.on('close', code => { if (code !== 0) try { child.kill('SIGTERM') } catch { /* already gone */ } })
        } catch { try { child.kill('SIGTERM') } catch { /* already gone */ } }
      } else {
        try { child.kill('SIGTERM') } catch { /* already gone */ }
      }
      graceTimer = setTimeout(() => finish({ ok: false, code: null, stdout: decoded(stdoutChunks), stderr: decoded(stderrChunks),
        timedOut: reason === 'timeout', cancelled: reason === 'cancel' }), 5_000)
      graceTimer.unref?.()
    }
    const onAbort = () => stop('cancel')
    const timer = setTimeout(() => stop('timeout'), timeoutMs)
    signal?.addEventListener('abort', onAbort, { once: true })
    if (signal?.aborted) onAbort()
    child.stdout?.on('data', data => {
      if (settled || stopReason) return
      // Always keep the bytes. Optional chaining must not guard pushChunk:
      // version and PATH probes omit onOutput, and a skipped push leaves
      // stdout empty so every installed CLI looks not-installed.
      const text = pushChunk(stdoutChunks, data)
      onOutput?.(text)
    })
    child.stderr?.on('data', data => {
      if (settled || stopReason) return
      const text = pushChunk(stderrChunks, data)
      onOutput?.(text)
    })
    child.on('error', error => {
      const stdout = decoded(stdoutChunks)
      const stderr = decoded(stderrChunks)
      finish({ ok: false, code: null, stdout, stderr: `${stderr}${error.message}`.trim(),
        timedOut: stopReason === 'timeout', cancelled: stopReason === 'cancel' })
    })
    child.on('close', (code, signal) => {
      finish({ ok: !stopReason && code === 0, code, stdout: decoded(stdoutChunks), stderr: decoded(stderrChunks),
        timedOut: stopReason === 'timeout', cancelled: stopReason === 'cancel', signal })
    })
  })
}

export function installerScriptText(source) {
  return decodeProcessOutput(Buffer.isBuffer(source) ? source : Buffer.from(source ?? '')).replace(/^\uFEFF/, '')
}

export function isMarkupDocument(text) {
  const head = String(text ?? '').replace(/^\uFEFF/, '').trimStart()
  if (!head.startsWith('<') || head.startsWith('<#')) return false
  return /^<(?:!|\?|[A-Za-z])/.test(head)
}

/**
 * MiniMax's official Windows installer script is run as published (it installs
 * `@minimax-ai/code@latest`). Only structural sanity is checked: it must be the
 * MiniMax Code installer, not an HTML error page or another script.
 */
export function officialMiniMaxInstaller(source) {
  const text = installerScriptText(source)
  // PowerShell help starts with `<# ... #>`, including the current official
  // installer. It is a script comment, not an HTML response.
  if (isMarkupDocument(text) || !['@minimax-ai/code', 'MCODE_INSTALL_DIR', 'MiniMax Code'].every(marker => text.includes(marker))) {
    throw new Error('下载内容不是 MiniMax Code 官方 Windows 安装脚本，已拒绝执行。')
  }
  return text
}

async function fetchOfficialMiniMaxInstaller(signal) {
  return officialMiniMaxInstaller(await fetchVendorScript(MINIMAX_INSTALLER_URL, signal, { verify: { mustInclude: ['@minimax-ai/code', 'MiniMax Code CLI'] } }))
}

export function minimaxOfficialInstallDir(selectedPreferences = {}, home = homedir(), existingRoot = '') {
  return selectedPreferences.installDir
    ? resolveInstallPlan(getOfficialTool('minimax-code'), 'script-powershell', selectedPreferences, { platform: 'win32', home }).installDir
    : existingRoot || join(home, '.minimax-code')
}

/** Keep a discovered native installation in place when its legacy updater runs. */
export function miniMaxFallbackPlan(selectedPreferences, beforeProbe, prefix, options = currentInstallOptions()) {
  const installDir = minimaxOfficialInstallDir(selectedPreferences, options.home,
    beforeProbe?.installed ? beforeProbe.installDir : '')
  const executionPreferences = { ...selectedPreferences,
    methods: { ...selectedPreferences.methods, 'minimax-code': 'script-powershell' } }
  const plan = resolveInstallPlan(getOfficialTool('minimax-code'), 'script-powershell', selectedPreferences, options)
  // installDir is already the discovered exclusive native root or the resolved
  // child of the configured base. Never reinterpret it as another shared base.
  return { plan: { ...plan, installDir, binDir: installDir,
    env: { ...plan.env, MCODE_INSTALL_DIR: installDir } }, executionPreferences }
}

async function runOfficialMiniMaxInstaller(job, { reason } = {}) {
  let staging = null
  let prefixRoot = null
  try {
    job.finishedAt = null
    job.error = null
    job.phase = 'downloading-and-verifying'
    pushLine(job, reason || '— npm 原生依赖未就绪；改用 MiniMax 官方 Windows 安装脚本（安装最新版）—')
    const { plan, executionPreferences } = miniMaxFallbackPlan(job.preferences, job.beforeProbe, '')
    const installDir = plan.installDir
    await assertVendorInstallDirectory(job.tool, plan, job.preferences)
    await mkdir(installDir, { recursive: true })
    prefixRoot = await realpath(installDir)
    const script = await fetchOfficialMiniMaxInstaller(job.controller.signal)
    staging = await mkdtemp(join(prefixRoot, '.model-router-minimax-installer-'))
    const scriptPath = join(staging, 'install.ps1')
    const tempPath = join(staging, 'temp')
    await mkdir(tempPath)
    // Windows PowerShell 5 reads a BOM-less .ps1 using the system ANSI page.
    // The upstream installer contains Unicode art, so write a UTF-8 BOM.
    await writeFile(scriptPath, `\uFEFF${script}`, 'utf8')
    job.plan = plan
    job.methodId = plan.methodId
    job.installDir = installDir
    job.command = planCommandLine(plan)
    pushLine(job, `— 本次更新目录：${installDir} —`)
    const powershell = join(process.env.SystemRoot ?? 'C:\\Windows', 'System32',
      'WindowsPowerShell', 'v1.0', 'powershell.exe')
    const utilityModule = join(process.env.SystemRoot ?? 'C:\\Windows', 'System32',
      'WindowsPowerShell', 'v1.0', 'Modules', 'Microsoft.PowerShell.Utility',
      'Microsoft.PowerShell.Utility.psd1')
    const command = '$ErrorActionPreference="Stop"; '
      + 'Import-Module -Name $env:MODEL_ROUTER_UTILITY_MODULE -ErrorAction Stop; '
      + '& $env:MODEL_ROUTER_MINIMAX_INSTALL_SCRIPT'
    job.phase = 'installing'
    await assertVendorInstallDirectory(job.tool, plan, job.preferences)
    const outcome = await runCapture(powershell,
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', command], {
        timeoutMs: INSTALL_TIMEOUT_MS, signal: job.controller.signal,
        env: { ...process.env, ...plan.env, MCODE_INSTALL_DIR: installDir,
          MCODE_NO_MODIFY_PATH: '1', MCODE_DOWNLOAD_MIRROR: 'global',
          npm_config_cache: join(prefixRoot, '.model-router-npm-cache'),
          TEMP: tempPath, TMP: tempPath,
          MODEL_ROUTER_UTILITY_MODULE: utilityModule,
          MODEL_ROUTER_MINIMAX_INSTALL_SCRIPT: scriptPath },
        onOutput: chunk => {
          for (const line of chunk.split(/\r?\n/)) if (line.trim()) pushLine(job, line.slice(0, 500))
        },
      })
    if (outcome.cancelled || job.cancelRequested) { markCancelled(job); return }
    job.exitCode = outcome.code
    job.timedOut = outcome.timedOut
    if (!outcome.ok) throw new Error(outcome.timedOut
      ? '官方安装脚本超时并已终止。'
      : `官方安装脚本退出码 ${outcome.code ?? '信号终止'}。${outcome.stderr.split('\n').find(Boolean)?.slice(0, 180) ?? ''}`)
    appendToProcessPath(installDir, { prepend: true })
    job.phase = 'verifying'
    probeCache.delete(job.tool.id)
    const probe = await probeToolWith(job.tool, defaultRunner, { preferences: executionPreferences, plan, cacheMs: 0 })
    job.postInstallProbe = probe
    const readiness = await trustedExecutionReadiness(job.tool.id, { preferences: executionPreferences, plan })
    if (!probe.installed || !readiness.ready) {
      throw new Error(`官方安装器完成，但执行入口未通过 npm registry 摘要核验：${readiness.reason ?? probe.detail}`)
    }
    const latest = await latestVersions.lookup(job.tool, { plan: job.plan, preferences: job.preferences }).catch(() => null)
    if (latest?.version && versionStillOlder(probe.version, latest.version)) {
      throw new Error(staleInstallMessage(job.tool.label, probe.version, latest.version))
    }
    job.status = 'succeeded'
    job.finishedAt = new Date().toISOString()
    pushLine(job, `— 官方安装器已完成，MiniMax Code ${probe.version ?? ''} 的执行入口已核验 —`)
  } catch (error) {
    if (job.cancelRequested || job.controller.signal.aborted) { markCancelled(job); return }
    job.status = 'failed'
    job.error = `MiniMax 官方安装兜底失败：${String(error?.message ?? error).slice(0, 300)}`
    job.finishedAt = new Date().toISOString()
  } finally {
    if (staging && prefixRoot) {
      const part = relative(prefixRoot, staging)
      if (part.startsWith('.model-router-minimax-installer-') && !part.includes(sep)) {
        await rm(staging, { recursive: true, force: true }).catch(() => {})
      }
    }
  }
}

/**
 * The downloaded bytes must still be the vendor script this registry entry
 * names — never an HTML error page, never another vendor's installer that a
 * mirror substituted. Markers are the same ones the vendor's own docs publish
 * inside the script, so a mirror may rehost the file but not rewrite it into a
 * different program.
 */
export function verifiedVendorScript(source, verify = {}) {
  const text = installerScriptText(source)
  if (!text.trim()) throw new Error('下载内容为空，已拒绝执行。')
  if (isMarkupDocument(text)) throw new Error('下载内容不是安装脚本（收到 HTML 页面），已拒绝执行。')
  // Check "wrong vendor" first: a mirror that substituted another installer is
  // a different diagnosis from a truncated download, and the clearer one.
  const foreign = (verify.mustNotInclude ?? []).filter(marker => text.includes(marker))
  if (foreign.length) throw new Error('下载内容属于其他厂商的安装脚本，已拒绝执行。')
  const missing = (verify.mustInclude ?? []).filter(marker => !text.includes(marker))
  if (missing.length) {
    throw new Error(`下载内容不是该厂商的官方安装脚本（缺少 ${missing.join('、')}），已拒绝执行。`)
  }
  return text
}

/** Windows WebRequest follows the system proxy, which Node fetch may not use. */
export const WINDOWS_SCRIPT_DOWNLOAD = [
  '$ErrorActionPreference="Stop"',
  '[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12',
  '$request=[Net.HttpWebRequest]::Create($env:MODEL_ROUTER_DOWNLOAD_URL)',
  '$request.UserAgent="curl/8.0"',
  '$request.Timeout=30000',
  '$request.ReadWriteTimeout=30000',
  '$response=$request.GetResponse()',
  `if ($response.ContentLength -gt ${MAX_INSTALLER_BYTES}) { $response.Close(); throw "Installer exceeds size limit" }`,
  '$stream=$response.GetResponseStream()',
  '$output=New-Object IO.MemoryStream',
  '$buffer=New-Object byte[] 8192',
  'try { while (($count=$stream.Read($buffer,0,$buffer.Length)) -gt 0) { '
    + `$output.Write($buffer,0,$count); if ($output.Length -gt ${MAX_INSTALLER_BYTES}) { throw "Installer exceeds size limit" } }; `
    + '[IO.File]::WriteAllBytes($env:MODEL_ROUTER_DOWNLOAD_FILE,$output.ToArray()) '
    + '} finally { $stream.Close(); $response.Close(); $output.Dispose() }',
].join('; ')

/** Download bytes only; every transport still checks the same vendor markers. */
export async function fetchVendorScript(url, signal, {
  verify = {}, fetcher = globalThis.fetch, platform = process.platform, powershellRunner = runCapture, fallbackUrls = [],
} = {}) {
  if (fallbackUrls.length) {
    let lastError
    for (const candidate of [...new Set([url, ...fallbackUrls])]) {
      try { return await fetchVendorScript(candidate, signal, { verify, fetcher, platform, powershellRunner }) }
      catch (error) { if (signal?.aborted) throw error; lastError = error }
    }
    throw lastError
  }
  const check = bytes => { verifiedVendorScript(bytes, verify); return bytes }
  let firstError
  try {
    const response = await fetcher(url, {
      headers: { 'User-Agent': 'curl/8.0', Accept: 'text/plain, application/octet-stream;q=0.9, */*;q=0.8' },
      signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(30_000)]) : AbortSignal.timeout(30_000),
    })
    if (!response.ok || !response.body) throw new Error(`官方脚本下载失败：HTTP ${response.status}`)
    const declared = Number(response.headers?.get?.('content-length') ?? 0)
    if (declared > MAX_INSTALLER_BYTES) throw new Error('官方安装脚本超过大小上限。')
    const chunks = []
    let length = 0
    for await (const chunk of response.body) {
      length += chunk.length
      if (length > MAX_INSTALLER_BYTES) throw new Error('官方安装脚本超过大小上限。')
      chunks.push(chunk)
    }
    return check(Buffer.concat(chunks))
  } catch (error) {
    if (signal?.aborted || platform !== 'win32') throw error
    firstError = error
  }
  // This fixed PowerShell program only downloads to a private temporary file.
  // Neither the URL nor response bytes become executable command text.
  const staging = await mkdtemp(join(tmpdir(), '.model-router-script-download-'))
  try {
    const outputPath = join(staging, 'installer.bin')
    const outcome = await powershellRunner(POWERSHELL, [
      '-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(WINDOWS_SCRIPT_DOWNLOAD, 'utf16le').toString('base64'),
    ], { timeoutMs: 40_000, signal,
      env: { ...process.env, MODEL_ROUTER_DOWNLOAD_URL: url, MODEL_ROUTER_DOWNLOAD_FILE: outputPath },
    })
    if (!outcome.ok) {
      throw new Error(`官方脚本下载失败：${String(firstError?.message ?? firstError).slice(0, 150)}；系统下载通道${outcome.cancelled ? '已取消' : outcome.timedOut ? '超时' : `退出码 ${outcome.code ?? '未知'}`}。${String(outcome.stderr ?? '').slice(0, 150)}`)
    }
    const size = (await stat(outputPath)).size
    if (size > MAX_INSTALLER_BYTES) throw new Error('官方安装脚本超过大小上限。')
    return check(await readFile(outputPath))
  } finally {
    await rm(staging, { recursive: true, force: true }).catch(() => {})
  }
}

const POWERSHELL = join(process.env.SystemRoot ?? 'C:\\Windows', 'System32',
  'WindowsPowerShell', 'v1.0', 'powershell.exe')

/** argv that runs one staged vendor script; no remote content ever reaches the interpreter. */
export function vendorScriptInvocation(plan, scriptPath) {
  // `installArg` is the vendor's own single flag (`--install-dir` / `-InstallDir`).
  const directoryArgs = plan.installArg?.[0] && plan.installDir ? [plan.installArg[0], plan.installDir] : []
  const extraArgs = Array.isArray(plan.extraArgs) ? plan.extraArgs : []
  if (plan.shell === 'powershell') {
    return {
      file: POWERSHELL,
      args: ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath, ...directoryArgs, ...extraArgs],
    }
  }
  return { file: plan.shell === 'sh' ? 'sh' : 'bash', args: [scriptPath, ...directoryArgs, ...extraArgs] }
}

/** Resolve an existing ancestor too, so a missing child under a junction is checked. */
async function canonicalInstallPath(path) {
  let current = resolve(path)
  const suffix = []
  for (;;) {
    try { return join(await realpath(current), ...suffix) }
    catch (error) {
      if (error.code !== 'ENOENT') throw error
      const parent = dirname(current)
      if (parent === current) throw error
      suffix.unshift(current.slice(parent.length).replace(/^[\\/]+/, ''))
      current = parent
    }
  }
}

/** A vendor owns its target; its cleanup must never touch a shared npm prefix. */
export async function assertVendorInstallDirectory(tool, plan, selectedPreferences = {}, options = currentInstallOptions()) {
  const directory = plan.installDir || plan.binDir
  if (!directory) throw new Error('官方脚本安装目录无法确定，已停止安装。')
  const canonical = await canonicalInstallPath(directory)
  if (canonical.split(/[\\/]+/).some(part => ['node_modules', '.pnpm'].includes(part.toLowerCase()))) {
    throw new Error('官方脚本不能写入 npm/pnpm 的包目录或共享存储目录。')
  }
  if (canonical === dirname(canonical) || canonical === await canonicalInstallPath(homedir())) {
    throw new Error('官方脚本不能在磁盘根目录或用户主目录中执行。')
  }
  let codexOwnedRelease = false
  if (tool.id === 'codex' && plan.shell === 'powershell') {
    // The official Windows script keeps releases under the user's existing
    // CODEX_HOME. CODEX_INSTALL_DIR selects only the visible bin junction.
    // Respect that documented layout without redirecting the user's config.
    const codexHome = options.env?.CODEX_HOME || join(options.home || homedir(), '.codex')
    const homeRoot = await canonicalInstallPath(codexHome)
    const releases = join(homeRoot, 'packages', 'standalone', 'releases')
    const member = relative(releases, canonical)
    const expectedVisible = !selectedPreferences.installDir || resolve(directory) === resolve(join(selectedPreferences.installDir, plan.method.installDirSubdir))
    codexOwnedRelease = Boolean(expectedVisible && member && member !== '..' && !member.startsWith(`..${sep}`) && !isAbsolute(member))
  }
  if (selectedPreferences.installDir && plan.method?.supportsInstallDir) {
    const base = await canonicalInstallPath(selectedPreferences.installDir)
    const child = relative(base, canonical)
    if (!codexOwnedRelease && (!child || child === '..' || child.startsWith(`..${sep}`) || isAbsolute(child))) {
      throw new Error('官方脚本必须使用统一安装根目录下的工具专属子目录；已拒绝覆盖共享目录。')
    }
    const owner = plan.method.installDirSubdir?.split(/[\\/]+/)[0]
    const ownedRoot = owner ? join(base, owner) : null
    const ownedChild = ownedRoot ? relative(ownedRoot, canonical) : '..'
    if (!codexOwnedRelease && (ownedChild === '..' || ownedChild.startsWith(`..${sep}`) || isAbsolute(ownedChild))) {
      throw new Error('官方脚本的目录联接必须留在本工具专属目录中，不能指向其他工具。')
    }
  }
  // These fixed/default bin installers replace only their own launcher, not
  // another CLI's runtime directory. Sharing ~/.local/bin is intentional.
  if (plan.method?.sharedDefaultBin && (!selectedPreferences.installDir || !plan.method.supportsInstallDir)) return
  const targetStat = await stat(directory).catch(error => {
    if (error.code === 'ENOENT') return null
    throw error
  })
  if (targetStat && !targetStat.isDirectory()) throw new Error('官方脚本安装目标不是目录。')
  const packageText = await readFile(join(directory, 'package.json'), 'utf8').catch(error => {
    if (error.code === 'ENOENT') return null
    throw error
  })
  if (packageText) {
    let name
    try { name = JSON.parse(packageText).name } catch { throw new Error('安装目录已有无法核验归属的 package.json，已停止运行官方脚本。') }
    const ownPackage = tool.package || (tool.id === 'stepcode' ? '@step-harness/coding-agent' : '')
      || (tool.id === 'hermes' ? 'hermes-agent' : '')
    if (!name || name !== ownPackage) throw new Error('安装目录已有其他工具或项目的 package.json，已停止运行官方脚本。')
  }
  for (const other of OFFICIAL_TOOLS) {
    if (other.id === tool.id) continue
    const commandDirectories = [...new Set([directory, plan.binDir].filter(Boolean))]
    const candidates = commandDirectories.flatMap(dir => (other.probeExecutables ?? []).flatMap(name =>
      [name, `${name}.exe`, `${name}.cmd`, `${name}.ps1`].map(file => join(dir, file))))
    if (other.package) {
      candidates.push(join(directory, 'node_modules', ...other.package.split('/'), 'package.json'))
      candidates.push(join(directory, 'lib', 'node_modules', ...other.package.split('/'), 'package.json'))
    }
    for (const path of candidates) {
      const found = await stat(path).catch(error => {
        if (error.code === 'ENOENT' || error.code === 'ENOTDIR') return null
        throw error
      })
      if (found?.isFile()) throw new Error(`安装目录中已有 ${other.label} 的文件，已拒绝运行可能替换其资源的官方脚本。请使用独立目录。`)
    }
  }
}

/**
 * Install one tool from its vendor script: download, verify, stage, run the
 * staged copy. The binary lands in a directory the plugin appends to its own
 * PATH, so the fresh probe below sees the copy this job just installed rather
 * than an older one that happened to be on PATH first.
 */
async function runVendorScriptInstallJob(job, plan) {
  if (job.status !== 'running') return
  let staging = null
  try {
    job.phase = 'preflight'
    await assertVendorInstallDirectory(job.tool, plan, job.preferences)
    const before = await probeToolWith(job.tool, defaultRunner, { plan, preferences: job.preferences, cacheMs: 0 })
    job.beforeProbe = before
    const latestBefore = before.installed ? await latestVersions.lookup(job.tool, { fresh: true, plan: job.plan, preferences: job.preferences }).catch(() => null) : null
    if (job.cancelRequested) { markCancelled(job); return }
    if (latestBefore?.version && compareReleaseVersions(before.version, latestBefore.version) === 1) {
      throw new Error(`已安装 ${before.version}，高于最新正式版 ${latestBefore.version}；不会自动降级。`)
    }
    job.phase = 'downloading-and-verifying'
    for (const notice of plan.notices ?? []) pushLine(job, notice)
    pushLine(job, `— 下载官方安装脚本：${plan.scriptUrl}`)
    const source = verifiedVendorScript(await fetchVendorScript(plan.scriptUrl, job.controller.signal, {
      verify: plan.verify, fallbackUrls: (plan.downloadUrls ?? []).slice(1),
    }), plan.verify)
    staging = await mkdtemp(join(tmpdir(), '.model-router-tool-install-'))
    const isPowerShell = plan.shell === 'powershell'
    const scriptPath = join(staging, isPowerShell ? 'install.ps1' : 'install.sh')
    // Windows PowerShell 5 reads a BOM-less .ps1 using the system ANSI page;
    // both vendor scripts contain non-ASCII text, so write a UTF-8 BOM.
    await writeFile(scriptPath, isPowerShell ? `\uFEFF${source}` : source, 'utf8')
    const invocation = vendorScriptInvocation(plan, scriptPath)
    job.phase = 'installing'
    await assertVendorInstallDirectory(job.tool, plan, job.preferences)
    pushLine(job, `$ ${plan.label}${invocation.args.length > 1 ? ` ${invocation.args.slice(1).join(' ')}` : ''}`)
    const outcome = await runCapture(invocation.file, invocation.args, {
      timeoutMs: INSTALL_TIMEOUT_MS,
      signal: job.controller.signal,
      env: installEnvironment(plan),
      onOutput: captureLines(job),
    })
    if (outcome.cancelled || job.cancelRequested) { markCancelled(job); return }
    job.exitCode = outcome.code
    job.timedOut = outcome.timedOut
    if (!outcome.ok) {
      throw new Error(outcome.timedOut ? '官方安装脚本超时并已终止。'
        : `官方安装脚本退出码 ${outcome.code ?? '信号终止'}。${String(outcome.stderr ?? '').split('\n').find(Boolean)?.slice(0, 200) ?? ''}`)
    }
    if (plan.binDir) appendToProcessPath(plan.binDir, { prepend: true })
    job.phase = 'verifying'
    probeCache.delete(job.tool.id)
    const probe = await probeToolWith(job.tool, defaultRunner, { cacheMs: 0, plan, preferences: job.preferences })
    job.postInstallProbe = probe
    if (!probe.installed) {
      throw new Error(`官方安装脚本已完成，但 PATH 上仍找不到 ${job.tool.probeExecutables?.[0] ?? job.tool.label}：${probe.detail}`)
    }
    const latest = await latestVersions.lookup(job.tool, { plan: job.plan, preferences: job.preferences }).catch(() => null)
    if (latest?.version && versionStillOlder(probe.version, latest.version)) {
      throw new Error(staleInstallMessage(job.tool.label, probe.version, latest.version))
    }
    job.status = 'succeeded'
    job.finishedAt = new Date().toISOString()
    pushLine(job, `— 已通过 ${plan.label} 安装 ${job.tool.label} ${probe.version ?? ''} —`)
  } catch (error) {
    if (job.cancelRequested || job.controller.signal.aborted) { markCancelled(job); return }
    job.status = 'failed'
    job.error = `${job.tool.label} 安装失败：${String(error?.message ?? error).slice(0, 300)}`
    job.finishedAt = new Date().toISOString()
  } finally {
    if (staging) await rm(staging, { recursive: true, force: true }).catch(() => {})
  }
}

/**
 * Guard rail for the one destructive operation: deleting a vendor binary. Every
 * part of the path came from the fixed registry and the user's own settings,
 * and this re-checks all of it — the basename must be one the registry names,
 * the file must sit inside that tool's install directory, and it can never be a
 * home directory or a filesystem root.
 */
export function scriptBinaryCandidate(installDir, relative) {
  const raw = String(relative ?? '')
  const parts = raw.split(/[\\/]/)
  if (!raw || isAbsolute(raw) || /^[A-Za-z]:/.test(raw) || parts.some(part => !part || part === '.' || part === '..')) {
    throw new Error('拒绝删除安装目录之外的文件。')
  }
  return join(installDir, ...parts)
}

export function checkedRemovableFile(candidate, { allowedNames, installDir, home = homedir() }) {
  const target = resolve(candidate)
  const base = target.split(sep).pop() ?? ''
  if (!allowedNames.includes(base)) throw new Error(`拒绝删除 ${base}：不在该工具的固定可执行文件名列表中。`)
  if (target === resolve(home) || target === resolve(target, '..')) {
    throw new Error('拒绝删除用户主目录或文件系统根目录。')
  }
  if (installDir && !isInsideDirectory(installDir, target)) {
    throw new Error(`拒绝删除 ${target}：不在该工具的安装目录 ${installDir} 内。`)
  }
  return target
}

function isInsideDirectory(parent, child) {
  const canonical = resolve(parent)
  return child === canonical || child.startsWith(canonical.endsWith(sep) ? canonical : `${canonical}${sep}`)
}

/**
 * Remove one tool. Package-manager installs go back through the same manager;
 * script installs delete the executable the vendor script placed, and only that
 * file — the vendor's config, credentials and session history stay, so a
 * reinstall keeps the user's login.
 */
async function runVendorScriptUninstallJob(job, plan) {
  if (job.status !== 'running') return
  try {
    job.phase = 'removing'
    const location = { dir: plan.dir, binaries: plan.binaries }
    const removed = []
    for (const binary of location?.binaries ?? []) {
      const candidate = scriptBinaryCandidate(location.dir, binary)
      // checkedRemovableFile re-checks the basename, the install directory and
      // the root/home guards even though every part came from the registry.
      const target = checkedRemovableFile(candidate, {
        allowedNames: location.binaries, installDir: location.dir, home: homedir(),
      })
      if (!(await stat(target).catch(() => null))?.isFile()) continue
      await rm(target, { force: true })
      removed.push(target)
    }
    if (removed.length === 0) {
      throw new Error(`在 ${location?.dir || '安装目录'} 下没有找到 ${job.tool.label} 的可执行文件；它可能是用包管理器安装的，请改用该方式卸载。`)
    }
    const stripped = await stripPathProfileBlocks(job.tool).catch(error => [`（未能清理 PATH 配置：${String(error?.message ?? error).slice(0, 120)}）`])
    for (const path of removed) pushLine(job, `已删除 ${path}`)
    if (stripped.length) pushLine(job, `已清理 shell 配置中的 PATH 记录：${stripped.join('、')}`)
    pushLine(job, `已保留 ${job.tool.label} 的配置与登录信息（${homedir()}/${String(job.tool.defaultScriptInstallDir ?? '').split('/')[0]}）。`)
    job.phase = 'verifying'
    probeCache.delete(job.tool.id)
    const probe = await probeToolWith(job.tool, defaultRunner, { cacheMs: 0, preferences: job.preferences, plan: { ...plan, binDir: plan.dir } })
    job.postInstallProbe = probe
    job.status = 'succeeded'
    job.finishedAt = new Date().toISOString()
    job.error = probe.installed
      ? `已删除本次安装的可执行文件，但 PATH 上仍有另一份 ${job.tool.label}，请检查其他安装来源。`
      : null
  } catch (error) {
    if (job.cancelRequested || job.controller.signal.aborted) { markCancelled(job); return }
    job.status = 'failed'
    job.error = `${job.tool.label} 卸载失败：${String(error?.message ?? error).slice(0, 300)}`
    job.finishedAt = new Date().toISOString()
  }
}

/**
 * Remove the vendor installer's own marked block from the shell profiles it
 * writes. Only a well-formed `# stepcode … # stepcode end` block is removed; a
 * bare mention is left alone, exactly as the vendor's installer decides.
 */
export function stripPathBlock(content, marker, closingMarker = `${marker} end`) {
  const text = String(content ?? '')
  if (!text.includes(marker)) return null
  const lines = text.match(/[^\r\n]*(?:\r\n|\n|$)/g)?.filter(Boolean) ?? []
  const kept = []
  let removed = 0
  for (let index = 0; index < lines.length; index += 1) {
    if (lines[index].trim() !== marker) { kept.push(lines[index]); continue }
    let closing = index + 1
    while (closing < lines.length && lines[closing].trim() !== closingMarker) {
      if (lines[closing].trim() === marker) return null
      closing += 1
    }
    // A truncated block never authorizes deleting the rest of the user's file.
    if (closing === lines.length) return null
    removed += closing - index + 1
    index = closing
  }
  return removed > 0 ? kept.join('') : null
}

const SHELL_PROFILES = ['.bashrc', '.bash_profile', '.zshrc', '.profile']

async function stripPathProfileBlocks(tool) {
  const markers = tool?.pathProfileMarkers ?? []
  if (markers.length === 0) return []
  const touched = []
  for (const profile of SHELL_PROFILES) {
    const path = join(homedir(), profile)
    let content
    try { content = await readFile(path, 'utf8') } catch { continue }
    let next = content
    if (tool.id === 'grok-build' && markers.length === 2) {
      next = stripPathBlock(next, markers[0], markers[1]) ?? next
    } else {
      for (const marker of markers) next = stripPathBlock(next, marker) ?? next
    }
    if (next === content) continue
    const temporary = `${path}.model-router-${process.pid}.tmp`
    await writeFile(temporary, next, 'utf8')
    await rename(temporary, path)
    touched.push(profile)
  }
  return touched
}

/** Tools whose ready-check failure can be repaired by reinstalling the same version. */
const CAPABILITY_REPAIRABLE = new Set([
  'claude-code', 'codex', 'kimi-code', 'minimax-code', 'mimo-code', 'grok-build', 'opencode', 'stepcode', 'hermes', 'pi', 'zcode',
])

/** Extract the first version-looking token from a CLI banner. */
export function versionFromBanner(banner) {
  const match = String(banner ?? '').match(/\d+\.\d+\.\d+(?:-[0-9A-Za-z.]+)?/)
  return match ? match[0] : null
}

/**
 * Probe one registry tool. `runner` is injectable for offline tests and must
 * return { ok, code, stdout, stderr, timedOut }. Package-manager probes inspect
 * their actual package manifest and declared entry; they never execute a shared
 * npm/pnpm command shim. `packageEntries` keeps those inspections injectable.
 */
export async function probeToolWith(tool, runner, {
  cache = probeCache, cacheMs = PROBE_CACHE_MS, now = Date.now,
  preferences: selectedPreferences = preferences, plan,
  fileExists = async path => (await stat(path).catch(() => null))?.isFile() === true,
  packageEntries = selectedPackageEntries,
} = {}) {
  const scope = JSON.stringify([selectedPreferences, plan?.methodId, plan?.binDir, plan?.packageModuleRoots])
  const cached = cache.get(tool.id)
  if (cached && cached.scope === scope && now() - cached.at < cacheMs) return cached.value
  const probe = await probeUncached(tool, runner, { selectedPreferences, plan, fileExists, packageEntries })
  cache.set(tool.id, { at: now(), value: probe, scope })
  return probe
}

/** Reuse the concrete entry discovered by the installation probe for login checks. */
export async function loginLaunchForProbe(probe, {
  workspace = process.cwd(),
  fileExists = async path => (await stat(path).catch(() => null))?.isFile() === true,
  findNode = async cwd => (await import('./official-tool-executor.mjs')).findNodeExecutable(cwd),
} = {}) {
  if (probe?.installed !== true || !getOfficialTool(probe.id)) return null
  const entry = probe.packageEntry || probe.executablePath
  if (typeof entry !== 'string' || !isAbsolute(entry) || !(await fileExists(entry))) return null
  if (/\.(?:mjs|cjs|js)$/i.test(entry)) {
    const node = await findNode(workspace)
    return node ? { file: node, args: [entry], useShell: false } : null
  }
  return { file: entry, args: [], useShell: IS_WINDOWS && /\.(?:cmd|bat)$/i.test(entry) }
}

async function selectedPackageEntries(tool, { plan, preferences: selectedPreferences }) {
  const { findGlobalPackageEntries, officialToolEntrySelection } = await import('./official-tool-executor.mjs')
  if (tool.id === 'zcode' && plan.kind === 'package-manager') {
    plan = plan.installDir || Array.isArray(plan.packageModuleRoots) ? plan
      : await resolvePackageJobPlan(tool, plan, selectedPreferences)
    const moduleRoots = plan.packageModuleRoots ?? [IS_WINDOWS ? join(plan.installDir, 'node_modules') : join(plan.installDir, 'lib', 'node_modules')]
    return findGlobalPackageEntries(tool.package, 'zcode', 'bin/zcode.mjs', process.cwd(), { moduleRoots, manager: 'npm' })
  }
  const selection = officialToolEntrySelection(tool.id, { preferences: selectedPreferences, plan })
  const entries = []
  for (const executable of tool.probeExecutables) {
    entries.push(...await findGlobalPackageEntries(tool.package, executable, '', process.cwd(), {
      selection, directories: selection.directories, manager: plan.manager, moduleRoots: plan.packageModuleRoots,
    }))
  }
  return entries
}

async function probeUncached(tool, runner, { selectedPreferences, plan, fileExists, packageEntries }) {
  if (tool.unsupported) {
    return { id: tool.id, installed: false, version: null, status: 'unsupported', detail: tool.unsupportedReason }
  }
  let selectedPlan = plan
  if (!selectedPlan) {
    try {
      selectedPlan = resolveInstallPlan(tool, undefined, {
        ...selectedPreferences,
        allowScriptInstall: installMethodFor(tool, selectedPreferences.methods?.[tool.id])?.kind === 'script' ? true : selectedPreferences.allowScriptInstall,
      }, currentInstallOptions())
    } catch (error) {
      if (usesConfiguredInstallPlan(tool.id, selectedPreferences)) {
        return { id: tool.id, installed: false, version: null, status: 'probe-failed',
          detail: `无法检查所选安装方式或目录：${String(error?.message ?? error).slice(0, 200)}` }
      }
    }
  }
  if (selectedPlan?.kind === 'archive') {
    const location = { methodId: selectedPlan.methodId, manager: selectedPlan.manager, binDir: selectedPlan.binDir }
    let rejected = null
    const bundle = await discoverZCodeBundle({ installDir: selectedPlan.installDir,
      onRejected: value => { rejected ??= value } })
    if (bundle) return { id: tool.id, installed: true, version: bundle.version, status: 'installed', ...location,
      detail: `${tool.probeNote} 安装目录：${bundle.root}`, bannerLine: `${tool.label} ${bundle.version}`,
      installDir: bundle.root, cliEntry: bundle.cliEntry, packageEntry: bundle.cliEntry, source: bundle.source }
    return { id: tool.id, installed: false, version: null, status: 'not-installed', ...location,
      detail: rejected?.rejected || `未找到经过 GitHub Release SHA256 校验的 ZCode CLI：${selectedPlan.installDir}` }
  }
  // npm and pnpm can write the same shim into a unified bin directory. Its
  // banner belongs to whichever manager wrote it last, not the selected copy.
  // Bind version detection to the selected manager's package tree and declared
  // bin. Execution readiness independently verifies whether that entry runs.
  if (selectedPlan?.kind === 'package-manager' && tool.package) {
    const entries = await packageEntries(tool, { plan: selectedPlan, preferences: selectedPreferences })
    const selected = [...entries].sort((left, right) => compareReleaseVersions(right.version, left.version) ?? 0)[0]
    const location = { installDir: selectedPlan.installDir, binDir: selectedPlan.binDir,
      methodId: selectedPlan.methodId, manager: selectedPlan.manager }
    if (selected) return { id: tool.id, installed: true, version: selected.version ?? null,
      status: 'installed', ...location, packageRoot: selected.packageRoot,
      packageEntry: selected.entry, source: selected.source,
      detail: `${tool.probeNote ?? ''} ${selectedPlan.manager} 安装包：${selected.packageRoot}`,
      bannerLine: `${tool.label} ${selected.version ?? '（版本未知）'}` }
    return { id: tool.id, installed: false, version: null, status: 'not-installed', ...location,
      detail: `未在所选${selectedPlan.binDir ? `安装目录 ${selectedPlan.binDir}` : '全局安装目录'}中找到 ${selectedPlan.manager} 安装的 ${tool.package} 及其声明的命令入口。` }
  }
  // Native script locations are also concrete targets. A different PATH copy
  // must not satisfy installation or conceal an unsuccessful update.
  if (selectedPlan?.binDir) {
    for (const executable of tool.probeExecutables) {
      const names = IS_WINDOWS
        ? selectedPlan.kind === 'package-manager'
          ? [`${executable}.cmd`, executable, `${executable}.exe`]
          : [`${executable}.exe`, `${executable}.cmd`, executable]
        : [executable]
      for (const name of names) {
        const target = join(selectedPlan.binDir, name)
        if (!(await fileExists(target))) continue
        const attempt = await runner(target, ['--version'], { timeoutMs: PROBE_TIMEOUT_MS, useShell: IS_WINDOWS && /\.(cmd|bat)$/i.test(target) })
        const banner = probeBanner(attempt)
        const version = versionFromBanner(banner)
        return { id: tool.id, installed: Boolean(attempt.ok || version), version,
          status: attempt.timedOut ? 'probe-timeout' : attempt.ok || version ? 'installed' : 'probe-failed',
          detail: attempt.ok || version ? `${tool.probeNote ?? ''} 安装目录：${selectedPlan.binDir}`
            : `${target} --version ${attempt.timedOut ? '超时' : `退出码 ${attempt.code ?? '信号终止'}`}。${String(attempt.stderr ?? '').slice(0, 120)}`,
          executablePath: target, installDir: selectedPlan.installDir, binDir: selectedPlan.binDir,
          bannerLine: banner.split('\n').find(Boolean)?.slice(0, 200) ?? '' }
      }
    }
    const legacy = resolveLegacyScriptLocation(tool, selectedPlan.method, selectedPreferences, currentInstallOptions())
    if (legacy) {
      for (const executable of tool.probeExecutables) {
        const names = IS_WINDOWS ? [`${executable}.exe`, `${executable}.cmd`, executable] : [executable]
        for (const name of names) {
          const target = join(legacy.dir, name)
          if (!(await fileExists(target))) continue
          // Discovery is read-only. The old root can never satisfy a new job's
          // target probe or become a script update/uninstall destination.
          return { id: tool.id, installed: false, version: null, status: 'legacy-install',
            installDir: selectedPlan.installDir, binDir: selectedPlan.binDir,
            legacyExecutablePath: target,
            detail: `发现旧共享目录中的 ${tool.label}：${target}。请安装到独立目录 ${selectedPlan.installDir}；旧文件会保留，不能用旧目录覆盖其他工具。` }
        }
      }
    }
    return { id: tool.id, installed: false, version: null, status: 'not-installed',
      installDir: selectedPlan.installDir, binDir: selectedPlan.binDir,
      detail: `未在所选安装目录 ${selectedPlan.binDir} 中找到官方命令。` }
  }
  if (tool.id === 'minimax-code' && IS_WINDOWS && !usesConfiguredInstallPlan(tool.id, selectedPreferences)) {
    // The official Windows installer keeps mcode under a versioned releases
    // directory. A partial npm install can leave a broken shim earlier on PATH;
    // prefer the checksum-verified installer release in that case.
    const { findManagedMiniMaxEntry } = await import('./official-tool-executor.mjs')
    const managed = await findManagedMiniMaxEntry(process.cwd())
    if (managed) return { id: tool.id, installed: true, version: managed.version,
      status: 'installed', detail: '已按官方 npm registry 摘要核验 MiniMax 官方 Windows 安装器中的 CLI 文件。',
      installDir: managed.installDir, binDir: managed.installDir,
      bannerLine: `MiniMax Code ${managed.version}` }
  }
  for (const executable of tool.probeExecutables) {
    // Existence check first: a missing command is indistinguishable from a
    // broken one by exit code alone once a shell is involved.
    const located = await runner(LOCATOR, [executable], { timeoutMs: PROBE_TIMEOUT_MS })
    if (located.timedOut) {
      return { id: tool.id, installed: false, version: null, status: 'probe-timeout', detail: `定位 ${executable} 超时（${PROBE_TIMEOUT_MS / 1000}s）` }
    }
    if (!located.ok || !located.stdout.trim()) {
      continue
    }
    const attempt = await runner(executable, ['--version'], { timeoutMs: PROBE_TIMEOUT_MS, useShell: IS_WINDOWS })
    if (attempt.timedOut) {
      return { id: tool.id, installed: false, version: null, status: 'probe-timeout', detail: `${executable} --version 超时（${PROBE_TIMEOUT_MS / 1000}s）` }
    }
    const attempts = [{ ...attempt, executablePath: locatorPaths(located.stdout)[0] }]
    if (!versionFromBanner(probeBanner(attempt))) {
      for (const target of locatorPaths(located.stdout)) {
        if (target === executable) continue
        const direct = await runner(target, ['--version'], { timeoutMs: PROBE_TIMEOUT_MS, useShell: false })
        attempts.push({ ...direct, executablePath: target })
        if (direct.timedOut) break
        if (direct.ok || versionFromBanner(probeBanner(direct))) break
      }
    }
    const chosen = attempts.find(item => item && (item.ok || versionFromBanner(probeBanner(item)))) ?? attempt
    const banner = probeBanner(chosen)
    const version = versionFromBanner(banner)
    if (chosen.ok || version) {
      return {
        id: tool.id,
        installed: true,
        version,
        status: 'installed',
        detail: tool.probeNote ?? '',
        executablePath: chosen.executablePath,
        bannerLine: banner.split('\n').find(Boolean)?.slice(0, 200) ?? '',
      }
    }
    return {
      id: tool.id,
      installed: false,
      version: null,
      status: 'probe-failed',
      detail: `${executable} --version 退出码 ${chosen.code ?? '信号终止'}；程序可能损坏或版本过旧。${String(chosen.stderr ?? '').split('\n').find(Boolean)?.slice(0, 120) ?? ''}`,
    }
  }
  return { id: tool.id, installed: false, version: null, status: 'not-installed', detail: '未在 PATH 中找到官方命令。' }
}

/** Default runner: real spawn with the platform's shell for .cmd shims. */
export const defaultRunner = (executable, args, options = {}) =>
  runCapture(executable, args, { useShell: IS_WINDOWS, ...options })

let prefixPromise = null

/** Add one directory to this process's PATH unless it is already there. */
export function appendToProcessPath(directory, { prepend = false, env = process.env, platform = process.platform } = {}) {
  const target = String(directory ?? '').trim()
  const paths = platform === 'win32' ? win32 : posix
  if (!target || !paths.isAbsolute(target)) return
  const separator = platform === 'win32' ? ';' : ':'
  const key = Object.keys(env).find(name => name.toUpperCase() === 'PATH') ?? 'PATH'
  const parts = String(env[key] ?? '').split(separator).filter(Boolean)
  const equal = entry => platform === 'win32' ? entry.toLowerCase() === target.toLowerCase() : entry === target
  if (!prepend && parts.some(equal)) return
  const remaining = parts.filter(entry => !equal(entry))
  env[key] = (prepend ? [target, ...remaining] : [...remaining, target]).join(separator)
}

/**
 * Users frequently move the npm global prefix off the default location (for
 * example to save C-drive space), so globally installed CLIs are missing from
 * PATH. Resolve the real prefix once and append it — plus the directory the
 * user configured for this plugin — to this process's PATH so probes and
 * installs see the user's actual tools. Best effort: any failure leaves the
 * environment untouched.
 */
export function ensureNpmPrefixOnPath() {
  if (prefixPromise === null) {
    prefixPromise = (async () => {
      try {
        const outcome = await runCapture('npm', ['config', 'get', 'prefix'], {
          timeoutMs: 5_000,
          useShell: IS_WINDOWS,
        })
        if (!outcome.ok) throw new Error('npm prefix is unavailable')
        let prefix = outcome.stdout.trim()
        if (!prefix) throw new Error('npm prefix is empty')
        if (prefix.startsWith('\\\\?\\')) prefix = prefix.slice(4)
        if (IS_WINDOWS && !process.env.GROK_HOME && /^[D-Z]:[\\/]/i.test(prefix)) {
          // Grok's npm bootstrap otherwise expands its native binary under
          // the Windows user profile on C. Keep plugin-managed downloads on
          // the same non-C drive as this user's npm global prefix.
          process.env.GROK_HOME = join(prefix, '.model-router-grok')
        }
        appendToProcessPath(IS_WINDOWS ? prefix : join(prefix, 'bin'))
      } catch { /* environment stays untouched */ }
      // A --prefix install lands outside the npm prefix, so it needs its own
      // PATH entry or every later probe reports the tool as missing.
      for (const tool of OFFICIAL_TOOLS) {
        for (const directory of preferredToolDirectories(tool.id)) {
          try { appendToProcessPath(directory, { prepend: Boolean(preferences.installDir || preferences.methods[tool.id]) }) } catch { /* environment stays untouched */ }
        }
      }
    })()
  }
  return prefixPromise
}

/** Probe every registry tool and return the ids whose CLI is installed. */
export async function installedToolIds() {
  await ensureNpmPrefixOnPath()
  const probes = await probeAllTools()
  return probes.filter(probe => probe.installed).map(probe => probe.id)
}

/**
 * Probe every registry tool in parallel (the slowest single probe bounds the
 * wall time; the cache keeps repeat calls instant).
 */
/** One tool's probe failure must not reject detection of the rest of the page. */
export async function probeToolSafely(tool, runner, options) {
  try {
    return await probeToolWith(tool, runner, options)
  } catch (error) {
    return {
      id: tool.id,
      installed: false,
      version: null,
      status: 'probe-failed',
      detail: `检测失败：${String(error?.message ?? error).slice(0, 200)}`,
    }
  }
}

export async function probeAllTools({ fresh = false, preferences: selectedPreferences = installPreferences() } = {}) {
  await ensureNpmPrefixOnPath()
  return Promise.all(OFFICIAL_TOOLS.map(tool => probeToolSafely(tool, defaultRunner,
    { preferences: selectedPreferences, ...(fresh ? { cacheMs: 0 } : {}) })))
}

function probeBanner(attempt) {
  return `${attempt?.stdout ?? ''}\n${attempt?.stderr ?? ''}`.trim()
}

export function probeSnapshot() {
  return [...probeCache.values()].map(entry => entry.value)
}

function jobView(job) {
  if (!job) return null
  return {
    tool: job.tool.id,
    operation: job.operation,
    methodId: job.methodId,
    installDir: job.installDir,
    command: job.command,
    status: job.status,
    phase: job.phase,
    cancelRequested: job.cancelRequested,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt,
    exitCode: job.exitCode,
    timedOut: job.timedOut,
    error: job.error,
    executionReadiness: job.executionReadiness ?? null,
    outputTail: [...job.outputTail],
    outputTruncated: job.outputTruncated,
    postInstallProbe: job.postInstallProbe,
  }
}

function pushLine(job, line) {
  if (job.outputTail.length >= OUTPUT_LINE_CAP) {
    job.outputTail.shift()
    job.outputTruncated = true
  }
  job.outputTail.push(line)
}

/** Bind a mutating package-manager job to the directory its command will write. */
export async function resolvePackageJobPlan(tool, plan, selectedPreferences, {
  operation = 'install', runner = defaultRunner, options = currentInstallOptions(), signal,
} = {}) {
  if (plan?.kind !== 'package-manager' || plan.installDir) return plan
  const readDirectory = async args => {
    const outcome = await runner(plan.manager, args, {
      timeoutMs: PROBE_TIMEOUT_MS, useShell: options.platform === 'win32', signal,
    })
    if (!outcome.ok || outcome.timedOut || outcome.cancelled) throw new Error('query failed')
    const raw = String(outcome.stdout ?? '').trim().replace(/^\\\\\?\\/, '')
    const directory = expandInstallDir(raw, options)
    if (!directory || /[\r\n]/.test(directory)) throw new Error('invalid directory')
    return directory.replace(/[\\/]+$/, '')
  }
  if (plan.manager === 'pnpm') {
    try {
      const [binDir, moduleRoot] = await Promise.all([readDirectory(['bin', '-g']), readDirectory(['root', '-g'])])
      const layout = /^(.*)[\\/]\d+[\\/]node_modules$/.exec(moduleRoot)
      if (!layout || !layout[1]) throw new Error('unsupported global layout')
      const globalDir = expandInstallDir(layout[1], options)
      return { ...plan, binDir, installDir: '', globalDir, packageModuleRoots: [moduleRoot],
        args: [...plan.args, `--config.global-dir=${globalDir}`, `--config.global-bin-dir=${binDir}`] }
    } catch {
      throw new Error('无法安全绑定 pnpm 默认全局包目录与命令目录，已停止操作；请检查 pnpm 或在官方工具设置中配置统一安装目录。')
    }
  }
  if (plan.manager !== 'npm') throw new Error('此包管理器的默认安装目录无法安全绑定，请配置统一安装目录。')
  let prefix
  try { prefix = await readDirectory(['config', 'get', 'prefix']) } catch {
    throw new Error('无法读取有效的 npm 默认全局安装目录，已停止操作；请检查 npm 或配置统一安装目录。')
  }
  const targetPreferences = { ...selectedPreferences, installDir: prefix }
  return operation === 'uninstall'
    ? resolveUninstallPlan(tool, plan.methodId, targetPreferences, options)
    : resolveInstallPlan(tool, plan.methodId, targetPreferences, options)
}

/** Reserve the single per-tool job slot and serialise against every other tool. */
function beginJob(tool, { operation, methodId, command, installDir = '', plan, configured = false, run }) {
  const existing = installJobs.get(tool.id)
  if (existing?.status === 'running') throw new Error(`${tool.label} 已有${operation === 'uninstall' ? '卸载' : '安装'}任务正在执行。`)
  const job = {
    tool,
    operation,
    methodId,
    command,
    installDir,
    plan,
    preferences: installPreferences(),
    configured: configured || plan?.kind === 'package-manager',
    status: 'running',
    phase: 'queued',
    cancelRequested: false,
    controller: new AbortController(),
    startedAt: new Date().toISOString(),
    finishedAt: null,
    exitCode: null,
    timedOut: false,
    error: null,
    outputTail: [`$ ${command}`],
    outputTruncated: false,
    postInstallProbe: null,
  }
  installJobs.set(tool.id, job)
  probeCache.delete(tool.id)
  installChain = installChain.then(async () => {
    if (job.status !== 'running') return
    if (job.plan?.kind === 'package-manager') {
      job.phase = 'preflight'
      const target = await resolvePackageJobPlan(job.tool, job.plan, job.preferences, {
        operation: job.operation, signal: job.controller.signal,
      })
      if (job.cancelRequested) { markCancelled(job); return }
      job.plan = target
      job.installDir = target.installDir || target.globalDir || target.binDir
      const resolvedCommand = planCommandLine(target, job.operation)
      const command = job.operation === 'repair' ? `修复：${resolvedCommand}` : resolvedCommand
      if (job.command !== command) {
        job.command = command
        pushLine(job, `— 本次操作目录：${job.installDir} —`)
        pushLine(job, `$ ${job.command}`)
      }
    }
    return run(job)
  }).catch(error => {
    if (job.status !== 'running') return
    if (job.cancelRequested || job.controller.signal.aborted) { markCancelled(job); return }
    job.status = 'failed'
    job.finishedAt = new Date().toISOString()
    job.error = `${operation === 'uninstall' ? '卸载' : '安装'}流程失败：${String(error?.message ?? error).slice(0, 200)}`
  })
  return jobView(job)
}

/** One-line summary of a resolved plan, for the job log and the UI. */
export function planCommandLine(plan, operation = 'install') {
  if (plan.kind === 'archive') return operation === 'uninstall'
    ? `删除插件安装的 ZCode CLI 运行目录 ${plan.installDir}（保留配置与会话）`
    : `下载 Alice-Marx/zcode-cli 最新 GitHub Release，校验 SHA256 并安装到 ${plan.installDir}`
  if (plan.kind === 'script') {
    const quote = value => `'${String(value).replace(/'/g, plan.shell === 'powershell' ? "''" : "'\\''")}'`
    const environment = Object.entries(plan.env ?? {}).map(([name, value]) => plan.shell === 'powershell'
      ? `$env:${name}=${quote(value)}; ` : `${name}=${quote(value)} `).join('')
    const directoryArgs = plan.installDir && plan.installArg?.length ? ` ${plan.installArg.join(' ')} ${quote(plan.installDir)}` : ''
    const extraArgs = plan.extraArgs?.length ? ` ${plan.extraArgs.map(arg => /^-{1,2}[A-Za-z][\w-]*$/.test(arg) ? arg : quote(arg)).join(' ')}` : ''
    const scriptArgs = directoryArgs + extraArgs
    const piped = plan.shell === 'powershell'
      ? `${environment}irm ${plan.scriptUrl} | iex`
      : `curl -fsSL ${plan.scriptUrl} | ${environment}${plan.shell === 'sh' ? 'sh' : 'bash'}${scriptArgs ? ` -s --${scriptArgs}` : ''}`
    return operation === 'uninstall'
      ? `删除 ${plan.dir} 下的 ${(plan.binaries ?? []).join('、') || '可执行文件'}`
      : plan.shell === 'powershell' && scriptArgs
        ? `${environment}& ([scriptblock]::Create((irm ${plan.scriptUrl})))${scriptArgs}` : piped
  }
  return `${plan.manager} ${plan.args.map(arg => /\s/.test(arg) ? JSON.stringify(arg) : arg).join(' ')}`
}

/**
 * Start the fixed install for one registry tool id. `method` names one of that
 * tool's declared install methods; the default comes from the user's settings
 * and then from the registry. Returns the job snapshot synchronously; poll
 * installStatus until status is succeeded/failed.
 */
export function startInstall(toolId, { method } = {}) {
  const tool = getOfficialTool(toolId)
  if (!tool) throw new Error(`未知工具：${toolId}。只允许安装注册表中的官方工具。`)
  if (tool.unsupported) throw new Error(tool.unsupportedReason)
  const plan = resolveInstallPlan(tool, method, preferences, currentInstallOptions())
  return beginJob(tool, {
    operation: 'install',
    methodId: plan.methodId,
    command: planCommandLine(plan),
    installDir: plan.installDir ?? '',
    plan,
    configured: usesConfiguredInstallPlan(tool.id, preferences, method),
    run: job => (plan.kind === 'archive' ? runZCodeInstallJob(job) : plan.kind === 'script'
      ? runVendorScriptInstallJob(job, plan)
      : runInstallJob(job.plan, job)),
  })
}

/** Reinstall the tool even when it is already the latest release. */
export function startRepair(toolId, { method } = {}) {
  const tool = getOfficialTool(toolId)
  if (!tool) throw new Error(`未知工具：${toolId}。`)
  const plan = resolveInstallPlan(tool, method, preferences, currentInstallOptions())
  return beginJob(tool, {
    operation: 'repair',
    methodId: plan.methodId,
    command: `修复：${planCommandLine(plan)}`,
    installDir: plan.installDir ?? '',
    plan,
    configured: usesConfiguredInstallPlan(tool.id, preferences, method),
    run: async job => {
      job.repair = true
      if (plan.kind === 'archive') return runZCodeInstallJob(job)
      if (plan.kind === 'script') return runVendorScriptInstallJob(job, plan)
      return runInstallJob(job.plan, job)
    },
  })
}

/**
 * Remove one tool: through its package manager, or by deleting the single file
 * the vendor installer placed. Configuration and credentials are never touched.
 */
export function startUninstall(toolId, { method } = {}) {
  const tool = getOfficialTool(toolId)
  if (!tool) throw new Error(`未知工具：${toolId}。只允许卸载注册表中的官方工具。`)
  const plan = resolveUninstallPlan(tool, method, preferences, currentInstallOptions())
  return beginJob(tool, {
    operation: 'uninstall',
    methodId: plan.methodId,
    command: planCommandLine(plan, 'uninstall'),
    installDir: plan.dir ?? plan.installDir ?? '',
    plan,
    configured: usesConfiguredInstallPlan(tool.id, preferences, method),
    run: job => (plan.kind === 'archive' ? runZCodeUninstallJob(job) : plan.kind === 'script'
      ? runVendorScriptUninstallJob(job, plan)
      : runPackageManagerUninstallJob(job, job.plan)),
  })
}

async function runPackageManagerUninstallJob(job, plan) {
  if (job.status !== 'running') return
  try {
    job.phase = 'preflight'
    await ensureNpmPrefixOnPath()
    const before = await probeToolWith(job.tool, defaultRunner, { plan, preferences: job.preferences, cacheMs: 0 })
    if (job.cancelRequested) { markCancelled(job); return }
    if (!before.installed) {
      job.status = 'succeeded'
      job.finishedAt = new Date().toISOString()
      job.postInstallProbe = before
      pushLine(job, `— ${job.tool.label} 本就未安装，无需卸载 —`)
      return
    }
    job.phase = 'uninstalling'
    const outcome = await runCapture(plan.manager, plan.args, {
      timeoutMs: UNINSTALL_TIMEOUT_MS,
      useShell: IS_WINDOWS,
      signal: job.controller.signal,
      onOutput: captureLines(job),
      env: installEnvironment(plan),
    })
    if (outcome.cancelled || job.cancelRequested) { markCancelled(job); return }
    job.exitCode = outcome.code
    job.timedOut = outcome.timedOut
    if (!outcome.ok) {
      throw new Error(outcome.timedOut ? '卸载超时并已终止。'
        : `卸载命令失败（退出码 ${outcome.code ?? '信号终止'}）。${String(outcome.stderr ?? '').split('\n').find(Boolean)?.slice(0, 200) ?? ''}`)
    }
    job.phase = 'verifying'
    probeCache.delete(job.tool.id)
    const probe = await probeToolWith(job.tool, defaultRunner, { cacheMs: 0, preferences: job.preferences, plan })
    job.postInstallProbe = probe
    job.status = 'succeeded'
    job.finishedAt = new Date().toISOString()
    if (probe.installed) {
      job.error = `${plan.manager} 已卸载 ${job.tool.label}，但 PATH 上仍有另一份；请检查其他安装来源。`
    } else {
      pushLine(job, `— 已卸载 ${job.tool.label}，PATH 上已找不到 ${job.tool.probeExecutables?.[0] ?? ''} —`)
    }
  } catch (error) {
    if (job.cancelRequested || job.controller.signal.aborted) { markCancelled(job); return }
    job.status = 'failed'
    job.error = `${job.tool.label} 卸载失败：${String(error?.message ?? error).slice(0, 300)}`
    job.finishedAt = new Date().toISOString()
  }
}

function captureLines(job) {
  return chunk => {
    for (const line of String(chunk).split(/\r?\n/)) {
      if (line.trim()) pushLine(job, line.slice(0, 500))
    }
  }
}

/** pnpm requires its global bin directory on PATH even during installation. */
export function installEnvironment(plan, base = process.env) {
  const env = { ...base, ...(plan.env ?? {}) }
  if (plan.binDir) appendToProcessPath(plan.binDir, { prepend: true, env })
  return env
}

/** Installation and version must pass; verify execution only where an adapter supports it. */
export async function finishVerifiedInstall(job, probe, {
  lookupLatest = (tool, selection) => latestVersions.lookup(tool, selection), readinessFor = trustedExecutionReadiness,
} = {}) {
  job.postInstallProbe = probe
  if (job.cancelRequested) { markCancelled(job); return true }
  if (!probe.installed) {
    job.status = 'failed'
    job.finishedAt = new Date().toISOString()
    job.error = `安装命令已完成，但重探测失败：${probe.detail}`
    return true
  }
  const latest = await lookupLatest(job.tool, { plan: job.plan, preferences: job.preferences }).catch(() => null)
  if (latest?.version && versionStillOlder(probe.version, latest.version)) {
    failBecauseStillOlder(job, probe, latest.version)
    return true
  }
  const readiness = await readinessFor(job.tool.id, { preferences: job.preferences, plan: job.plan })
  job.executionReadiness = readiness
  if (job.cancelRequested) { markCancelled(job); return true }
  if (!readiness.ready && readiness.supported !== false) {
    if (IS_WINDOWS && job.tool.id === 'minimax-code' && !job.configured) {
      await runOfficialMiniMaxInstaller(job)
      return true
    }
    job.status = 'failed'
    job.finishedAt = new Date().toISOString()
    job.error = `安装命令和版本探测已成功，但官方执行入口未就绪：${readiness.reason}`
    return true
  }
  job.status = 'succeeded'
  job.error = null
  job.finishedAt = new Date().toISOString()
  pushLine(job, readiness.supported === false
    ? `— 已安装 ${job.tool.label} ${probe.version ?? ''}，版本探测已通过；受限执行未启用：${readiness.reason} —`
    : `— 已安装 ${job.tool.label} ${probe.version ?? ''}，官方执行入口已核验（新版本未经插件测试）—`)
  return true
}

function failBecauseStillOlder(job, probe, latestVersion) {
  job.postInstallProbe = probe
  job.status = 'failed'
  job.finishedAt = new Date().toISOString()
  job.error = staleInstallMessage(job.tool.label, probe?.version, latestVersion)
}

/**
 * Native Claude Code lives outside the npm prefix. `claude update` is the
 * vendor's non-interactive updater; return true when the job is finished.
 */
async function tryClaudeUpdate(job, latestVersion) {
  if (job.cancelRequested) { markCancelled(job); return true }
  pushLine(job, '$ claude update')
  job.phase = 'installing'
  const outcome = await runCapture(job.beforeProbe?.executablePath || 'claude', CLAUDE_UPDATE_ARGS, {
    timeoutMs: CLAUDE_UPDATE_TIMEOUT_MS,
    useShell: IS_WINDOWS,
    signal: job.controller.signal,
    onOutput: captureLines(job),
  })
  if (job.status !== 'running') return true
  if (outcome.cancelled || job.cancelRequested) { markCancelled(job); return true }
  if (!outcome.ok) {
    pushLine(job, `— claude update 未完成（退出码 ${outcome.code ?? '信号终止'}），将继续尝试注册表安装 —`)
    return false
  }
  await ensureNpmPrefixOnPath()
  probeCache.delete(job.tool.id)
  const nativePlan = job.beforeProbe?.executablePath
    ? { ...job.plan, binDir: dirname(job.beforeProbe.executablePath), installDir: dirname(job.beforeProbe.executablePath) }
    : job.plan
  const probe = await probeToolWith(job.tool, defaultRunner, { preferences: job.preferences, plan: nativePlan, cacheMs: 0 })
  if (job.cancelRequested) { markCancelled(job); return true }
  if (latestVersion && versionStillOlder(probe.version, latestVersion)) {
    job.postInstallProbe = probe
    pushLine(job, `— claude update 已结束，但探测到的版本仍是 ${probe.version}，低于 ${latestVersion} —`)
    return false
  }
  return finishVerifiedInstall(job, probe)
}

async function runInstallJob(installPlan, job) {
  let legacyShims = null
  try {
    const { manager, args } = installPlan
    if (job.status !== 'running') return
    job.phase = 'preflight'
    await ensureNpmPrefixOnPath()
    if (job.cancelRequested) { markCancelled(job); return }
    probeCache.delete(job.tool.id)
    const before = await probeToolWith(job.tool, defaultRunner, { plan: installPlan, preferences: job.preferences, cacheMs: 0 })
    job.beforeProbe = before
    if (job.cancelRequested) { markCancelled(job); return }
    let latest = null
    let order = null
    if (before.installed) {
      latest = await latestVersions.lookup(job.tool, { fresh: true, plan: job.plan, preferences: job.preferences }).catch(() => null)
      if (job.cancelRequested) { markCancelled(job); return }
      order = latest?.version ? compareReleaseVersions(before.version, latest.version) : null
      if (order === 1) {
        job.status = 'failed'
        job.finishedAt = new Date().toISOString()
        job.postInstallProbe = before
        job.error = `已安装 ${before.version}，高于 npm 最新正式版 ${latest.version}；不会自动降级。`
        return
      }
      if (order === 0) {
        const readiness = await trustedExecutionReadiness(job.tool.id, { preferences: job.preferences, plan: job.plan })
        if (job.cancelRequested) { markCancelled(job); return }
        // A repair re-runs the same command even when nothing looks stale: a
        // broken install reports the right version, so "already current" is
        // exactly the case the user pressed 修复 for.
        if (job.repair) {
          pushLine(job, `— ${job.tool.label} ${before.version} 已是最新版本，按修复流程重新安装 —`)
        } else if (readiness.ready || readiness.supported === false || !CAPABILITY_REPAIRABLE.has(job.tool.id)) {
          job.status = 'succeeded'
          job.finishedAt = new Date().toISOString()
          job.postInstallProbe = before
          job.executionReadiness = readiness
          pushLine(job, `— ${job.tool.label} ${before.version} 已是最新版本，无需重复安装 —`)
          if (readiness.supported === false) pushLine(job, `— 受限执行未启用：${readiness.reason} —`)
          return
        } else {
          pushLine(job, `— 已是最新版本 ${before.version}，但执行入口未就绪：${readiness.reason}；重新安装修复 —`)
        }
      }
    }
    const plan = officialUpdatePlan({
      toolId: job.tool.id,
      installed: before.installed === true,
      order,
      platform: process.platform,
      configured: job.configured,
    })
    let triedClaudeUpdate = false
    if (plan === 'claude-update-then-registry') {
      triedClaudeUpdate = true
      const finished = await tryClaudeUpdate(job, latest?.version)
      if (finished || job.status !== 'running') return
    } else if (plan === 'minimax-official-installer') {
      await runOfficialMiniMaxInstaller(job, {
        reason: '— 已安装的 MiniMax Code 由官方安装目录接管；直接运行官方 Windows 安装脚本以更新到最新版 —',
      })
      return
    }
    if (installPlan.binDir) await mkdir(installPlan.binDir, { recursive: true })
    job.phase = 'installing'
    if (job.tool.id === 'zcode' && manager === 'npm' && installPlan.kind === 'package-manager') {
      legacyShims = await prepareZCodeNpmShims({ prefix: installPlan.installDir, platform: process.platform, signal: job.controller.signal })
      if (legacyShims.backups.length) pushLine(job, `— 已备份旧 ZCode 桌面启动器：${legacyShims.backupDir}；本次 npm 安装不会使用 --force —`)
    }
    const outcome = await runCapture(manager, args, {
      timeoutMs: INSTALL_TIMEOUT_MS,
      useShell: IS_WINDOWS,
      signal: job.controller.signal,
      onOutput: captureLines(job),
      env: installEnvironment(installPlan),
    })
    if (job.status !== 'running') return
    if (outcome.cancelled || job.cancelRequested) { markCancelled(job); return }
    job.exitCode = outcome.code
    job.timedOut = outcome.timedOut
    if (outcome.timedOut) {
      job.status = 'failed'
      job.finishedAt = new Date().toISOString()
      job.error = `安装超时（${INSTALL_TIMEOUT_MS / 1000}s），已终止。`
      return
    }
    if (!outcome.ok) {
      if (IS_WINDOWS && job.tool.id === 'minimax-code' && !job.configured) {
        await runOfficialMiniMaxInstaller(job)
        return
      }
      job.status = 'failed'
      job.finishedAt = new Date().toISOString()
      job.error = `安装命令失败（退出码 ${outcome.code ?? '信号终止'}）。${outcome.stderr.split('\n').find(Boolean)?.slice(0, 200) ?? ''}`
      return
    }
    job.phase = 'verifying'
    await ensureNpmPrefixOnPath()
    probeCache.delete(job.tool.id)
    const probe = await probeToolWith(job.tool, defaultRunner, { plan: installPlan, preferences: job.preferences, cacheMs: 0 })
    if (job.cancelRequested) { markCancelled(job); return }
    job.postInstallProbe = probe
    const latestAfter = (await latestVersions.lookup(job.tool, { plan: job.plan, preferences: job.preferences }).catch(() => null)) ?? latest
    const stillOlder = Boolean(latestAfter?.version && versionStillOlder(probe.version, latestAfter.version))
    if (stillOlder && job.tool.id === 'claude-code' && !triedClaudeUpdate && !job.configured) {
      triedClaudeUpdate = true
      const finished = await tryClaudeUpdate(job, latestAfter.version)
      if (finished || job.status !== 'running') return
      failBecauseStillOlder(job, job.postInstallProbe ?? probe, latestAfter.version)
      return
    }
    if (stillOlder && IS_WINDOWS && job.tool.id === 'minimax-code' && !job.configured) {
      pushLine(job, `— npm 完成后 ${job.tool.label} 仍是 ${probe.version}，低于最新 ${latestAfter.version}；改用官方安装脚本 —`)
      await runOfficialMiniMaxInstaller(job)
      return
    }
    if (stillOlder) {
      pushLine(job, `— 注意：PATH 上的 ${job.tool.label} 仍是 ${probe.version}，低于最新 ${latestAfter.version} —`)
      failBecauseStillOlder(job, probe, latestAfter.version)
      return
    }
    await finishVerifiedInstall(job, probe)
  } finally {
    if (legacyShims?.backups.length && job.status !== 'succeeded') {
      const restored = await legacyShims.restoreMissing()
      pushLine(job, `— npm 安装未完成，已恢复 ${restored.restored.length} 个缺失的旧启动器；新建文件未覆盖，备份保留于 ${legacyShims.backupDir} —`)
    }
  }
}

export async function runZCodeInstallJob(job, {
  probe = probeToolWith, lookup = (...args) => latestVersions.lookup(...args),
  install = installZCodeCli, finish = finishVerifiedInstall,
} = {}) {
  if (job.status !== 'running') return
  try {
    job.phase = 'preflight'
    const plan = job.plan ?? resolveInstallPlan(job.tool, job.methodId, job.preferences, currentInstallOptions())
    job.installDir = plan.installDir
    job.plan = plan
    const before = await probe(job.tool, defaultRunner, { preferences: job.preferences, plan, cacheMs: 0 })
    if (job.cancelRequested) { markCancelled(job); return }
    const latest = await lookup(job.tool, { fresh: true, plan, preferences: job.preferences }).catch(() => null)
    if (job.cancelRequested) { markCancelled(job); return }
    const order = before.installed && latest?.version ? compareReleaseVersions(before.version, latest.version) : null
    if (before.installed && (order === null || latest?.stale || latest?.error)) throw new Error('无法核实 ZCode CLI 最新版本；保留当前安装，网络恢复后重试。')
    if (order === 1 || (order === 0 && job.operation !== 'repair')) {
      await finish(job, before, { lookupLatest: async () => latest })
      job.phase = 'done'
      pushLine(job, order === 1 ? `— 已安装 ${before.version} 高于最新 ${latest.version}，不会自动降级 —` : `— ZCode CLI ${before.version} 已是最新版本 —`)
      return
    }
    job.phase = 'downloading-and-verifying'
    pushLine(job, `— 安装目录：${plan.installDir}；来源：Alice-Marx/zcode-cli GitHub Release —`)
    let lastProgress = 0
    await install({ installDir: plan.installDir, latest, signal: job.controller.signal,
      onProgress: ({ receivedBytes }) => { if (receivedBytes - lastProgress >= 25_000_000) { pushLine(job, `已下载 ${Math.round(receivedBytes / 1_000_000)} MB`); lastProgress = receivedBytes } } })
    if (job.cancelRequested) { markCancelled(job); return }
    appendToProcessPath(plan.binDir, { prepend: true })
    job.phase = 'verifying'
    probeCache.delete(job.tool.id)
    const after = await probe(job.tool, defaultRunner, { preferences: job.preferences, plan, cacheMs: 0 })
    if (job.cancelRequested) { markCancelled(job); return }
    await finish(job, after, { lookupLatest: async () => latest })
    job.phase = 'done'
  } catch (error) {
    if (job.cancelRequested || job.controller.signal.aborted) { markCancelled(job); return }
    job.status = 'failed'; job.phase = 'done'; job.finishedAt = new Date().toISOString()
    job.error = `ZCode CLI 安装失败：${String(error?.message ?? error).slice(0, 300)}`
  }
}

async function runZCodeUninstallJob(job) {
  if (job.status !== 'running') return
  job.phase = 'uninstalling'
  await uninstallZCodeCli({ installDir: job.plan.installDir })
  probeCache.delete(job.tool.id)
  job.postInstallProbe = await probeToolWith(job.tool, defaultRunner, { plan: job.plan, preferences: job.preferences, cacheMs: 0 })
  job.status = job.postInstallProbe.installed ? 'failed' : 'succeeded'
  job.phase = 'done'; job.finishedAt = new Date().toISOString()
  if (job.status === 'failed') job.error = 'ZCode CLI 卸载后的目录探测仍显示已安装。'
  else pushLine(job, '— 已卸载插件安装的 ZCode CLI 运行目录；配置与会话保留原位置 —')
}

function markCancelled(job) {
  const uninstalling = job.operation === 'uninstall'
  job.status = 'cancelled'
  job.phase = 'done'
  job.finishedAt = new Date().toISOString()
  job.error = uninstalling
    ? '已取消卸载。若删除已经开始，请重新检测实际状态。'
    : '已取消安装。若包管理器已开始写入，可能需要重新检测或修复该工具。'
  probeCache.delete(job.tool.id)
  pushLine(job, uninstalling ? '— 卸载已取消；请重新检测实际状态 —' : '— 安装已取消；请重新检测实际状态 —')
}

/** Cancel a queued or running install; cancellation is reflected after its process exits. */
export function cancelInstall(toolId) {
  const tool = getOfficialTool(toolId)
  if (!tool) throw new Error(`未知工具：${toolId}。`)
  const job = installJobs.get(tool.id)
  if (!job || job.status !== 'running') throw new Error(`${tool.label} 当前没有进行中的安装任务。`)
  if (!job.cancelRequested) {
    job.cancelRequested = true
    job.controller.abort()
    if (job.phase === 'queued') markCancelled(job)
  }
  return jobView(job)
}

export function installStatus(toolId) {
  const job = installJobs.get(String(toolId ?? '').trim())
  return job ? jobView(job) : null
}

/** Plan-side projection: whether each provider can run through an installed CLI. */
export async function executionChannels(providers) {
  const unique = [...new Set(providers.filter(Boolean))]
  await Promise.all(unique.map(provider => {
    const tool = OFFICIAL_TOOLS.find(entry => !entry.unsupported
      && entry.providerHints.some(hint => provider.toLowerCase().includes(hint)))
    return tool ? probeToolWith(tool, defaultRunner) : Promise.resolve(null)
  }))
  const resolved = new Map()
  for (const provider of unique) {
    const tool = OFFICIAL_TOOLS.find(entry => !entry.unsupported
      && entry.providerHints.some(hint => provider.toLowerCase().includes(hint)))
    if (!tool) {
      resolved.set(provider, { kind: 'harness-llm', detail: '通过官方模型目录 API 调用。' })
      continue
    }
    const probe = await probeToolWith(tool, defaultRunner)
    resolved.set(provider, probe.installed
      ? { kind: 'harness-llm', tool: tool.id, label: tool.label, version: probe.version, detail: 'CLI 已安装；执行入口仍须单独核验，当前使用官方模型目录 API。' }
      : { kind: 'harness-llm', tool: tool.id, label: tool.label, detail: `${tool.label} 未安装；将使用官方模型目录 API 调用。可在会话中运行 /tools install ${tool.id} 安装。` })
  }
  return resolved
}

/** Test-only: drop caches, jobs and any preferences a previous test left behind. */
export function resetForTests() {
  probeCache.clear()
  installJobs.clear()
  installChain = Promise.resolve()
  prefixPromise = null
  preferences = { installDir: '', registry: '', methods: {}, scriptUrls: {}, allowScriptInstall: true }
}
