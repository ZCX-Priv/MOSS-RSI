/**
 * Pure run-ledger logic shared by the Host and the Desktop panel: actual cost
 * from reported token usage, daily/monthly spending, budget decisions, and
 * gentle routing adjustments from user ratings and reviews.
 */

import { reasoningExecutionFields, unsupportedCliReasoning } from './reasoning-execution.mjs'
import { packageSelectionFields } from './package-assignments.mjs'
import { archiveSubscriptionUsage, sanitizeArchivedSubscriptionUsage, sanitizeSubscriptionAttempts } from './subscription-usage.mjs'

export const MAX_STORED_ANSWER = 4_000
export const MAX_STORED_TASK = 20_000
/** Ratings move a route's quality by at most this much (quality is 0–1). */
export const MAX_QUALITY_BIAS = 0.04

const finite = value => typeof value === 'number' && Number.isFinite(value)
const receiptTimestamp = value => finite(value) && value >= 0 && Number.isFinite(new Date(value).getTime())
const nonEmptyText = value => (typeof value === 'string' && value.length > 0 ? value : null)
const routeKey = (provider, model) => `${String(provider ?? '')}\u0000${String(model ?? '')}`

function modelIdentity(value) {
  if (typeof value === 'string' && value.trim()) return value.trim()
  if (value && typeof value === 'object' && !Array.isArray(value)
    && typeof value.providerId === 'string' && value.providerId
    && typeof value.modelId === 'string' && value.modelId) return `${value.providerId}/${value.modelId}`
  return null
}

// A stop marker belongs to one attempt, not to earlier requests in a cascade.
// Contradictory positive/invalid counters remain potentially paid evidence.
function clearlyNotStarted(attempt) {
  if (!attempt || typeof attempt !== 'object' || (attempt.notStarted !== true && attempt.blocked !== true)) return false
  if (Object.hasOwn(attempt, 'reportedCostUsd') && attempt.reportedCostUsd !== undefined
    && attempt.reportedCostUsd !== null && attempt.reportedCostUsd !== 0) return false
  return !['inputTokens', 'outputTokens', 'cacheReadTokens', 'cacheWriteTokens'].some(key => {
    const value = attempt.usage?.[key]
    return value !== undefined && value !== null && value !== 0
  })
}

/** True when some quality attempt ran, or execution cannot safely be ruled out. */
export function hasStartedQualityAttempts(result) {
  if (!result || !Object.hasOwn(result, 'qualityAttempts')) return false
  const attempts = result.qualityAttempts
  if (!Array.isArray(attempts) || attempts.length < 1 || attempts.length > 2) return true
  return attempts.some(attempt => !clearlyNotStarted(attempt))
}

/** USD cost of one package. Prefers a CLI-reported cost, else usage × configured price. */
export function actualCost(result, pricing) {
  if (result && Object.hasOwn(result, 'qualityAttempts')) {
    const attempts = result.qualityAttempts
    if (!Array.isArray(attempts) || attempts.length < 1 || attempts.length > 2
      || attempts.some(item => !item || typeof item !== 'object' || Object.hasOwn(item, 'qualityAttempts')
        || item.channel === 'official-cli' || item.billing === 'subscription')) {
      return { costUsd: null, costSource: 'quality-attempts-invalid' }
    }
    const costs = attempts.map(item => clearlyNotStarted(item)
      ? { costUsd: 0, costSource: 'not-run' }
      : actualCost(item, item.pricingSnapshot ?? null))
    if (costs.some(item => item.costUsd === null)) {
      const knownCostUsd = costs.filter(item => item.costUsd !== null).reduce((sum, item) => sum + item.costUsd, 0)
      return finite(knownCostUsd) ? { costUsd: null, costSource: 'quality-attempts-incomplete', knownCostUsd,
        unknownAttemptCount: costs.filter(item => item.costUsd === null).length }
        : { costUsd: null, costSource: 'cost-invalid' }
    }
    const total = costs.reduce((sum, item) => sum + item.costUsd, 0)
    return finite(total) && total >= 0 ? { costUsd: total, costSource: 'quality-attempts' }
      : { costUsd: null, costSource: 'cost-invalid' }
  }
  if (result && Object.hasOwn(result, 'reportedCostUsd') && finite(result.reportedCostUsd) && result.reportedCostUsd >= 0) {
    return { costUsd: result.reportedCostUsd, costSource: 'cli-reported' }
  }
  const usage = result && Object.hasOwn(result, 'usage') ? result.usage : null
  if (usage && result.usageIncomplete === true) return { costUsd: null, costSource: 'usage-incomplete' }
  if (usage && result.channel === 'official-cli') {
    const actualModel = modelIdentity(result.actualModel) ?? modelIdentity(result.reportedModel)
    if (!actualModel) return { costUsd: null, costSource: 'model-unknown' }
    const pricedModel = pricing?.model ?? result.model
    const provider = pricing?.provider ?? result.provider
    const matches = [pricedModel, pricing?.cliModel, provider && pricedModel ? `${provider}/${pricedModel}` : null]
      .some(value => typeof value === 'string' && value === actualModel)
    if (!matches) return { costUsd: null, costSource: 'model-price-unverified' }
  }
  if (!usage || !pricing || !Object.hasOwn(pricing, 'input') || !Object.hasOwn(pricing, 'output')
    || pricing.input === undefined || pricing.input === null || pricing.output === undefined || pricing.output === null) {
    return { costUsd: null, costSource: usage ? 'price-missing' : 'usage-missing' }
  }
  const nonnegative = value => finite(value) && value >= 0
  if (typeof pricing !== 'object' || Array.isArray(pricing)
    || !nonnegative(pricing.input) || !nonnegative(pricing.output)
    || ['cacheRead', 'cacheWrite'].some(key => Object.hasOwn(pricing, key) && pricing[key] !== undefined && !nonnegative(pricing[key]))) {
    return { costUsd: null, costSource: 'price-invalid' }
  }
  if (typeof usage !== 'object' || Array.isArray(usage)) return { costUsd: null, costSource: 'usage-invalid' }
  if (!Object.hasOwn(usage, 'inputTokens') || !Object.hasOwn(usage, 'outputTokens')
    || usage.inputTokens === undefined || usage.inputTokens === null || usage.outputTokens === undefined || usage.outputTokens === null) {
    return { costUsd: null, costSource: 'usage-missing' }
  }
  if (['inputTokens', 'outputTokens'].some(key => !nonnegative(usage[key]))
    || ['cacheReadTokens', 'cacheWriteTokens'].some(key => Object.hasOwn(usage, key) && usage[key] !== undefined && !nonnegative(usage[key]))) {
    return { costUsd: null, costSource: 'usage-invalid' }
  }
  const input = usage.inputTokens
  const output = usage.outputTokens
  const cacheRead = Object.hasOwn(usage, 'cacheReadTokens') ? usage.cacheReadTokens ?? 0 : 0
  const cacheWrite = Object.hasOwn(usage, 'cacheWriteTokens') ? usage.cacheWriteTokens ?? 0 : 0
  const cacheReadPrice = Object.hasOwn(pricing, 'cacheRead') ? pricing.cacheRead ?? pricing.input : pricing.input
  const cacheWritePrice = Object.hasOwn(pricing, 'cacheWrite') ? pricing.cacheWrite ?? pricing.input : pricing.input
  // Divide each usage counter before multiplication to avoid intermediate
  // overflow for a finite USD result; an actually unrepresentable cost is unknown.
  const costUsd = input / 1_000_000 * pricing.input
    + cacheRead / 1_000_000 * cacheReadPrice
    + cacheWrite / 1_000_000 * cacheWritePrice
    + output / 1_000_000 * pricing.output
  if (!nonnegative(costUsd)) return { costUsd: null, costSource: 'cost-invalid' }
  return { costUsd, costSource: 'usage' }
}

/**
 * Who pays for a package. `api`: an API key or the model-catalog API, counted
 * against budgets. `subscription`: an official CLI on its own account login with
 * no API key injected; its CLI-reported or usage × price figure is only an
 * API-equivalent reference and is not counted against budgets.
 * `loginBilling` comes from the health check ('api-key' when the CLI's own
 * login is an API key). `apiKeyPresent` is for runners that do not report
 * `credentialSource` (the signed team runner inherits vendor key variables).
 */
export function billingOf(result, { loginBilling = null, apiKeyPresent = false } = {}) {
  if (!result || result.blocked) return null
  // The subscription-first executor states the channel it billed explicitly.
  if (result.billing === 'api' || result.billing === 'subscription' || result.billing === 'unknown') return result.billing
  if (result.channel !== 'official-cli') return 'api'
  if (result.credentialSource === 'configured-api-key' || result.credentialSource === 'process-environment') return 'api'
  if (!result.credentialSource && apiKeyPresent) return 'api'
  return loginBilling === 'api-key' ? 'api' : 'subscription'
}

/** Cost fields for storage: subscription runs keep the figure as `referenceCostUsd` only. */
export function billedCost(result, pricing, billing) {
  if (billing === 'unknown') return { costUsd: null, costSource: 'billing-unknown', billing, referenceCostUsd: null }
  const cost = actualCost(result, pricing)
  if (billing !== 'subscription') return { ...cost, billing: billing ?? 'api', referenceCostUsd: null }
  return { costUsd: null, costSource: cost.costSource, billing, referenceCostUsd: cost.costUsd }
}

const pad = value => String(value).padStart(2, '0')
/** Local calendar keys (the Host's time zone, which is the user's machine). */
export const dayKey = at => { const date = new Date(at); return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}` }
export const monthKey = at => { const date = new Date(at); return `${date.getFullYear()}-${pad(date.getMonth() + 1)}` }

/** Detailed history can be evicted without losing the current budget totals. */
export const MAX_SPENDING_DAYS = 90
export const MAX_SPENDING_MONTHS = 24
const emptyPeriodSpending = () => ({ costUsd: 0, unknown: 0, subscriptionUsd: 0, subscriptionRuns: 0 })

function periodSpending(value) {
  const amount = field => finite(value?.[field]) && value[field] >= 0 ? value[field] : 0
  return { costUsd: amount('costUsd'), unknown: Math.floor(amount('unknown')),
    subscriptionUsd: amount('subscriptionUsd'), subscriptionRuns: Math.floor(amount('subscriptionRuns')) }
}

/** Bounded calendar aggregates contain amounts and counts, never tasks or answers. */
export function sanitizeArchivedSpending(value) {
  const periods = (entries, pattern, limit) => Object.fromEntries(Object.entries(entries && typeof entries === 'object' && !Array.isArray(entries) ? entries : {})
    .filter(([key, entry]) => pattern.test(key) && entry && typeof entry === 'object' && !Array.isArray(entry))
    .sort(([left], [right]) => left.localeCompare(right)).slice(-limit)
    .map(([key, entry]) => [key, periodSpending(entry)]))
  return {
    days: periods(value?.days, /^\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])$/, MAX_SPENDING_DAYS),
    months: periods(value?.months, /^\d{4}-(?:0[1-9]|1[0-2])$/, MAX_SPENDING_MONTHS),
  }
}

function addArchivedSpending(target, source) {
  const archive = sanitizeArchivedSpending(source)
  for (const period of ['days', 'months']) {
    for (const [key, amount] of Object.entries(archive[period])) {
      const total = target[period][key] ??= emptyPeriodSpending()
      for (const field of Object.keys(amount)) total[field] += amount[field]
    }
  }
}

function* spendingEntries(runs) {
  for (const run of Array.isArray(runs) ? runs : []) {
    for (const item of [...(Array.isArray(run?.packages) ? run.packages : []), ...(Array.isArray(run?.reviews) ? run.reviews : [])]) {
      if (!item || typeof item !== 'object') continue
      const when = item.finishedAt ?? run.createdAt
      if (!finite(when) || !finite(new Date(when).getTime())) continue
      const amount = emptyPeriodSpending()
      if (item.billing === 'subscription') {
        // A subscription login is reference cost only, never budget spend.
        if (item.ran !== true) continue
        amount.subscriptionRuns = 1
        if (finite(item.referenceCostUsd) && item.referenceCostUsd >= 0) amount.subscriptionUsd = item.referenceCostUsd
      } else if (finite(item.costUsd) && item.costUsd >= 0) amount.costUsd = item.costUsd
      else if (item.ran === true) {
        amount.unknown = 1
        if (finite(item.knownCostUsd) && item.knownCostUsd >= 0) amount.costUsd = item.knownCostUsd
      }
      else continue
      yield { when, amount }
    }
  }
}

/** Fold only evicted records into the archive; retained records are counted live. */
export function archiveSpending(runs, archivedSpending) {
  const archive = sanitizeArchivedSpending(archivedSpending)
  for (const run of Array.isArray(runs) ? runs : []) addArchivedSpending(archive, run?.priorAttemptSpending)
  for (const { when, amount } of spendingEntries(runs)) {
    for (const [periods, key] of [[archive.days, dayKey(when)], [archive.months, monthKey(when)]]) {
      const total = periods[key] ??= emptyPeriodSpending()
      for (const field of Object.keys(amount)) total[field] += amount[field]
    }
  }
  return sanitizeArchivedSpending(archive)
}

/** Recorded spending, including evicted history, for the local day and month. */
export function spending(runs, at = Date.now(), archivedSpending = null) {
  const today = dayKey(at)
  const month = monthKey(at)
  const archive = sanitizeArchivedSpending(archivedSpending)
  for (const run of Array.isArray(runs) ? runs : []) addArchivedSpending(archive, run?.priorAttemptSpending)
  const daily = periodSpending(archive.days[today])
  const monthly = periodSpending(archive.months[month])
  const total = { today: daily.costUsd, month: monthly.costUsd, unknownToday: daily.unknown, unknownMonth: monthly.unknown,
    subscriptionToday: daily.subscriptionUsd, subscriptionMonth: monthly.subscriptionUsd,
    subscriptionRunsToday: daily.subscriptionRuns, subscriptionRunsMonth: monthly.subscriptionRuns }
  for (const { when, amount } of spendingEntries(runs)) {
    if (monthKey(when) !== month) continue
    total.month += amount.costUsd
    total.unknownMonth += amount.unknown
    total.subscriptionMonth += amount.subscriptionUsd
    total.subscriptionRunsMonth += amount.subscriptionRuns
    if (dayKey(when) === today) {
      total.today += amount.costUsd
      total.unknownToday += amount.unknown
      total.subscriptionToday += amount.subscriptionUsd
      total.subscriptionRunsToday += amount.subscriptionRuns
    }
  }
  return total
}

/**
 * Decide whether a run fits the configured limits. A zero limit is off.
 * `estimateUsd` null means prices are missing; only already-exceeded limits block then.
 */
/** USD amounts in budget messages and the workbench: always four decimals, so limits and spend line up. */
export function formatUsd(value) {
  return typeof value === 'number' && Number.isFinite(value) ? `$${value.toFixed(4)}` : '—'
}

export function budgetCheck({ estimateUsd = null, spent = { today: 0, month: 0 }, dailyLimitUsd = 0, monthlyLimitUsd = 0 } = {}) {
  const limits = []
  if (finite(dailyLimitUsd) && dailyLimitUsd > 0) limits.push({ period: 'daily', label: '今日', limit: dailyLimitUsd, spent: spent.today ?? 0 })
  if (finite(monthlyLimitUsd) && monthlyLimitUsd > 0) limits.push({ period: 'monthly', label: '本月', limit: monthlyLimitUsd, spent: spent.month ?? 0 })
  const estimateKnown = finite(estimateUsd)
  const remaining = limits.length ? Math.max(0, Math.min(...limits.map(item => item.limit - item.spent))) : null
  const exceeded = limits.find(item => item.spent >= item.limit || (estimateKnown && item.spent + estimateUsd > item.limit)) ?? null
  return {
    limited: limits.length > 0,
    estimateKnown,
    estimateUsd: estimateKnown ? estimateUsd : null,
    remainingUsd: remaining,
    exceeded: exceeded ? exceeded.period : null,
    message: exceeded
      ? `${exceeded.label}预算 ${formatUsd(exceeded.limit)}，已用 ${formatUsd(exceeded.spent)}${estimateKnown ? `，本次预估 ${formatUsd(estimateUsd)}` : ''}，将超出上限。`
      : limits.length && !estimateKnown ? '部分路线缺少单价，无法预估本次费用；仅在已用金额达到上限时阻止。' : '',
  }
}

/**
 * Per-route quality bias from ratings (+1/-1) and reviews (score 1–5).
 * Bayesian-shrunk toward 0 so a single rating barely moves routing.
 */
export function routeQualityBiases(runs) {
  const tally = new Map()
  for (const run of Array.isArray(runs) ? runs : []) {
    for (const item of run.packages ?? []) {
      const key = routeKey(item.provider, item.model)
      const entry = tally.get(key) ?? { sum: 0, weight: 0, ratings: 0 }
      if (item.rating === 1 || item.rating === -1) { entry.sum += item.rating; entry.weight += 1; entry.ratings += 1 }
      if (finite(item.review?.score)) { entry.sum += 0.5 * ((item.review.score - 3) / 2); entry.weight += 0.5 }
      tally.set(key, entry)
    }
  }
  const biases = {}
  for (const [key, entry] of tally) {
    if (entry.weight === 0) continue
    const bias = MAX_QUALITY_BIAS * entry.sum / (entry.weight + 3)
    biases[key] = Math.max(-MAX_QUALITY_BIAS, Math.min(MAX_QUALITY_BIAS, Number(bias.toFixed(4))))
  }
  return biases
}

/** Attach biases to exact routes; the planner adds them to estimated quality. */
export function applyQualityBiases(routes, biases) {
  if (!biases || typeof biases !== 'object') return routes
  return (Array.isArray(routes) ? routes : []).map(route => {
    const bias = biases[routeKey(route.provider, route.model)]
    return finite(bias) && bias !== 0 ? { ...route, qualityBias: bias } : route
  })
}

function storedPackage(planned, result, pricing, finishedAt, billingFor = billingOf) {
  const plannedEffort = nonEmptyText(planned?.recommendedReasoningEffort) ?? nonEmptyText(planned?.plannedReasoningEffort)
  const startedAttempts = hasStartedQualityAttempts(result)
  const qualityAttempts = Array.isArray(result?.qualityAttempts)
    ? result.qualityAttempts.slice(0, 2).map(attempt => attempt && typeof attempt === 'object' ? attempt : {}) : null
  const cost = !result || ((result.blocked || result.notStarted) && !startedAttempts)
    ? { costUsd: null, costSource: 'not-run', billing: null, referenceCostUsd: null }
    : billedCost(result, pricing, billingFor(result))
  return {
    id: planned.id,
    ...packageSelectionFields(result?.manualAssignment !== undefined ? { ...planned, ...result } : planned),
    name: planned.name,
    objective: String(planned.objective ?? '').slice(0, 2_000),
    ...(planned.type ? { type: String(planned.type) } : {}),
    ...(planned.purpose ? { purpose: String(planned.purpose) } : {}),
    ...(Array.isArray(planned.verificationChecklist) ? { verificationChecklist: planned.verificationChecklist.slice(0, 12).map(point => String(point).slice(0, 300)) } : {}),
    dependsOn: [...(planned.dependsOn ?? [])],
    recommendedProvider: planned.recommendedProvider,
    recommendedModel: planned.recommendedModel,
    ...reasoningExecutionFields(result),
    ...(qualityAttempts ? { qualityAttempts: qualityAttempts.map(attempt => ({
      provider: attempt.provider, model: attempt.model, channel: 'harness-llm',
      ok: attempt.ok === true, usage: attempt.usage ?? null,
      ...(attempt.notStarted === true ? { notStarted: true } : {}),
      ...(attempt.blocked === true ? { blocked: true } : {}),
      ...(attempt.usageIncomplete ? { usageIncomplete: true } : {}),
      ...(finite(attempt.reportedCostUsd) && attempt.reportedCostUsd >= 0 ? { reportedCostUsd: attempt.reportedCostUsd } : {}),
      pricingSnapshot: attempt.pricingSnapshot ? { ...attempt.pricingSnapshot } : null,
      ...reasoningExecutionFields(attempt),
      ...(finite(attempt.durationMs) ? { durationMs: attempt.durationMs } : {}),
      ...(finite(attempt.inputChars) ? { inputChars: attempt.inputChars } : {}),
      finishedAt: attempt.finishedAt, error: typeof attempt.error === 'string' ? attempt.error.slice(0, 1_000) : null,
    })) } : {}),
    ...(result?.qualityValidation ? { qualityValidation: { ...result.qualityValidation } } : {}),
    ...(plannedEffort ? { plannedReasoningEffort: plannedEffort } : {}),
    ...(finite(result?.durationMs) && result.durationMs >= 0 ? { durationMs: result.durationMs } : {}),
    ...(finite(result?.inputChars) && result.inputChars >= 0 ? { inputChars: result.inputChars } : {}),
    difficulty: planned.difficulty ?? null,
    estimatedCost: finite(planned.estimatedCost) ? planned.estimatedCost : null,
    plannedChannel: planned.executionChannel ?? null,
    provider: result?.provider ?? planned.recommendedProvider,
    model: result?.model ?? planned.recommendedModel,
    status: !result ? 'pending' : result.ok ? (result.fallback ? 'fallback' : 'succeeded') : result.paused ? 'paused'
      : result.waiting ? 'waiting' : result.blocked ? 'blocked' : result.cancelled ? 'cancelled' : 'failed',
    ok: result?.ok === true,
    ran: Boolean(result) && (startedAttempts || (!result.blocked && !result.notStarted)),
    blocked: result?.blocked === true,
    ...(result?.paused ? { paused: true, pause: { ...result.pause } } : {}),
    ...(result?.waiting ? { waiting: true } : {}),
    reassigned: result?.reassigned === true,
    channel: result?.channel ?? null,
    toolId: result?.toolId ?? null,
    credentialSource: result?.credentialSource ?? null,
    ...(result?.channel === 'official-cli' ? {
      requestedCliModel: result.requestedCliModel ?? null,
      actualModel: modelIdentity(result.actualModel) ?? modelIdentity(result.reportedModel),
      modelNotice: result.modelNotice ?? null,
    } : {}),
    ...(result?.channel !== 'official-cli' && result?.actualModel ? { actualModel: String(result.actualModel) } : {}),
    ...(result?.reportedModel !== undefined ? { reportedModel: result.reportedModel } : {}),
    ...(typeof result?.source === 'string' ? { source: result.source } : {}),
    ...(typeof result?.sandboxEnforcement === 'string' ? { sandboxEnforcement: result.sandboxEnforcement } : {}),
    ...(result?.usageIncomplete === true ? { usageIncomplete: true } : {}),
    ...(typeof result?.executionEnvironment === 'string' ? { executionEnvironment: result.executionEnvironment } : {}),
    ...(finite(result?.reportedCostUsd) && result.reportedCostUsd >= 0 ? { reportedCostUsd: result.reportedCostUsd } : {}),
    fallback: result?.fallback ?? null,
    ...(result?.billingMode ? { billingMode: String(result.billingMode) } : {}),
    ...(result?.billingSwitch ? { billingSwitch: { ...result.billingSwitch } } : {}),
    ...(result?.subscriptionRoute ? { subscriptionRoute: { provider: String(result.subscriptionRoute.provider ?? ''), model: String(result.subscriptionRoute.model ?? '') } } : {}),
    ...(result?.subscriptionAttempts !== undefined ? { subscriptionAttempts: sanitizeSubscriptionAttempts(result.subscriptionAttempts) } : {}),
    error: result?.ok ? null : (result?.error ?? null),
    ...(!result?.ok && result?.diagnostic ? { diagnostic: String(result.diagnostic).slice(0, 2_000) } : {}),
    ...(Number.isInteger(result?.exitCode) ? { exitCode: result.exitCode } : {}),
    answer: String(result?.answer ?? '').slice(0, MAX_STORED_ANSWER),
    answerTruncated: String(result?.answer ?? '').length > MAX_STORED_ANSWER,
    usage: result?.usage ?? null,
    // Freeze the rates used for this result. Future price updates must not
    // silently rewrite historical spend calculated from usage.
    pricingSnapshot: pricing ? { ...pricing } : null,
    ...cost,
    finishedAt: receiptTimestamp(result?.finishedAt) ? result.finishedAt : finishedAt,
    review: planned.review ?? null,
    rating: planned.rating ?? null,
  }
}

/** Planned packages with their routing reason, for ledger and UI. */
export function plannedPackages(plan, task) {
  if (plan?.routingBypassed) {
    const route = plan.directRoute ?? plan.selected
    return [{ id: 'direct', name: '指定模型', objective: String(task ?? ''), dependsOn: [],
      recommendedProvider: route?.provider, recommendedModel: route?.model,
      ...(typeof route?.reasoningEffort === 'string' && route.reasoningEffort ? { recommendedReasoningEffort: route.reasoningEffort } : {}),
      difficulty: plan.complexity?.band ?? null, estimatedCost: plan.estimatedCost ?? null,
      executionChannel: plan.executionChannel ?? null }]
  }
  return (plan?.team?.workPackages ?? []).map(item => ({ ...item }))
}

/** One ledger record for a plan and its execution. */
export function buildRunRecord({ id, createdAt, task, plan, execution, preset = 'balanced', workspace = '', pricingFor = () => null, billingFor = billingOf, budget = null, finishedAt = createdAt, kind = 'assign', executionMode = 'read-only' }) {
  const planned = plannedPackages(plan, task)
  const results = Array.isArray(execution?.packages) ? execution.packages : []
  return {
    id,
    createdAt,
    finishedAt,
    task: String(task ?? '').slice(0, MAX_STORED_TASK),
    workspace,
    kind,
    executionMode,
    routingBypassed: plan?.routingBypassed === true,
    mode: plan?.mode ?? 'single',
    ...(typeof plan?.assignmentMode === 'string' && plan.assignmentMode.trim().length > 0
      && plan.assignmentMode.length <= 40 && !/[\u0000-\u001f\u007f]/u.test(plan.assignmentMode)
      ? { assignmentMode: plan.assignmentMode.trim() } : {}),
    preset,
    decision: {
      dataVersions: plan?.optimization?.dataVersions ?? null,
      personalization: plan?.optimization?.personalization ?? null,
      selected: plan?.selected ? { provider: plan.selected.provider, model: plan.selected.model } : null,
      reason: String(plan?.reason ?? ''),
      complexity: plan?.complexity ? { band: plan.complexity.band, value: finite(plan.complexity.value) ? Number(plan.complexity.value.toFixed(3)) : null } : null,
      estimatedCost: finite(plan?.estimatedCost) ? plan.estimatedCost : null,
      executionChannel: plan?.executionChannel ?? null,
    },
    budget,
    status: execution?.status ?? 'pending',
    packages: planned.map(item => storedPackage(item, results.find(result => result.id === item.id), pricingFor(results.find(result => result.id === item.id) ?? item), finishedAt, billingFor)),
    reviews: [],
  }
}

/** Replace the retried packages (`rerunIds`) with new results; untouched ones keep ratings and reviews. */
export function mergeRerun(run, execution, { rerunIds = [], pricingFor = () => null, billingFor = billingOf, finishedAt = Date.now() } = {}) {
  const results = Array.isArray(execution?.packages) ? execution.packages : []
  const retried = new Set(rerunIds)
  // Retrying replaces the visible result, but earlier attempts still incurred
  // charges (or unknown usage). Keep their calendar totals before replacement.
  const replaced = run.packages.filter(stored => retried.has(stored.id) && results.some(item => item.id === stored.id))
  run.priorAttemptSubscriptionUsage = archiveSubscriptionUsage([{ createdAt: run.createdAt, packages: replaced }],
    sanitizeArchivedSubscriptionUsage(run.priorAttemptSubscriptionUsage, { legacySpending: run.priorAttemptSpending }))
  run.priorAttemptSpending = archiveSpending([{ createdAt: run.createdAt, packages: replaced }], run.priorAttemptSpending)
  run.packages = run.packages.map(stored => {
    const result = results.find(item => item.id === stored.id)
    if (!result || !retried.has(stored.id)) return stored
    return storedPackage({ ...stored, review: null, rating: null }, result, pricingFor(result), finishedAt, billingFor)
  })
  run.status = execution?.status ?? run.status
  run.finishedAt = finishedAt
  return run
}

/** Results in executor shape, from stored packages, for a retry. */
export function storedResults(run) {
  return (run?.packages ?? []).map(item => ({
    id: item.id, name: item.name, ok: item.ok, provider: item.provider, model: item.model,
    channel: item.channel, answer: item.answer, error: item.error, fallback: item.fallback,
    blocked: item.blocked, finishedAt: item.finishedAt,
    ...(item.subscriptionAttempts !== undefined ? { subscriptionAttempts: sanitizeSubscriptionAttempts(item.subscriptionAttempts) } : {}),
    ...packageSelectionFields(item),
    ...reasoningExecutionFields(item),
    ...(finite(item.durationMs) && item.durationMs >= 0 ? { durationMs: item.durationMs } : {}),
    ...(finite(item.inputChars) && item.inputChars >= 0 ? { inputChars: item.inputChars } : {}),
    ...(item.paused ? { paused: true } : {}), ...(item.waiting ? { waiting: true } : {}),
  }))
}

const TEAM_FAILURE = new Set(['failed', 'timed-out', 'output-limit', 'model-mismatch', 'unsupported', 'integration-pending'])

/**
 * Convert the signed team runner's per-package results into the executor
 * result shape used by the ledger. Packages the runner never reached are
 * blocked behind the first failure (or by the preflight `blocking` list).
 */
export function teamExecutionResults(plan, execution) {
  const planned = plan?.team?.workPackages ?? []
  const results = Array.isArray(execution?.results) ? execution.results : []
  const blockingReason = (execution?.blocking ?? []).map(item => item.reason).filter(Boolean).join('；')
  const converted = results.map(result => ({
    id: result.id,
    ok: result.status === 'succeeded',
    cancelled: result.status === 'cancelled',
    ...(result.notStarted === true || result.status === 'unsupported' ? { notStarted: true } : {}),
    ...(result.blocked === true ? { blocked: true } : {}),
    ...(result.billing === 'api' || result.billing === 'subscription' || result.billing === 'unknown' ? { billing: result.billing } : {}),
    ...(typeof result.credentialSource === 'string' ? { credentialSource: result.credentialSource } : {}),
    provider: result.provider,
    model: result.recommendedModel,
    ...unsupportedCliReasoning({ reasoningEffort: result.recommendedReasoningEffort }),
    ...reasoningExecutionFields(result),
    ...(finite(result.durationMs) && result.durationMs >= 0 ? { durationMs: result.durationMs } : {}),
    ...(finite(result.inputChars) && result.inputChars >= 0 ? { inputChars: result.inputChars } : {}),
    ...(receiptTimestamp(result.finishedAt) ? { finishedAt: result.finishedAt } : {}),
    requestedCliModel: result.requestedCliModel ?? null,
    actualModel: result.actualModel ?? null,
    ...(result.reportedModel !== undefined ? { reportedModel: result.reportedModel } : {}),
    modelNotice: result.modelNotice ?? null,
    ...(typeof result.source === 'string' ? { source: result.source } : {}),
    ...(typeof result.sandboxEnforcement === 'string' ? { sandboxEnforcement: result.sandboxEnforcement } : {}),
    ...(result.usageIncomplete === true ? { usageIncomplete: true } : {}),
    ...(result.subscriptionAttempts !== undefined ? { subscriptionAttempts: sanitizeSubscriptionAttempts(result.subscriptionAttempts) } : {}),
    ...(typeof result.executionEnvironment === 'string' ? { executionEnvironment: result.executionEnvironment } : {}),
    channel: 'official-cli',
    toolId: result.toolId ?? null,
    answer: String(result.finalText ?? ''),
    error: result.status === 'succeeded' ? null : String(result.error ?? (TEAM_FAILURE.has(result.status) ? result.status : '官方 CLI 未成功完成。')),
    stderrTail: result.outputTail ?? null,
    diagnostic: result.outputTail ?? null,
    exitCode: result.exitCode ?? null,
    ...(result.usage ? { usage: result.usage } : {}),
    ...(finite(result.reportedCostUsd) ? { reportedCostUsd: result.reportedCostUsd } : {}),
  }))
  const reached = new Set(converted.map(item => item.id))
  for (const item of planned) {
    if (reached.has(item.id)) continue
    converted.push({ id: item.id, ok: false, blocked: true, provider: item.recommendedProvider, model: item.recommendedModel,
      error: execution?.status === 'blocked' ? (blockingReason || '团队执行预检未通过。')
        : execution?.status === 'cancelled' ? '团队执行已取消。' : '前置工作包未成功，团队执行已停止。' })
  }
  return { status: execution?.status ?? 'pending', packages: converted }
}

/** A ledger record for model_router_team_execute. */
export function buildTeamRunRecord({ plan, execution, mode = 'read-only', ...rest }) {
  const record = buildRunRecord({ ...rest, plan, execution: teamExecutionResults(plan, execution), kind: 'team', executionMode: mode })
  record.mode = 'team'
  if (execution?.workspace && execution.workspace !== rest.workspace) record.isolatedWorkspace = String(execution.workspace)
  if (execution?.integration) record.integration = { ignoredArtifacts: execution.integration.ignoredArtifacts ?? 0 }
  if (typeof execution?.baseCommit === 'string') record.baseCommit = execution.baseCommit
  return record
}

/** A ledger record for model_router_tool_run (one package, one CLI). */
export function buildToolRunRecord({ toolId, toolLabel, provider, model, cliModel = null, mode = 'read-only', result, estimatedCost = null, rerunOf = null, ...rest }) {
  const packageId = 'direct'
  const plan = {
    mode: 'single', routingBypassed: true,
    directRoute: { provider: provider || toolId, model: model || result?.requestedModel || '默认模型' },
    selected: provider && model ? { provider, model } : null,
    reason: `直接调用 ${toolLabel ?? toolId}，未经过路由。`,
    complexity: null, estimatedCost: finite(estimatedCost) ? estimatedCost : null, executionChannel: 'official-cli',
  }
  const succeeded = result?.status === 'succeeded'
  const execution = {
    status: result?.status ?? 'pending',
    packages: [{
      id: packageId, ok: succeeded, cancelled: result?.status === 'cancelled',
      ...(result?.notStarted === true || result?.status === 'unsupported' ? { notStarted: true } : {}),
      ...(result?.blocked === true ? { blocked: true } : {}),
      ...(result?.billing === 'api' || result?.billing === 'subscription' || result?.billing === 'unknown' ? { billing: result.billing } : {}),
      ...(typeof result?.credentialSource === 'string' ? { credentialSource: result.credentialSource } : {}),
      provider: plan.directRoute.provider, model: plan.directRoute.model,
      channel: 'official-cli', toolId,
      requestedCliModel: Object.hasOwn(result ?? {}, 'requestedModel') ? result.requestedModel : cliModel,
      actualModel: modelIdentity(result?.actualModel) ?? modelIdentity(result?.reportedModel),
      ...(result?.reportedModel !== undefined ? { reportedModel: result.reportedModel } : {}),
      modelNotice: result?.modelNotice ?? null,
      ...(typeof result?.source === 'string' ? { source: result.source } : {}),
      ...(typeof result?.sandboxEnforcement === 'string' ? { sandboxEnforcement: result.sandboxEnforcement } : {}),
      ...(result?.usageIncomplete === true ? { usageIncomplete: true } : {}),
      ...(result?.subscriptionAttempts !== undefined ? { subscriptionAttempts: sanitizeSubscriptionAttempts(result.subscriptionAttempts) } : {}),
      ...(receiptTimestamp(result?.finishedAt) ? { finishedAt: result.finishedAt } : {}),
      answer: String(result?.finalText ?? ''),
      error: succeeded ? null : String(result?.error ?? result?.reason ?? result?.status ?? '官方 CLI 未成功完成。'),
      ...(!succeeded && typeof result?.diagnostic === 'string' && result.diagnostic.trim()
        ? { diagnostic: result.diagnostic } : {}),
      ...(Number.isInteger(result?.exitCode) ? { exitCode: result.exitCode } : {}),
      ...(result?.usage ? { usage: result.usage } : {}),
      ...(finite(result?.reportedCostUsd) ? { reportedCostUsd: result.reportedCostUsd } : {}),
    }],
  }
  const record = buildRunRecord({ ...rest, plan, execution, kind: 'tool', executionMode: mode })
  record.packages[0].name = `${toolLabel ?? toolId} 单次调用`
  // What a rerun needs to repeat this call exactly (no credentials).
  record.toolRun = { toolId, provider: provider || null, model: model || null, cliModel: cliModel || null }
  if (rerunOf) record.rerunOf = String(rerunOf)
  if (typeof result?.isolatedWorkspace === 'string') record.isolatedWorkspace = result.isolatedWorkspace
  return record
}
