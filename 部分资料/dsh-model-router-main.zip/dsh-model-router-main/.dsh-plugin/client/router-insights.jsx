import React from 'react'
import { ROUTING_PRESETS } from '../shared/routing-presets.mjs'
import { BILLING_MODE_LABEL } from '../shared/subscription-billing.mjs'
import {
  BILLING_CHANNEL_LABEL, LOGIN_LABEL, RUN_KIND_LABEL, billingRows, billingSwitchText, RUN_STATUS_LABEL, UNTESTED_VERSION_NOTE, budgetOccupancyMeter, dagLayers, formatUsd, healthSummary,
  packageCost, packageStatus, priorAttemptTotals, rerunSupport, reservationSummary, runTotals, versionLine,
  formatUsageTokens, subscriptionUsageForPackage, subscriptionUsageForRun, subscriptionUsageSummary, subscriptionUsageText,
} from './insights-state.mjs'
import {
  ADAPTIVE_NUMBER_FIELDS, adaptiveSettingValue, dynamicSourceView, feedbackRatingArguments,
  learningEvidenceRows, learningExclusionRows, learningView, parseAdaptiveNumber, parsePublicEndpoint, publicEndpointDraft,
} from './adaptive-state.mjs'

const text = value => typeof value === 'string' ? value.trim() : ''
const BAND = { simple: '简单', balanced: '中等', complex: '困难' }
const SUBSCRIPTION_FAILURE_OPTIONS = [['ask', '暂停并询问'], ['api', '自动改用 API'], ['fail', '直接失败']]
const SUBSCRIPTION_CHOICE_BUTTONS = [['api', '改用 API 重试', false], ['subscription', '重试订阅', true], ['cancel', '取消', true]]

/** First-open banner: one line per problem, with the way out. */
export function OnboardingBanner({ health, onDone, onRefresh, refreshing, error }) {
  const summary = healthSummary(health?.tools)
  const problems = (health?.tools ?? []).filter(item => item.installed && item.login?.state === 'logged-out')
  const updates = (health?.tools ?? []).filter(item => item.installed && item.versionStatus === 'update-available')
  return (
    <section className="mr-card mr-onboarding" aria-label="开箱体检">
      <div className="mr-card-head"><div>
        <h2 className="mr-card-title">开箱体检</h2>
        <p className="mr-card-copy">首次打开时检测官方工具的安装、版本与登录状态。未登录时按计费设置暂停或使用模型目录 API；任务模式的执行支持见各工具说明。</p>
      </div><button className="mr-button mr-button-secondary" type="button" disabled={refreshing} onClick={onRefresh}>{refreshing ? '检测中…' : '重新体检'}</button></div>
      <div className="mr-card-body">
        {error && <p className="mr-error" role="alert">{error}</p>}
        {!health && !error && <p className="mr-empty" role="status">正在体检本机官方工具…</p>}
        {health && (
          <>
            <div className="mr-result-grid">
              <div className="mr-metric"><div className="mr-metric-label">已安装</div><div className="mr-metric-value">{summary.installed} / {summary.total}</div></div>
              <div className="mr-metric"><div className="mr-metric-label">已登录</div><div className="mr-metric-value">{summary.ready}</div></div>
              <div className="mr-metric"><div className="mr-metric-label">未登录</div><div className="mr-metric-value">{summary.loggedOut}</div></div>
              <div className="mr-metric"><div className="mr-metric-label">登录状态未知</div><div className="mr-metric-value">{summary.unknown}</div></div>
            </div>
            {problems.length > 0
              ? <ul className="mr-checklist">{problems.map(item => <li key={item.id}><strong>{item.label}</strong>：未登录，可在下方点“去登录”查看登录方法（{item.login.command ?? '见说明'}）。</li>)}</ul>
              : <p className="mr-caption">已安装的工具没有发现未登录的问题。未安装的工具可在下方一键安装。</p>}
            {updates.length > 0 && <p className="mr-caption">有新版本：{updates.map(item => `${item.label} ${item.version ?? '?'} → ${item.latestVersion}`).join('；')}。可在下方“官方工具”中更新（可选）。</p>}
            <p className="mr-caption">{UNTESTED_VERSION_NOTE}</p>
            <div className="mr-actions"><button className="mr-button" type="button" onClick={onDone}>完成体检</button><span className="mr-caption">之后可随时在“官方工具”卡片中重新体检。</span></div>
          </>
        )}
      </div>
    </section>
  )
}

/** Login line and the “去登录” helper for one tool row. */
export function ToolLoginLine({ entry }) {
  const [open, setOpen] = React.useState(false)
  const [copied, setCopied] = React.useState(false)
  if (!entry?.installed) return null
  const state = entry.login?.state ?? 'unknown'
  const copy = async () => {
    try { await navigator.clipboard.writeText(entry.login.command); setCopied(true) } catch { setCopied(false) }
  }
  return (
    <div className="mr-login">
      <div className="mr-tool-status"><span className={`mr-tool-dot ${state === 'logged-in' ? 'installed' : state === 'logged-out' ? 'missing-strong' : ''}`} />{LOGIN_LABEL[state]} · {versionLine(entry)}</div>
      {entry.login?.detail && <p className="mr-caption mr-tool-detail">{entry.login.detail}</p>}
      {state === 'logged-in' && entry.login?.billing === 'subscription' && <p className="mr-caption mr-tool-detail">订阅账号登录：单独统计调用与 token 用量，不计入 API 费用预算。</p>}
      {state === 'logged-in' && entry.login?.billing === 'api-key' && <p className="mr-caption mr-tool-detail">API Key 计费：费用计入每日/每月预算。</p>}
      {state !== 'logged-in' && <button className="mr-button mr-button-secondary mr-tool-button mr-login-button" type="button" aria-expanded={open} onClick={() => setOpen(value => !value)}>去登录</button>}
      {open && (
        <div className="mr-login-guide">
          <p className="mr-caption">{entry.login.steps}</p>
          {entry.login.command && <div className="mr-login-command"><code className="mr-tool-command">{entry.login.command}</code><button className="mr-button mr-button-secondary" type="button" onClick={() => { void copy() }}>{copied ? '已复制' : '复制命令'}</button></div>}
          <p className="mr-caption">插件不会替你启动交互式登录。登录完成后点“重新体检”。</p>
        </div>
      )}
    </div>
  )
}

function Meter({ label, meter }) {
  return (
    <div className="mr-meter">
      <div className="mr-meter-top"><span className="mr-control-label">{label}</span><span className={meter.over ? 'mr-meter-over' : ''}>{meter.text}</span></div>
      {meter.limited && <div className="mr-meter-track" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(meter.share * 100)}><div className={`mr-meter-fill ${meter.over ? 'over' : meter.share > 0.8 ? 'near' : ''}`} style={{ width: `${Math.round(meter.share * 100)}%` }} /></div>}
    </div>
  )
}

/** Shared settings writer for the main page; Host schema keeps the real validation. */
function useSettingsWriter(settingsScope) {
  const [snapshot, setSnapshot] = React.useState(() => settingsScope.getSnapshot())
  const [notice, setNotice] = React.useState('')
  const [busy, setBusy] = React.useState(false)
  const pending = React.useRef(false)
  const mounted = React.useRef(true)
  React.useEffect(() => { mounted.current = true; return () => { mounted.current = false } }, [])
  React.useEffect(() => settingsScope.subscribe(() => setSnapshot(settingsScope.getSnapshot())), [settingsScope])
  const writable = snapshot.status === 'ready' && snapshot.writable === true && !busy
  const write = async (key, value) => {
    const current = settingsScope.getSnapshot()
    if (pending.current || current.status !== 'ready' || current.writable !== true) return false
    pending.current = true
    setBusy(true)
    setNotice('')
    try {
      const accepted = await settingsScope.mutate([{ op: 'set', path: [key], value }], current.revision)
      if (!accepted && mounted.current) setNotice('设置未保存，可能已在其他页面修改，请重试。')
      return accepted
    } catch (error) {
      if (mounted.current) setNotice(text(error?.message) || '设置保存失败。')
      return false
    } finally {
      pending.current = false
      if (mounted.current) setBusy(false)
    }
  }
  return { value: snapshot.value ?? {}, writable, busy, write, notice }
}

const ADAPTIVE_FIELD_LABEL = {
  feedbackHalfLifeDays: '反馈半衰期（天）', feedbackPriorWeight: '收缩强度',
  feedbackMaxAdjustment: '最大偏好效用调整', dynamicDataTtlMinutes: '公共快照检查间隔（分钟）',
}

/** Number drafts are local until saved; blank never means zero. */
function AdaptiveNumberControl({ field, value, writable, onSave }) {
  const [draft, setDraft] = React.useState('')
  const [notice, setNotice] = React.useState('')
  const save = async () => {
    let next
    try {
      next = parseAdaptiveNumber(field.key, draft)
    } catch { setNotice(`请输入 ${field.min} 到 ${field.max} 的数字。`); return }
    setNotice('')
    try {
      if (await onSave(field.key, next)) setDraft(current => current === draft ? '' : current)
    } catch { setNotice('设置保存失败，请重试。') }
  }
  return <div className="mr-control-group">
    <label className="mr-control-label" htmlFor={`mr-${field.key}`}>{ADAPTIVE_FIELD_LABEL[field.key]}</label>
    <div className="mr-inline"><input className="mr-input mr-budget" id={`mr-${field.key}`} type="number" min={field.min} max={field.max} step={field.step}
      placeholder={String(value)} value={draft} disabled={!writable} onChange={event => setDraft(event.target.value)} />
      <button className="mr-button mr-button-secondary" type="button" disabled={!writable || draft === ''} onClick={() => { void save() }}>保存</button></div>
    {notice && <span className="mr-error" role="alert">{notice}</span>}
  </div>
}

function PublicEndpointControl({ name, label, value, writable, onSave }) {
  const [draft, setDraft] = React.useState(null)
  const [notice, setNotice] = React.useState('')
  const current = publicEndpointDraft(name, value)
  const save = async () => {
    let next
    try {
      next = parsePublicEndpoint(name, draft ?? current)
    } catch { setNotice('请输入不含认证、查询参数或片段的公开 HTTPS 地址；价格快照可留空。'); return }
    setNotice('')
    try {
      if (await onSave(name, next)) setDraft(currentDraft => currentDraft === draft ? null : currentDraft)
    } catch { setNotice('地址保存失败，请重试。') }
  }
  return <div className="mr-control-group">
    <label className="mr-control-label" htmlFor={`mr-${name}`}>{label}</label>
    <input className="mr-input" id={`mr-${name}`} type="url" maxLength={2048} value={draft ?? current} disabled={!writable}
      placeholder={name === 'liveBenchEndpoint' ? 'https://livebench.ai' : '留空：不读取远程价格快照'} onChange={event => setDraft(event.target.value)} />
    <button className="mr-button mr-button-secondary" type="button" disabled={!writable || draft === null} onClick={() => { void save() }}>保存地址</button>
    {notice && <span className="mr-error" role="alert">{notice}</span>}
  </div>
}

function PublicSourceStatus({ label, source, enabled }) {
  const view = dynamicSourceView(source, enabled)
  return <div className="mr-control-group"><span className="mr-control-label">{label}：{view.label}</span>
    {view.status !== 'disabled' && <span className="mr-caption">{view.version ? `版本 ${view.version} · ` : ''}{view.count} 条记录{view.verifiedAt ? ` · 最近校验 ${new Date(view.verifiedAt).toLocaleString()}` : ''}</span>}
    {view.source && <span className="mr-caption">公开来源：{view.source}</span>}
    {(view.refreshing || view.pending) && <span className="mr-caption" role="status">公开源正在刷新；上面的版本仍是最近一次已保存快照，不是本次请求已成功。</span>}
    {view.lastAttemptAt && <span className="mr-caption">最近尝试 {new Date(view.lastAttemptAt).toLocaleString()}{view.lastSuccessAt ? ` · 最近成功 ${new Date(view.lastSuccessAt).toLocaleString()}` : ''}</span>}
    {view.status === 'error' && <span className="mr-caption">更新失败；是否可用由 Host 校验，不将缺失数据当作零成本或满分。</span>}
    {view.status === 'stale' && <span className="mr-caption">上次有效快照已过期或本次更新失败；Host 可能沿用旧数据，不能当作最新价格或能力。</span>}
    {view.errorCode === 'storage-failed' && <span className="mr-caption">本次状态保存失败；只能使用此前已保存的当前源快照，请重试刷新。</span>}
    {view.errorCode === 'refresh-interrupted' && <span className="mr-caption">上次公开数据刷新中断；请刷新摘要查看 Host 的后续重试状态。</span>}
    {view.lastGoodEndpoint && view.endpoint && view.lastGoodEndpoint !== view.endpoint && <span className="mr-caption">此前来源的有效快照仍保留在本地，但不应用到当前公开源。</span>}
    {view.status === 'disabled' && <span className="mr-caption">当前设置不使用此公开源；保留的历史快照不代表正在使用。</span>}
  </div>
}

function LearningEvidence({ learning }) {
  const evidence = learningEvidenceRows(learning)
  const exclusions = learningExclusionRows(learning)
  return <>
    {evidence.total > 0 && <details className="mr-tool-log"><summary>查看分模型 / 任务类型的已观察反馈（{evidence.total} 组）</summary>
      <p className="mr-caption">只描述已选择并获得评价的结果，不代表所有模型的真实质量或收益；有效样本量反映权重集中程度，不是质量置信度。</p>
      <div className="mr-table-wrap"><table className="mr-table"><thead><tr><th>路线 / 任务类型</th><th>有用 / 不好</th><th>偏好效用调整</th></tr></thead>
        <tbody>{evidence.rows.map(row => <tr key={row.id}>
          <td>{row.route}<div className="mr-caption">{row.domain}</div></td>
          <td>{row.positiveCount} / {row.negativeCount}<div className="mr-caption">已观察 {row.feedbackCount} · 有效权重 {row.effectiveWeight.toFixed(2)} · 有效样本量 {row.effectiveSampleSize.toFixed(2)}</div></td>
          <td>{row.adjustment > 0 ? '+' : ''}{row.adjustment.toFixed(4)}<div className="mr-caption">收缩系数 {row.shrinkage.toFixed(2)}</div></td>
        </tr>)}</tbody></table></div>
      {evidence.total > evidence.rows.length && <p className="mr-caption">仅展示前 {evidence.rows.length} 组；不是所有模型的覆盖率。</p>}
    </details>}
    {exclusions.length > 0 && <details className="mr-tool-log"><summary>查看未参与学习的原因</summary>
      <ul className="mr-checklist">{exclusions.map(row => <li key={row.reason}>{row.label}：{row.count}</li>)}</ul>
    </details>}
  </>
}

function AdaptiveControls({ ledger, settings, onChanged, refreshing }) {
  const value = settings.value
  const learning = learningView(ledger?.learning, value)
  const [resetBusy, setResetBusy] = React.useState(false)
  const [refreshNotice, setRefreshNotice] = React.useState('')
  const resetPending = React.useRef(false)
  const save = async (key, next) => {
    const accepted = await settings.write(key, next)
    if (accepted) {
      setRefreshNotice('')
      try { await onChanged?.() }
      catch { setRefreshNotice('设置已保存，但摘要刷新失败；请刷新执行记录后重新规划。') }
    }
    return accepted
  }
  const reset = async () => {
    if (resetPending.current || !settings.writable) return
    resetPending.current = true
    try {
      if (!window.confirm('从现在重新学习你的偏好？此前反馈将不再参与调整，但执行记录、费用历史和原评价不会删除。')) return
      setResetBusy(true)
      await save('feedbackResetAt', Date.now())
    } finally { resetPending.current = false; setResetBusy(false) }
  }
  return <>
    <h3 className="mr-section-title">持续反馈与本地偏好</h3>
    <p className="mr-caption">只使用你对已记录结果的点赞 / 不好 / 撤回，按任务类型和时间衰减调整偏好效用；不抬高质量硬门槛。系统执行成功不等于你满意，模型复核也不作为人工评分。不会为了学习发起付费探索。</p>
    <p className="mr-caption">范围：本地 DSH_HOME 工作室共享，不是按账号隔离；最多最近 200 次运行的滑动窗口，不上传反馈或任务内容。</p>
    <div className="mr-controls">
      <label className="mr-check"><input type="checkbox" checked={adaptiveSettingValue(value, 'feedbackLearningEnabled') !== false} disabled={!settings.writable}
        onChange={event => { void save('feedbackLearningEnabled', event.target.checked) }} />启用用户反馈学习</label>
      {ADAPTIVE_NUMBER_FIELDS.filter(field => field.key !== 'dynamicDataTtlMinutes').map(field => <AdaptiveNumberControl key={field.key} field={field}
        value={adaptiveSettingValue(value, field.key)} writable={settings.writable} onSave={save} />)}
    </div>
    {settings.busy && <p className="mr-caption" role="status">正在保存设置，请稍候…</p>}
    {refreshing && <p className="mr-caption" role="status">正在读取反馈与公开数据摘要…</p>}
    {refreshNotice && <p className="mr-error" role="alert">{refreshNotice}</p>}
    {learning.available ? <p className="mr-caption" role="status">{learning.enabled ? '学习已启用' : '学习已停用'} · 最近一次账本摘要：有效反馈 {learning.feedbackCount} · 有效权重 {learning.effectiveWeight.toFixed(2)} · 忽略 {learning.ignoredCount}{learning.policyVersion ? ` · 策略 ${learning.policyVersion}` : ''}</p>
      : <p className="mr-caption" role="status">学习摘要尚未读取；保存后刷新执行记录查看。</p>}
    <p className="mr-caption">摘要是最近一次读取的已观察证据。修改评价 / 学习设置后需刷新摘要并重新生成建议；刷新按检查间隔复用公开快照，不保证每次下载新数据。</p>
    <LearningEvidence learning={ledger?.learning} />
    {learning.resetAt > 0 && <p className="mr-caption">学习起点：{new Date(learning.resetAt).toLocaleString()}，此前反馈不再参与调整。</p>}
    <button className="mr-button mr-button-secondary" type="button" disabled={!settings.writable || resetBusy} onClick={() => { void reset() }}>{resetBusy ? '正在设置…' : '从现在重新学习'}</button>
    <h3 className="mr-section-title">动态公共数据</h3>
    <p className="mr-caption">默认关闭。明确启用后，在打开 / 刷新账本及执行前按检查间隔读取公开 LiveBench 和可选价格快照；价格与能力先验保留版本，不代表真实任务收益。只有打开公共源开关才会读取远程数据，不发送任务或反馈。</p>
    <div className="mr-controls">
      <label className="mr-check"><input type="checkbox" checked={adaptiveSettingValue(value, 'dynamicDataEnabled') === true} disabled={!settings.writable}
        onChange={event => { void save('dynamicDataEnabled', event.target.checked) }} />启用动态公共数据</label>
      <AdaptiveNumberControl field={ADAPTIVE_NUMBER_FIELDS.find(field => field.key === 'dynamicDataTtlMinutes')}
        value={adaptiveSettingValue(value, 'dynamicDataTtlMinutes')} writable={settings.writable} onSave={save} />
      <PublicEndpointControl name="liveBenchEndpoint" label="LiveBench 公开源" value={adaptiveSettingValue(value, 'liveBenchEndpoint')} writable={settings.writable} onSave={save} />
      <PublicEndpointControl name="pricingSnapshotEndpoint" label="价格快照公开源（可选）" value={adaptiveSettingValue(value, 'pricingSnapshotEndpoint')} writable={settings.writable} onSave={save} />
      <PublicSourceStatus label="LiveBench" source={ledger?.dynamicData?.liveBench} enabled={adaptiveSettingValue(value, 'dynamicDataEnabled') === true} />
      <PublicSourceStatus label="价格" source={ledger?.dynamicData?.pricing} enabled={adaptiveSettingValue(value, 'dynamicDataEnabled') === true && Boolean(adaptiveSettingValue(value, 'pricingSnapshotEndpoint'))} />
    </div>
  </>
}

/** 成本控制 + 预设方案: prominent spending meters and the knobs that govern routing cost. */
export function CostControlCard({ ledger, settingsScope, onChanged, error, refreshing = false }) {
  const settings = useSettingsWriter(settingsScope)
  const [dailyDraft, setDailyDraft] = React.useState('')
  const [monthlyDraft, setMonthlyDraft] = React.useState('')
  const value = settings.value
  const preset = value.routingPreset ?? 'balanced'
  const daily = Number(value.dailyBudgetUsd ?? 0)
  const monthly = Number(value.monthlyBudgetUsd ?? 0)
  const spent = ledger?.spent ?? { today: 0, month: 0, unknownToday: 0, unknownMonth: 0 }
  const reserved = reservationSummary(ledger)
  const reservations = (ledger?.reservations ?? []).filter(item => ['active', 'interrupted'].includes(item.status))
  const set = async (key, next) => { if (await settings.write(key, next)) onChanged?.() }
  const saveLimit = async (key, draft, reset) => {
    const parsed = Number(draft)
    if (draft === '' || !Number.isFinite(parsed) || parsed < 0) return
    if (await settings.write(key, parsed)) { reset(''); onChanged?.() }
  }
  return (
    <section className="mr-card mr-cost" aria-label="成本控制">
      <div className="mr-card-head"><div>
        <h2 className="mr-card-title">API 费用、预算与路由方案</h2>
        <p className="mr-card-copy">API 按实际计费计算预算（CLI 自报金额或 token 用量 × 你配置的单价）。订阅调用单独统计用量，不折算金额、不占 API 预算。API 缺少单价或完整用量时，费用保持未知；本机记录不能替代厂商账单。</p>
      </div></div>
      <div className="mr-card-body">
        {error && <p className="mr-error" role="alert">{error}</p>}
        <div className="mr-meters">
          <Meter label="今日 API 预算占用" meter={budgetOccupancyMeter(spent.today, daily, reserved.today)} />
          <Meter label="本月 API 预算占用" meter={budgetOccupancyMeter(spent.month, monthly, reserved.month)} />
        </div>
        <p className="mr-caption">预占是尚未结算的费用估算，不是实际账单；剩余额度已扣除已发生费用与已知预占。执行中 {reserved.activeCount} 项 · 待核对中断 {reserved.interruptedCount} 项。</p>
        {(reserved.unknownToday > 0 || reserved.unknownMonth > 0) && <p className="mr-caption mr-warn-text">预占金额未知：今日 {reserved.unknownToday} 项 · 本月 {reserved.unknownMonth} 项，未计入上方预占金额，不能视为零费用。请核对厂商账单与原任务记录。</p>}
        {reserved.interruptedCount > 0 && <p className="mr-error" role="alert">有中断任务尚未核对，预占继续保留，不能直接重跑。请先核对旧任务与厂商账单，保留原始状态文件和已保存结果；若记录损坏，从可信备份恢复完整状态。当前界面不支持手动结算或自动付费恢复。</p>}
        {reservations.length > 0 && <details className="mr-tool-log"><summary>查看未结算预占（{reservations.length} 项）</summary>
          <ul className="mr-checklist">{reservations.map(item => <li key={item.id}>运行 <code>{item.runId || item.id}</code> · {item.billing === 'subscription'
            ? item.status === 'interrupted' ? '订阅执行中断，用量待核对' : '订阅执行中，用量待回报'
            : <>{item.status === 'interrupted' ? '执行中断，费用待核对' : '执行中'} · 剩余预占 {item.unknown || !Number.isFinite(item.remainingEstimateUsd) ? '金额未知' : formatUsd(item.remainingEstimateUsd)}</>}{Number.isFinite(item.updatedAt) ? ` · 最近保存 ${new Date(item.updatedAt).toLocaleString()}` : ''}</li>)}</ul>
        </details>}
        {(spent.unknownToday > 0 || spent.unknownMonth > 0) && <p className="mr-caption">本月有 {spent.unknownMonth} 次调用缺少单价或用量，未计入金额。请在“模型价格与能力”中补齐单价。</p>}
        {ledger?.budget?.exceeded && <p className="mr-error" role="alert">{ledger.budget.message} {ledger.budget.action === 'pause' ? '新的执行会先暂停并请求确认。' : '新的执行会尝试自动降级为“省钱优先”。'}</p>}
        <div className="mr-controls">
          <div className="mr-control-group"><span className="mr-control-label">路由方案</span>
            <div className="mr-segment" role="group" aria-label="路由方案">
              {Object.values(ROUTING_PRESETS).map(item => <button key={item.id} type="button" title={item.description} aria-pressed={preset === item.id} disabled={!settings.writable} onClick={() => { void set('routingPreset', item.id) }}>{item.label}</button>)}
            </div>
            <span className="mr-caption">{ROUTING_PRESETS[preset]?.description}</span>
          </div>
          <div className="mr-control-group"><label className="mr-control-label" htmlFor="mr-daily-budget">每日上限（USD，0 为不限）</label>
            <div className="mr-inline"><input className="mr-input mr-budget" id="mr-daily-budget" type="number" min="0" step="0.5" placeholder={String(daily)} value={dailyDraft} onChange={event => setDailyDraft(event.target.value)} /><button className="mr-button mr-button-secondary" type="button" disabled={!settings.writable || dailyDraft === ''} onClick={() => { void saveLimit('dailyBudgetUsd', dailyDraft, setDailyDraft) }}>保存</button></div>
          </div>
          <div className="mr-control-group"><label className="mr-control-label" htmlFor="mr-monthly-budget">每月上限（USD，0 为不限）</label>
            <div className="mr-inline"><input className="mr-input mr-budget" id="mr-monthly-budget" type="number" min="0" step="1" placeholder={String(monthly)} value={monthlyDraft} onChange={event => setMonthlyDraft(event.target.value)} /><button className="mr-button mr-button-secondary" type="button" disabled={!settings.writable || monthlyDraft === ''} onClick={() => { void saveLimit('monthlyBudgetUsd', monthlyDraft, setMonthlyDraft) }}>保存</button></div>
          </div>
          <div className="mr-control-group"><span className="mr-control-label">超出预算时</span>
            <div className="mr-segment" role="group" aria-label="超出预算时">
              <button type="button" aria-pressed={(value.overBudgetAction ?? 'downgrade') === 'downgrade'} disabled={!settings.writable} onClick={() => { void set('overBudgetAction', 'downgrade') }}>自动降级</button>
              <button type="button" aria-pressed={value.overBudgetAction === 'pause'} disabled={!settings.writable} onClick={() => { void set('overBudgetAction', 'pause') }}>暂停并询问</button>
            </div>
          </div>
          <div className="mr-control-group"><span className="mr-control-label">订阅调用失败（非额度用尽）时</span>
            <div className="mr-segment" role="group" aria-label="订阅调用失败时">
              {SUBSCRIPTION_FAILURE_OPTIONS.map(([id, label]) => <button key={id} type="button" aria-pressed={(value.onSubscriptionFailure ?? 'ask') === id} disabled={!settings.writable} onClick={() => { void set('onSubscriptionFailure', id) }}>{label}</button>)}
            </div>
            <span className="mr-caption">超时、崩溃、解析失败、非零退出、登录错误等。额度用尽或限流仍会自动切换 API Key。</span>
          </div>
        </div>
        <h3 className="mr-section-title">质量回路</h3>
        <div className="mr-controls">
          <div className="mr-control-group"><span className="mr-control-label">强模型抽查</span>
            <div className="mr-segment" role="group" aria-label="强模型抽查">
              {[['off', '关闭'], ['sample', '按比例抽查'], ['always', '每次审阅']].map(([id, label]) => <button key={id} type="button" aria-pressed={(value.reviewMode ?? 'off') === id} disabled={!settings.writable} onClick={() => { void set('reviewMode', id) }}>{label}</button>)}
            </div>
            <span className="mr-caption">抽查由目录中质量最高的已配置模型完成，只审阅更便宜模型的结果；审阅本身也会计费。抽查比例 {Math.round(Number(value.reviewSampleRate ?? 0.2) * 100)}%（可在插件设置中调整）。</span>
          </div>
          <label className="mr-check"><input type="checkbox" checked={value.allowManualReassign !== false} disabled={!settings.writable} onChange={event => { void set('allowManualReassign', event.target.checked) }} />允许手动改派工作包</label>
          <label className="mr-check"><input type="checkbox" checked={value.confirmUnsandboxedCli !== false} disabled={!settings.writable} onChange={event => { void set('confirmUnsandboxedCli', event.target.checked) }} />直接启动无沙箱 CLI 前先确认</label>
        </div>
        <AdaptiveControls ledger={ledger} settings={settings} onChanged={onChanged} refreshing={refreshing} />
        {settings.notice && <p className="mr-error" role="alert">{settings.notice}</p>}
      </div>
    </section>
  )
}

function UsagePeriod({ label, period }) {
  return <div className="mr-metric">
    <div className="mr-metric-label">{label}</div>
    <div className="mr-metric-value">{period.calls} 次调用</div>
    <p className="mr-caption">已报告输入 {formatUsageTokens(period.inputTokens)} / 输出 {formatUsageTokens(period.outputTokens)} tokens</p>
    <p className="mr-caption">缓存读取 {formatUsageTokens(period.cacheReadTokens)} / 写入 {formatUsageTokens(period.cacheWriteTokens)} tokens</p>
    {period.unknownUsageCalls > 0 && <p className="mr-caption mr-warn-text">{period.unknownUsageCalls} 次调用用量不完整或未知</p>}
  </div>
}

/** A separate quantity ledger: provider quota is not inferred from token counts. */
export function SubscriptionUsageCard({ ledger }) {
  const usage = subscriptionUsageSummary(ledger)
  return <section className="mr-card mr-results" aria-label="订阅用量">
    <div className="mr-card-head"><div>
      <h2 className="mr-card-title">订阅用量</h2>
      <p className="mr-card-copy">订阅只统计调用次数与厂商已报告的 token 用量，和 API 金额分开计算。未报告的用量保持未知，不按 API 价格折算。</p>
    </div></div>
    <div className="mr-card-body">
      {!usage.available && <p className="mr-empty">订阅用量摘要不可用。旧版 Host 或历史记录可能只保存参考金额；不能从该金额还原 token 用量，请更新 Host 后刷新。</p>}
      {usage.available && <>
        <div className="mr-result-grid">
          <UsagePeriod label="今日订阅用量" period={usage.today} />
          <UsagePeriod label="本月订阅用量" period={usage.month} />
        </div>
        {usage.byRoute.length > 0 && <div className="mr-table-wrap"><table className="mr-table">
          <thead><tr><th>订阅供应商 / 工具</th><th>今日已观察用量</th><th>本月已观察用量</th></tr></thead>
          <tbody>{usage.byRoute.map(item => <tr key={`${item.provider}\u0000${item.toolId ?? ''}\u0000${item.model ?? ''}`}>
            <td><strong>{item.provider || '未记录供应商'}</strong><div className="mr-caption">{[item.toolId, item.model].filter(Boolean).join(' · ') || '未记录工具或模型'}</div></td>
            <td>{subscriptionUsageText(item.today)}</td><td>{subscriptionUsageText(item.month)}</td>
          </tr>)}</tbody>
        </table></div>}
        {usage.month.calls === 0 && <p className="mr-caption">本月没有已记录的订阅调用。</p>}
      </>}
      <p className="mr-caption">这些数值是本机已记录用量，不代表订阅总额度或剩余额度。不同厂商的计量方式、窗口及缓存口径可能不同；未获得厂商配额时，不显示已用百分比。</p>
    </div>
  </section>
}

/** Layered dependency view: one column per depth, nodes in plan order. */
export function DagView({ packages, renderNode, label = '子任务依赖图' }) {
  const layers = dagLayers(packages)
  if (layers.length === 0) return null
  const names = new Map((packages ?? []).map(item => [item.id, item.name]))
  return (
    <div className="mr-dag" role="list" aria-label={label}>
      {layers.map((layer, index) => (
        <div className="mr-dag-column" key={index}>
          <div className="mr-dag-step">第 {index + 1} 步</div>
          {layer.map(item => {
            const status = packageStatus(item)
            return (
              <article className={`mr-dag-node ${status.tone}`} role="listitem" key={item.id}>
                <div className="mr-dag-node-top"><span className="mr-package-name">{item.name}</span><span className={`mr-pill mr-status-${status.tone}`}>{status.label}</span></div>
                {(item.dependsOn ?? []).length > 0 && <p className="mr-package-copy">依赖：{item.dependsOn.map(id => names.get(id) ?? id).join('、')}</p>}
                {renderNode?.(item)}
              </article>
            )
          })}
        </div>
      ))}
    </div>
  )
}

function ChannelText({ item }) {
  if (!item.channel) return <span className="mr-pill">{item.status === 'running' ? '执行中' : item.status === 'interrupted' ? '执行中断' : '待执行'}</span>
  if (item.billing === 'subscription') return <span className="mr-pill mr-pill-channel-ok">{item.channel === 'official-cli' ? `订阅 · 官方 CLI · ${item.toolId ?? ''}` : '编程套餐订阅'}</span>
  return <span className={item.channel === 'official-cli' ? 'mr-pill mr-pill-channel-ok' : 'mr-pill'}>{item.channel === 'official-cli' ? `官方 CLI · ${item.toolId ?? ''}` : '模型目录 API'}</span>
}

function RunNode({ run, item, routes, allowReassign, busy, onRate, onRerun, ledger }) {
  const [target, setTarget] = React.useState('')
  const rerun = rerunSupport(run, ledger)
  if (item.status === 'paused') return <PausedNode run={run} item={item} busy={busy} onRerun={onRerun} rerun={rerun} />
  const cost = packageCost(item)
  const usage = subscriptionUsageForPackage(item)
  const canRerun = rerun.supported && !item.ok && !busy
  const others = routes.filter(route => `${route.provider}/${route.model}` !== `${item.provider}/${item.model}`)
  return (
    <>
      <p className="mr-package-route">{item.provider}/{item.model}{item.reassigned ? '（已改派）' : ''}</p>
      {item.manualAssignment && <p className="mr-caption">手动分配 · {item.manualAssignment.kind === 'tool'
        ? `官方工具 ${item.manualAssignment.toolId}（厂商默认模型）`
        : `模型 API ${item.manualAssignment.provider}/${item.manualAssignment.model}`}
        {item.algorithmRecommendation?.provider ? ` · 原推荐 ${item.algorithmRecommendation.provider}/${item.algorithmRecommendation.model}` : ''}</p>}
      <div className="mr-channel-line"><ChannelText item={item} /><span className="mr-caption">{item.billing === 'subscription' ? '订阅用量单独统计 · 不占 API 预算' : `API 预估 ${formatUsd(item.estimatedCost)} · 实际 ${cost.budget}`}{item.difficulty ? ` · 难度 ${BAND[item.difficulty] ?? item.difficulty}` : ''}</span></div>
      {usage.calls > 0 && <p className="mr-package-copy">{subscriptionUsageText(usage)}</p>}
      {item.billing === 'subscription' && usage.calls === 0 && <p className="mr-package-copy">{item.inFlight ? '订阅调用执行中，用量待回报。' : '尚未记录订阅调用用量。'}</p>}
      {item.actualModel && <p className="mr-package-copy">CLI 回报模型：{item.actualModel}</p>}
      {(item.billing || item.billingMode) && <p className="mr-package-copy">计费：{BILLING_CHANNEL_LABEL[item.billing] ?? '—'}{item.subscriptionRoute ? ` · 套餐路线 ${item.subscriptionRoute.provider}/${item.subscriptionRoute.model}` : ''}{item.billingMode && item.billingMode !== 'subscription-first' ? ` · ${BILLING_MODE_LABEL[item.billingMode] ?? item.billingMode}` : ''}</p>}
      {billingSwitchText(item) && <p className="mr-package-copy mr-warn-text">计费切换：{billingSwitchText(item)}</p>}
      {item.fallback?.reason && item.fallback.reason !== billingSwitchText(item) && <p className="mr-package-copy">回退原因：{item.fallback.reason}</p>}
      {item.fallback?.error && <p className="mr-package-copy mr-fallback-error">CLI 原始错误：<code>{item.fallback.error}</code></p>}
      {!item.ok && item.error && <p className="mr-package-copy mr-fallback-error">{item.error}</p>}
      {!item.ok && item.diagnostic && <details className="mr-tool-log"><summary>CLI 诊断{Number.isInteger(item.exitCode) ? `（退出码 ${item.exitCode}）` : ''}</summary><pre>{item.diagnostic}</pre></details>}
      {item.review && <p className="mr-package-copy">强模型抽查（{item.review.provider}/{item.review.model}）：{item.review.score ? `${item.review.score}/5` : '未评分'} {item.review.summary}</p>}
      {item.answer && <details className="mr-tool-log"><summary>查看结果</summary><pre>{item.answer}{item.answerTruncated ? '\n…（已截断）' : ''}</pre></details>}
      <div className="mr-node-actions">
        {item.ok && <>
          <button className="mr-button mr-button-secondary mr-mini" type="button" title={item.rating === 1 ? '再次点击撤回有用评价' : '评价此结果有用'} aria-pressed={item.rating === 1} disabled={busy} onClick={() => onRate(...feedbackRatingArguments(run, item, 'up'))}>👍 有用</button>
          <button className="mr-button mr-button-secondary mr-mini" type="button" title={item.rating === -1 ? '再次点击撤回不好评价' : '评价此结果不好'} aria-pressed={item.rating === -1} disabled={busy} onClick={() => onRate(...feedbackRatingArguments(run, item, 'down'))}>👎 不好</button>
        </>}
        {canRerun && <button className="mr-button mr-mini" type="button" title={rerun.confirm || undefined} onClick={() => onRerun(run.id, item.id, null)}>{run.kind === 'tool' ? '重新执行此调用' : rerun.writes ? '在新工作区续跑' : '重跑此步'}</button>}
        {!rerun.supported && !item.ok && <span className="mr-caption">{rerun.reason}</span>}
        {rerun.supported && rerun.reassign && !(rerun.writes && item.ok) && allowReassign && others.length > 0 && !busy && (
          <span className="mr-inline">
            <select className="mr-input mr-mini-select" aria-label="改派到" value={target} onChange={event => setTarget(event.target.value)}>
              <option value="">改派到…</option>
              {others.map(route => <option key={`${route.provider}/${route.model}`} value={`${route.provider}\u0000${route.model}`}>{route.provider}/{route.model}</option>)}
            </select>
            <button className="mr-button mr-button-secondary mr-mini" type="button" disabled={!target} onClick={() => { const [provider, model] = target.split('\u0000'); onRerun(run.id, item.id, { provider, model }) }}>改派并重跑</button>
          </span>
        )}
      </div>
    </>
  )
}

/** A step paused after a non-quota subscription failure: the user picks how to continue. */
function PausedNode({ run, item, busy, onRerun, rerun }) {
  const pause = item.pause ?? {}
  return (
    <>
      <p className="mr-package-route">{item.provider}/{item.model}</p>
      <div className="mr-channel-line"><span className="mr-pill mr-pill-warn">等待确认</span><span className="mr-caption">订阅调用失败，未自动改用 API Key</span></div>
      <p className="mr-package-copy mr-warn-text">{pause.reason ?? item.error}</p>
      {pause.detail && <p className="mr-package-copy mr-fallback-error">真实错误：<code>{pause.detail}</code></p>}
      {pause.loginRequired && <p className="mr-package-copy">看起来是登录问题：请先在终端重新登录该 CLI，再点“重试订阅”。</p>}
      <div className="mr-node-actions">
        {SUBSCRIPTION_CHOICE_BUTTONS.map(([choice, label, secondary]) => (
          <button key={choice} className={`mr-button mr-mini${secondary ? ' mr-button-secondary' : ''}`} type="button" disabled={busy || !rerun.supported}
            onClick={() => onRerun(run.id, item.id, null, choice)}>{label}</button>
        ))}
      </div>
      {!rerun.supported && <p className="mr-caption">{rerun.reason}</p>}
    </>
  )
}

/** 路由决策 + 子任务可视化: recent runs with their DAG, channels, real errors, costs and ratings. */
export function RunHistoryCard({ ledger, routes, onRefresh, onRate, onRerun, busy, error, selectedRunId, onNewTask }) {
  const runs = ledger?.runs ?? []
  const [openId, setOpenId] = React.useState(null)
  React.useEffect(() => {
    if (selectedRunId && runs.some(run => run.id === selectedRunId)) setOpenId(selectedRunId)
  }, [selectedRunId, runs])
  const current = runs.find(run => run.id === openId) ?? runs[0]
  const support = rerunSupport(current, ledger)
  const unresolved = ['running', 'interrupted'].includes(current?.status)
    || (ledger?.reservations ?? []).some(item => item.runId === current?.id && ['active', 'interrupted'].includes(item.status))
  const totals = runTotals(current)
  const subscriptionUsage = subscriptionUsageForRun(current)
  const prior = priorAttemptTotals(current)
  const unknownCalls = prior.unknownCalls + [...(current?.packages ?? []), ...(current?.reviews ?? [])]
    .filter(item => item.ran && item.billing !== 'subscription' && !Number.isFinite(item.costUsd)).length
  return (
    <section className="mr-card mr-results" aria-label="执行记录">
      <div className="mr-card-head"><div>
        <h2 className="mr-card-title">执行记录与子任务</h2>
        <p className="mr-card-copy">查看模型分配、逐步结果与费用。已结束任务的失败步骤可重跑或改派；已完成的上游保持原结果。</p>
      </div><button className="mr-button mr-button-secondary" type="button" disabled={busy} onClick={onRefresh}>刷新</button></div>
      <div className="mr-card-body">
        {error && <p className="mr-error" role="alert">{error}</p>}
        {!ledger && !error && <p className="mr-empty" role="status">正在读取执行记录…</p>}
        {ledger && runs.length === 0 && <div className="mr-empty"><p>还没有执行记录。填写任务，预览并确认执行后，结果会显示在这里。</p>{onNewTask && <button type="button" className="mr-button mr-button-secondary" onClick={onNewTask}>开始一个任务</button>}</div>}
        {runs.length > 0 && (
          <>
            <label className="mr-label" htmlFor="mr-run-select">选择记录</label>
            <select className="mr-input" id="mr-run-select" value={current?.id ?? ''} onChange={event => setOpenId(event.target.value)}>
              {runs.map(run => <option key={run.id} value={run.id}>{new Date(run.createdAt).toLocaleString()} · {RUN_KIND_LABEL[run.kind ?? 'assign'] ?? run.kind} · {RUN_STATUS_LABEL[run.status] ?? run.status} · {(String(run.task ?? '').trim() || '未命名任务').slice(0, 40)}</option>)}
            </select>
            {current && (
              <div className="mr-run">
                <div className="mr-result-grid">
                  <div className="mr-metric"><div className="mr-metric-label">方案</div><div className="mr-metric-value">{ROUTING_PRESETS[current.preset]?.label ?? current.preset}{current.budget?.downgraded ? '（超预算自动降级）' : ''}</div></div>
                  <div className="mr-metric"><div className="mr-metric-label">难度</div><div className="mr-metric-value">{BAND[current.decision?.complexity?.band] ?? '—'}{current.decision?.complexity?.value !== null && current.decision?.complexity?.value !== undefined ? ` · ${current.decision.complexity.value}` : ''}</div></div>
                  <div className="mr-metric"><div className="mr-metric-label">API {unknownCalls ? '已知实际费用' : '实际费用'}（计入预算）</div><div className="mr-metric-value">{formatUsd(totals.budgetUsd)}</div></div>
                  <div className="mr-metric"><div className="mr-metric-label">类型</div><div className="mr-metric-value">{RUN_KIND_LABEL[current.kind ?? 'assign'] ?? current.kind}{current.kind === 'team' || current.kind === 'tool' ? ` · ${current.executionMode === 'workspace-write' ? '可编辑' : '只读'}` : ''}</div></div>
                </div>
                {subscriptionUsage.calls > 0 && <p className="mr-caption">{subscriptionUsageText(subscriptionUsage)}。订阅不计入 API 金额。</p>}
                {unknownCalls > 0 && <p className="mr-caption">另有 {unknownCalls} 次调用费用未知，未计入上方金额。</p>}
                {(prior.budgetUsd > 0 || prior.subscriptionRuns > 0 || prior.unknownCalls > 0) && <p className="mr-caption">累计包含此前重跑尝试：API {formatUsd(prior.budgetUsd)}{prior.subscriptionRuns > 0 ? ` · 订阅 ${prior.subscriptionRuns} 次调用（用量见上方累计）` : ''}{prior.unknownCalls > 0 ? ` · API 费用未知 ${prior.unknownCalls} 次` : ''}。下方节点显示最近一次结果。</p>}
                {current.kind === 'team' && <p className="mr-caption">执行环境：{current.executionEnvironment === 'cli-native'
                  ? '厂商 CLI 正常环境 · 当前用户权限 · 无 Harness 进程沙箱'
                  : current.executionEnvironment === 'harness' ? 'Harness 受限环境' : '历史记录未记录执行环境'}</p>}
                {current.isolatedWorkspace && <p className="mr-caption">独立工作区：<code>{current.isolatedWorkspace}</code></p>}
                {current.rerunOf && <p className="mr-caption">重新执行自运行 {current.rerunOf.slice(0, 8)}。</p>}
                {current.decision?.reason && <p className="mr-caption">路由原因：{current.decision.reason}</p>}
                {!support.supported && unresolved && <p className="mr-caption mr-warn-text">{support.reason}</p>}
                <DagView packages={current.packages} renderNode={item => <RunNode run={current} item={item} routes={routes} ledger={ledger} allowReassign={ledger?.settings?.allowManualReassign !== false} busy={busy} onRate={onRate} onRerun={onRerun} />} />
              </div>
            )}
          </>
        )}
      </div>
    </section>
  )
}

/** 订阅与 API Key: per-provider billing mode, subscription state and fallback availability. */
export function BillingCard({ billing, error, onRefresh, refreshing }) {
  const rows = billingRows(billing)
  return (
    <section className="mr-card mr-results" aria-label="订阅与 API Key">
      <div className="mr-card-head"><div>
        <h2 className="mr-card-title">订阅与 API Key</h2>
        <p className="mr-card-copy">默认订阅优先：有订阅（官方 CLI 账号登录或编程套餐 Key 路线）就先用订阅；订阅额度用尽或限流时，同一步骤按预算规则改用 API Key，并在执行记录中写明原因。订阅统计用量，API 统计费用，两种通道分别记账。</p>
      </div><button className="mr-button mr-button-secondary" type="button" disabled={refreshing} onClick={onRefresh}>重新体检</button></div>
      <div className="mr-card-body">
        {error && <p className="mr-error" role="alert">{error}</p>}
        {billing?.quotaPatternErrors?.length > 0 && <p className="mr-error" role="alert">额度识别规则有误，已忽略：{billing.quotaPatternErrors.join('；')}</p>}
        {rows.length === 0 && !error && <p className="mr-empty" role={billing ? undefined : 'status'}>{billing ? '模型目录中没有路线；请先在官方“模型”页添加模型，再点“刷新”。' : '正在读取计费状态…'}</p>}
        {rows.length > 0 && (
          <div className="mr-table-wrap"><table className="mr-table">
            <thead><tr><th>供应商</th><th>计费方式</th><th>订阅</th><th>订阅状态 / 恢复时间</th><th>API Key 回退</th></tr></thead>
            <tbody>{rows.map(row => (
              <tr key={row.key}>
                <td><strong>{row.provider}</strong><div className="mr-caption">{row.models}</div></td>
                <td>{row.mode}</td>
                <td>{row.subscription}</td>
                <td className={row.exhausted ? 'mr-warn-text' : ''}>{row.state}</td>
                <td className={row.apiAvailable ? '' : 'mr-warn-text'}>{row.api}</td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
        {billing && <p className="mr-caption">厂商没有给出恢复时间时，按设置中的冷却时间（{billing.cooldownMinutes ?? 60} 分钟）暂停使用该订阅。团队执行和单工具调用只能通过官方 CLI 修改文件，额度用尽时会记录并提示，但不会自动改用 API Key。</p>}
      </div>
    </section>
  )
}

/** 安全边界: what each configured route can read and write. */
export function SecurityCard({ data, error, onRefresh }) {
  const rows = data?.boundaries ?? []
  return (
    <section className="mr-card mr-results" aria-label="安全边界">
      <div className="mr-card-head"><div>
        <h2 className="mr-card-title">安全边界</h2>
        <p className="mr-card-copy">每条已配置路线可读、可写的范围和是否经过 Harness 进程沙箱。可编辑运行总是需要你在官方审批中确认；直接启动无沙箱 CLI 前默认也会询问。</p>
      </div><button className="mr-button mr-button-secondary" type="button" onClick={onRefresh}>刷新</button></div>
      <div className="mr-card-body">
        {error && <p className="mr-error" role="alert">{error}</p>}
        {data && !data.sandboxAvailable && <p className="mr-error">当前 Host 没有提供 Harness 进程沙箱：可编辑运行会被拒绝，只读的无界面 CLI 将直接启动。</p>}
        {rows.length === 0 && !error && <p className="mr-empty" role={data ? undefined : 'status'}>{data ? '模型目录中没有路线；请先在官方“模型”页添加模型，再点“刷新”。' : '正在读取安全边界…'}</p>}
        {rows.length > 0 && (
          <div className="mr-table-wrap"><table className="mr-table">
            <thead><tr><th>路线</th><th>只读运行可读</th><th>只读运行沙箱</th><th>可编辑运行</th></tr></thead>
            <tbody>{rows.map(row => (
              <tr key={`${row.provider}/${row.model}`}>
                <td><strong>{row.provider}/{row.model}</strong>{row.toolLabel ? <div className="mr-caption">{row.toolLabel}</div> : <div className="mr-caption">仅 API</div>}</td>
                <td>{row.readOnly.readable}</td>
                <td className={row.readOnly.direct ? 'mr-warn-text' : ''}>{row.readOnly.sandbox}</td>
                <td>{row.write ? `${row.write.writable}；需审批` : '不支持'}</td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>
    </section>
  )
}

/**
 * The two books, side by side. They are never added: one is money, the other is quota.
 * A quantity the Host could not learn stays "未知" here as well.
 */
export function TwoLedgerBooks({ books }) {
  const api = books?.api, subscription = books?.subscription
  if (!api || !subscription) return null
  const money = value => (typeof value === 'number' && Number.isFinite(value) ? formatUsd(value) : '未知')
  const calls = value => (Number.isSafeInteger(value) ? String(value) : '0')
  const tokens = value => (Number.isSafeInteger(value) ? String(value) : '未知')
  return <section className="mr-card mr-books" aria-label="两本账">
    <div className="mr-card-head"><div>
      <h2 className="mr-card-title">两本账</h2>
      <p className="mr-card-copy">API 记钱，订阅记额度。两本账不相加：订阅调用不产生美元费用，API 调用也不消耗订阅额度。</p>
    </div></div>
    <div className="mr-books-grid">
      <div className="mr-book mr-book-api">
        <h3 className="mr-book-title">{api.label} <span className="mr-pill">USD</span></h3>
        <dl className="mr-facts">
          <div className="mr-value"><dt>今日已发生</dt><dd>{money(api.settled?.today)}</dd></div>
          <div className="mr-value"><dt>本月已发生</dt><dd>{money(api.settled?.month)}</dd></div>
          <div className="mr-value"><dt>今日预占</dt><dd>{money(api.reserved?.today)}</dd></div>
          <div className="mr-value"><dt>预算上限（今日 / 本月）</dt><dd>{money(api.limit?.daily)} / {money(api.limit?.monthly)}</dd></div>
        </dl>
        {api.unknown?.today > 0 || api.unknown?.month > 0
          ? <p className="mr-caption mr-warn-text">有 {api.unknown.today} 次（今日）/ {api.unknown.month} 次（本月）调用缺少单价或用量，费用保持未知，不能视为零。</p>
          : null}
        {api.budget?.exceeded ? <p className="mr-error" role="alert">{api.budget.message || '预算已超出。'}</p> : null}
        <p className="mr-caption">不含：{api.excludes}</p>
      </div>
      <div className="mr-book mr-book-subscription">
        <h3 className="mr-book-title">{subscription.label} <span className="mr-pill">次</span></h3>
        <dl className="mr-facts">
          <div className="mr-value"><dt>今日调用</dt><dd>{calls(subscription.today?.calls)}</dd></div>
          <div className="mr-value"><dt>本月调用</dt><dd>{calls(subscription.month?.calls)}</dd></div>
          <div className="mr-value"><dt>今日 token（入 / 出）</dt><dd>{tokens(subscription.today?.inputTokens)} / {tokens(subscription.today?.outputTokens)}</dd></div>
          <div className="mr-value"><dt>本月 token（入 / 出）</dt><dd>{tokens(subscription.month?.inputTokens)} / {tokens(subscription.month?.outputTokens)}</dd></div>
        </dl>
        {subscription.incomplete ? <p className="mr-caption mr-warn-text">{subscription.note}</p> : <p className="mr-caption">{subscription.note}</p>}
        <p className="mr-caption">不含：{subscription.excludes}</p>
      </div>
    </div>
  </section>
}
