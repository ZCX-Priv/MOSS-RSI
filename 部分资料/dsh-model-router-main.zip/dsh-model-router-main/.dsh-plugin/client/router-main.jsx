import React from 'react'
import { createWorkspacePlan, routesFromModelCatalog } from './catalog.mjs'
import { ModelProfileEditor } from './model-profile-editor.jsx'
import { acceptedInstallJob, installClickRefusal, installSummaryMatchesSettings, mutateToolInstallSettings, retainToolInstallDrafts, savedToolInstallMethods, shouldApplyInstallStatus, toolInstallAction, toolInstallSettingsSignature, toolMaintenanceActions, validateToolInstallSetting } from './tool-install-state.mjs'
import { OFFICIAL_TOOLS, installCommandLine, installMethodsFor, toolForProvider } from '../shared/official-tool-registry.mjs'
import { ROUTING_PRESETS } from '../shared/routing-presets.mjs'
import { attentionSummary, deriveAttention } from '../shared/attention.mjs'
import { BillingCard, CostControlCard, TwoLedgerBooks, DagView, OnboardingBanner, RunHistoryCard, SecurityCard, SubscriptionUsageCard, ToolLoginLine } from './router-insights.jsx'
import { apiPlanEstimate, healthSummary, initialPackageAssignments, manualAssignmentOptions, packageEstimateText, planBudget, rerunConfirmations, rerunSupport, reservationSummary, subscriptionEstimateText, unwrapRemote } from './insights-state.mjs'
import { packagePlanKey } from '../shared/package-assignments.mjs'
import { RunLauncher } from './run-launcher.jsx'
import { CliTerminalCard } from './cli-terminal.jsx'
import { remoteErrorText, staleHostNotice } from './host-version.mjs'
import { ADAPTIVE_DEFAULTS } from './adaptive-state.mjs'
import stylesheet from './router-main.css'
import { ROUTER_PACKAGE_NAME } from './package-info.mjs'
import { WORKSPACE_VIEWS, TASK_TEMPLATES, validWorkbenchView, savedWorkbenchView, rememberWorkbenchView, workbenchDraft, rememberWorkbenchDraft } from './workbench-state.mjs'

const money = value => value === null || value === undefined ? '价格待配置' : `$${Number(value).toFixed(4)}`
const text = value => typeof value === 'string' ? value.trim() : ''
const ATTENTION_VISIBILITY_KEY = 'dsh-model-router.workbench.attention-hidden'
const routingSettingsSignature = value => JSON.stringify([
  value.modelProfilesJson, value.routingPreset, value.allowManualReassign,
  ...Object.keys(ADAPTIVE_DEFAULTS).map(key => value[key] ?? ADAPTIVE_DEFAULTS[key]),
])

/** The sidebar owns button layout and selection; this is only its glyph. */
export function RouterPanelIcon({ size = 20, active = false }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M7 6.5h7M7 17.5h7M15 6.5v11" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      <circle cx="5" cy="6.5" r="2" fill={active ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.6" />
      <circle cx="5" cy="17.5" r="2" fill={active ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.6" />
      <circle cx="17" cy="12" r="3" fill={active ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.7" />
    </svg>
  )
}

function RouteList({ routes, query }) {
  const filtered = routes.filter(route => {
    const haystack = `${route.providerName} ${route.provider} ${route.name} ${route.model}`.toLowerCase()
    return haystack.includes(query.toLowerCase())
  })
  if (filtered.length === 0) return <div className="mr-empty">{routes.length === 0 ? '官方模型目录尚无可规划的路线。请先在“模型”页完成配置。' : '没有匹配的模型。'}</div>
  return (
    <div className="mr-list" role="list" aria-label="官方已登记模型路线">
      {filtered.map(route => (
        <div className="mr-route" role="listitem" key={`${route.provider}/${route.model}`}>
          <div style={{ minWidth: 0 }}>
            <div className="mr-route-name" title={route.name}>{route.name}</div>
            <div className="mr-route-provider" title={`${route.provider}/${route.model}`}>{route.provider}/{route.model}</div>
          </div>
          {route.reasoningKnown && <span className="mr-pill">推理等级</span>}
        </div>
      ))}
    </div>
  )
}

function ChannelBadge({ item }) {
  if (!item?.executionChannel) return null
  const official = item.executionChannel === 'official-cli'
  return (
    <span className={official ? 'mr-pill mr-pill-channel-ok' : 'mr-pill'} title={item.channelDetail ?? ''}>
      {official ? `官方 CLI · ${item.channelLabel ?? item.channelTool}` : '模型目录 API'}
    </span>
  )
}

export function PlanResults({ plan, ledger, headingRef, assignmentMode = 'algorithm', packageAssignments = {}, assignmentOptions = [], manualAllowed = true, onAssignmentModeChange, onPackageAssignmentChange, onRestoreAssignments }) {
  const selected = plan.selected
  const estimate = apiPlanEstimate(plan)
  const budget = plan.accounting ? planBudget(ledger, estimate) : null
  const subscriptionEstimate = subscriptionEstimateText(plan)
  const packageNames = new Map((plan.team?.workPackages ?? []).map(item => [item.id, item.name]))
  const purposeLabel = { analysis: '任务分析', execution: '任务实施', verification: '独立验证', synthesis: '结果整合' }
  return (
    <section className="mr-card mr-results" aria-label="路由建议">
      <div className="mr-card-head">
        <div>
          <h2 className="mr-card-title" ref={headingRef} tabIndex={-1}>路由建议</h2>
          <p className="mr-card-copy">本地计算完成，未向模型发送任务内容。</p>
        </div>
      </div>
      <div className="mr-card-body">
        <div className="mr-result-grid">
          <div className="mr-metric"><div className="mr-metric-label">{assignmentMode === 'manual' ? '算法原推荐路线' : '推荐路线'}</div><div className="mr-metric-value">{selected ? `${selected.provider}/${selected.model}` : '暂无路线'}</div></div>
          <div className="mr-metric"><div className="mr-metric-label">任务复杂度 · 分值（0–1）</div><div className="mr-metric-value">{{ simple: '简单', balanced: '中等', complex: '复杂' }[plan.complexity.band] || plan.complexity.band} · {plan.complexity.value}</div></div>
          <div className="mr-metric"><div className="mr-metric-label">{assignmentMode === 'manual' ? '调整前 API 估算' : 'API 预估费用'}</div><div className="mr-metric-value">{plan.accounting ? money(estimate) : '以执行预览为准'}</div></div>
          <div className="mr-metric"><div className="mr-metric-label">路由方案</div><div className="mr-metric-value">{ROUTING_PRESETS[plan.preset]?.label ?? '均衡'}</div></div>
        </div>
        {budget?.exceeded && <p className="mr-error" role="alert">{assignmentMode === 'manual' ? '算法原方案预算提示：' : '执行前预算检查：'}{budget.message} {assignmentMode === 'manual' ? '手动方案将重新预览费用，超预算时暂停确认，不自动替换目标。' : '实际执行时将按设置自动降级或暂停询问。'}</p>}
        {budget?.limited && !budget.exceeded && budget.estimateKnown && <p className="mr-caption">{assignmentMode === 'manual' ? '算法原方案：' : '执行前 API 预算检查：本次预估 '}{money(estimate)}，剩余额度 {money(budget.remainingUsd)}。</p>}
        {subscriptionEstimate && <p className="mr-caption">{subscriptionEstimate} 这是工作包本地估算，不是厂商已使用或剩余额度。</p>}
        {!plan.accounting && <p className="mr-caption">本地规划尚未核验实际计费渠道；API 费用与订阅预估用量以执行预览为准。</p>}
        {plan.loginRequired && <p className="mr-caption">推荐模型的官方 CLI 未登录，执行时按计费设置暂停或使用模型目录 API；可在“官方工具”卡片点“去登录”。</p>}
        <div className="mr-channel-line">
          <span className="mr-control-label">{assignmentMode === 'manual' ? '算法原推荐渠道' : '执行渠道'}</span>
          <ChannelBadge item={plan} />
        </div>
        <details className="mr-plan-explanation"><summary>查看规划依据与估算说明</summary><p className="mr-caption">{plan.reason}</p><p className="mr-caption">{plan.pricingNotice} {plan.qualityNotice} {plan.availabilityNotice} {plan.modalityNotice || ''}</p></details>
        {plan.accounting && Number.isFinite(estimate) && Number(plan.optimization.budgetUsd) > 0 && estimate > Number(plan.optimization.budgetUsd) && <p className="mr-error">按已提供单价估算，API 部分可能超过本次预算。预算只影响建议，不会阻止实际扣费。</p>}
        {!plan.routingBypassed && plan.team && (
          <>
            <h3 className="mr-section-title">{plan.mode === 'team' ? '团队工作包' : '任务工作包'}</h3>
            <div className="mr-assignment-controls">
              <div className="mr-segment" role="group" aria-label="工作包分配方式">
                <button type="button" aria-pressed={assignmentMode === 'algorithm'} onClick={() => onAssignmentModeChange?.('algorithm')}>按算法推荐分配</button>
                <button type="button" aria-pressed={assignmentMode === 'manual'} disabled={!manualAllowed || !plan.team.workPackages.length} title={!manualAllowed ? '设置中已关闭手动改派' : '为每个工作包选择模型 API 或官方工具'} onClick={() => onAssignmentModeChange?.('manual')}>手动调整分配</button>
              </div>
              {assignmentMode === 'manual' && <button className="mr-button mr-button-secondary" type="button" onClick={onRestoreAssignments}>恢复推荐分配</button>}
            </div>
            {!manualAllowed && <p className="mr-caption">设置中已关闭手动改派。</p>}
            <p className="mr-caption">{assignmentMode === 'manual'
              ? '手动分配可混合模型 API 与官方工具，按依赖执行只读任务；工具使用默认模型。上方费用仍是算法建议估算，手动目标与费用以执行预览为准，预览会核验套餐计费与工具就绪状态。'
              : '下方模型是工作包的规划建议。模型路由按只读方式执行，每步可使用官方 CLI 或模型目录 API；如需编辑文件，可在下方执行区选择“官方工具协作”和“编辑文件”权限。CLI 请求模型名需符合厂商规则，实际模型以运行记录为准。'}</p>
            {plan.team.workPackages.length > 1 && <DagView packages={plan.team.workPackages} label="工作包依赖图" renderNode={item => <p className="mr-package-route">算法推荐：{item.recommendedProvider}/{item.recommendedModel}</p>} />}
            {plan.team.workPackages.length === 0
              ? <div className="mr-empty">当前目录没有可分配的模型路线。</div>
              : plan.team.workPackages.map((item, index) => (
                <details className="mr-package mr-package-details" key={item.id} open={assignmentMode === 'manual' ? true : undefined}>
                  <summary><span className="mr-package-name">{index + 1}. {item.name}</span><span className="mr-package-route">算法推荐：{item.recommendedProvider}/{item.recommendedModel}</span></summary>
                  {assignmentMode === 'manual' && <div className="mr-assignment-target">
                    <label htmlFor={`mr-assignment-${item.id}`}>{item.name} 执行目标</label>
                    <select className="mr-input" id={`mr-assignment-${item.id}`} value={JSON.stringify(packageAssignments[item.id] ?? {})}
                      onChange={event => { const option = assignmentOptions.find(candidate => candidate.value === event.target.value && !candidate.disabled); if (option) onPackageAssignmentChange?.(item.id, { ...option.binding }) }}>
                      <optgroup label="模型目录 API">{assignmentOptions.filter(option => option.binding.kind === 'api').map(option => <option key={option.value} value={option.value} disabled={option.disabled}>{option.label}</option>)}</optgroup>
                      <optgroup label="官方工具（默认模型）">{assignmentOptions.filter(option => option.binding.kind === 'tool').map(option => <option key={option.value} value={option.value} disabled={option.disabled}>{option.label}</option>)}</optgroup>
                    </select>
                  </div>}
                  {item.objective && <p className="mr-package-copy">具体目标：{item.objective}</p>}
                  <p className="mr-package-copy">{purposeLabel[item.purpose] ?? item.purpose}{item.dependsOn.length > 0 ? ` · 依赖：${item.dependsOn.map(id => packageNames.get(id) ?? id).join('、')}` : ''}</p>
                  <p className="mr-package-copy">难度：{{ simple: '简单', balanced: '中等', complex: '困难' }[item.difficulty] || item.difficulty || '待评估'} · {plan.accounting ? packageEstimateText(plan, item) : '费用与订阅用量待执行预览核验'}</p>
                  <p className="mr-package-copy">验收：{item.verificationChecklist.join('；')}</p>
                  <div className="mr-channel-line">{assignmentMode === 'manual' && <span className="mr-caption">原推荐渠道：</span>}<ChannelBadge item={item} />{item.loginRequired && <span className="mr-pill">CLI 未登录</span>}</div>
                  {item.channelDetail && <p className="mr-package-copy">渠道说明：{item.channelDetail}</p>}
                </details>
              ))}
          </>
        )}
        {plan.routingBypassed && <p className="mr-caption">已指定单一模型，未与其他路线比较。在官方会话中调用 <code>model_router_execute</code> 并传入该 provider 与 model 即可直接执行；若该模型允许官方工具，会优先使用对应 CLI。</p>}
        {plan.mode === 'team' && assignmentMode !== 'manual' && <p className="mr-caption">{plan.team.handoff}</p>}
      </div>
    </section>
  )
}

const remoteError = (response, fallback) => remoteErrorText(
  text(response?.error?.message) || text(response?.value?.error) || (typeof response?.error === 'string' ? response.error : ''),
  fallback,
)

function probeLabel(probe) {
  if (!probe) return '尚未检测'
  if (probe.installed) return `已安装${probe.version ? ` · ${probe.version}` : ''}`
  if (probe.status === 'not-installed') return '未安装'
  if (probe.status === 'probe-timeout') return '检测超时'
  if (probe.status === 'probe-failed') return '检测失败'
  return probe.detail || '未安装'
}

/**
 * The unified install settings the user can change from the workbench itself.
 * They live in volatile plugin config, so a change applies to every later
 * one-click install, repair and uninstall, and to `/tools` and the agent tools
 * as well. Drafts are saved together so a directory and download source change
 * cannot leave the install controls showing a partly saved configuration.
 */
const INSTALL_SETTING_FIELDS = [
  { key: 'toolInstallDir', label: '统一安装根目录', fallback: '', placeholder: '留空 = 各厂商默认目录',
    hint: '例如 D:/AI/tools。npm / pnpm 使用该根；厂商脚本使用工具专属子目录，实际地址见工具行。固定厂商地址的方式会说明原因。' },
  { key: 'toolNpmRegistry', label: 'npm 源地址', fallback: 'https://registry.npmjs.org/', placeholder: 'https://registry.npmjs.org/',
    hint: '必须以 https:// 开头。所有 npm / pnpm 方式共用此下载源，例如 https://registry.npmmirror.com/。' },
  { key: 'toolScriptUrlsJson', label: '安装脚本源覆盖（JSON，可选）', fallback: '{}',
    placeholder: '{ "stepcode": "https://mirror/stepcode/install.ps1" }',
    hint: '按工具 ID 指定 https 镜像地址。脚本下载后仍会核对厂商标记，再执行本地副本。' },
]

function InstallSettings({ settingsScope, install, onPendingChange, onMutationStart }) {
  const [snapshot, setSnapshot] = React.useState(() => settingsScope?.getSnapshot?.() ?? { value: {}, writable: false })
  const [drafts, setDrafts] = React.useState({})
  const [saving, setSaving] = React.useState(false)
  const [notice, setNotice] = React.useState('')

  React.useEffect(() => {
    if (typeof settingsScope?.subscribe !== 'function') return undefined
    const unsubscribe = settingsScope.subscribe(() => {
      const next = settingsScope.getSnapshot()
      setSnapshot(next)
      setDrafts(previous => retainToolInstallDrafts(previous, next.value))
    })
    setSnapshot(settingsScope.getSnapshot())
    return unsubscribe
  }, [settingsScope])
  const dirty = Object.keys(drafts).length > 0
  React.useEffect(() => { onPendingChange?.(saving || dirty) }, [saving, dirty, onPendingChange])
  if (!settingsScope) return null

  const writable = snapshot.writable === true && !saving
  const shown = field => drafts[field.key] ?? String(snapshot.value?.[field.key] ?? field.fallback)
  const fields = INSTALL_SETTING_FIELDS
  const errors = Object.fromEntries(fields.map(field => [field.key, validateToolInstallSetting(field.key, shown(field))]))
  const invalid = Object.values(errors).some(Boolean)
  const edit = (key, value) => {
    const next = retainToolInstallDrafts({ ...drafts, [key]: value }, snapshot.value)
    onPendingChange?.(saving || Object.keys(next).length > 0)
    setNotice('')
    setDrafts(next)
  }

  const apply = async () => {
    if (!writable || !dirty || invalid) return
    setSaving(true)
    onPendingChange?.(true)
    setNotice('')
    try {
      const entries = Object.entries(drafts).map(([key, value]) => ({ op: 'set', path: [key], value }))
      const finishMutation = onMutationStart?.(entries)
      const onSettled = outcome => {
        const current = finishMutation?.(outcome)
        if (current && outcome.accepted) setNotice('安装设置已保存。')
      }
      const accepted = await mutateToolInstallSettings(settingsScope, entries, snapshot.revision, { onSettled })
      if (!accepted) throw new Error('设置未被保存，可能被其他页面修改；输入已保留，请重新核对。')
      const next = settingsScope.getSnapshot()
      setSnapshot(next)
      setDrafts(previous => retainToolInstallDrafts(previous, next.value))
      setNotice('安装设置已保存。')
    } catch (error) {
      setNotice(text(error?.message) || '安装设置保存失败。')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="mr-install-settings" aria-label="统一安装设置">
      <div className="mr-install-settings-head">
        <strong>统一安装设置</strong>
        <span className="mr-caption">保存后用于后续安装与更新。每个工具下方显示实际方式和目录，插件设置页里也能修改。</span>
      </div>
      <div className="mr-install-grid">
        {fields.map(field => (
          <label className="mr-install-field" key={field.key}>
            <span>{field.label}</span>
            <input
              className="mr-input"
              value={shown(field)}
              placeholder={field.placeholder}
              disabled={!writable}
              aria-invalid={Boolean(errors[field.key])}
              onChange={event => edit(field.key, event.target.value)}
            />
            {errors[field.key]
              ? <small className="mr-install-error" role="alert">{errors[field.key]}</small>
              : <small>{field.hint}</small>}
          </label>
        ))}
        <label className="mr-install-field">
          <span>安装脚本方式</span>
          <span className="mr-install-toggle-row">
            <input
              type="checkbox"
              checked={(drafts.toolAllowScriptInstall ?? snapshot.value?.toolAllowScriptInstall) !== false}
              disabled={!writable}
              onChange={event => {
                edit('toolAllowScriptInstall', event.target.checked)
              }}
            />
            <span>允许 curl / irm 安装脚本</span>
          </span>
          <small>关闭后仍可使用 npm / pnpm 和 GitHub Release 发行包；脚本方式需先下载并核对厂商标记。</small>
        </label>
      </div>
      <div className="mr-install-save-row">
        <button className="mr-button mr-button-secondary" type="button" disabled={!writable || !dirty || invalid} onClick={() => { void apply() }}>{saving ? '保存中…' : '保存安装设置'}</button>
        {dirty && <button className="mr-button mr-button-secondary" type="button" disabled={saving} onClick={() => { setDrafts({}); setNotice(''); onPendingChange?.(false) }}>放弃更改</button>}
        {dirty && <span className="mr-caption">{invalid ? '请修正输入后保存。' : '更改尚未保存，安装与更新暂不可用。'}</span>}
      </div>
      <p className="mr-caption" style={{ marginTop: 8 }} role={notice ? 'status' : undefined}>
        {`当前生效：安装目录 ${install?.installDir || '（各厂商默认）'} · npm 源 ${install?.registry || '（默认）'}`}{notice ? ` · ${notice}` : ''}
      </p>
    </div>
  )
}

export function OfficialToolsCard({ listOfficialTools, loadOfficialInstallSettings, installOfficialTool, uninstallOfficialTool, repairOfficialTool, cancelOfficialToolInstall, officialToolInstallStatus, onProbes, health, onRefreshHealth, settingsScope, tuiPrompt }) {
  const healthById = Object.fromEntries((health?.tools ?? []).map(item => [item.id, item]))
  const [probeState, setProbeState] = React.useState({ status: 'loading', probes: [], capabilities: [], readiness: [], install: null, error: '' })
  const [jobs, setJobs] = React.useState({})
  const [rowErrors, setRowErrors] = React.useState({})
  const [settingsPending, setSettingsPending] = React.useState(false)
  const [methodSaving, setMethodSaving] = React.useState(null)
  const [previewPending, setPreviewPending] = React.useState(false)
  const [settingsSnapshot, setSettingsSnapshot] = React.useState(() => settingsScope?.getSnapshot?.() ?? { value: {}, writable: false })
  const [previewError, setPreviewError] = React.useState('')
  const [probeSettingsStale, setProbeSettingsStale] = React.useState(false)
  // A probe that never settles must say so instead of spinning: the Host can be busy, and
  // "正在检测" forever looks exactly like a broken check.
  React.useEffect(() => {
    if (probeState.status !== 'loading' && probeState.status !== 'refreshing') return
    const timer = setTimeout(() => {
      setProbeState(previous => (previous.status === 'loading' || previous.status === 'refreshing')
        ? previous.probes.length > 0
          ? { ...previous, status: 'ready', error: '体检超时：部分工具的结果没有返回，已显示已有结果。可点“重新体检”。' }
          : { ...previous, status: 'error', error: '体检超时：Host 45 秒内没有返回检测结果，请点“重新体检”。' }
        : previous)
    }, 45_000)
    return () => clearTimeout(timer)
  }, [probeState.status])
  const settingsPendingRef = React.useRef(false)
  const methodSavingRef = React.useRef(null)
  const previewPendingRef = React.useRef(false)
  const mounted = React.useRef(false)
  const request = React.useRef(0)
  const previewRequest = React.useRef(0)
  const mutationGeneration = React.useRef(0)
  const mutationPendingRef = React.useRef(null)
  const submitting = React.useRef(new Set())
  const polling = React.useRef(new Set())
  const jobsRef = React.useRef({})
  const handleSettingsPending = React.useCallback(value => {
    settingsPendingRef.current = value
    setSettingsPending(value)
  }, [])
  const rememberJobs = updater => {
    setJobs(previous => {
      const next = typeof updater === 'function' ? updater(previous) : updater
      jobsRef.current = next
      return next
    })
  }

  const refresh = async () => {
    onRefreshHealth?.()
    const current = ++request.current
    const settingsSignature = toolInstallSettingsSignature(settingsScope?.getSnapshot?.()?.value)
    setProbeState(previous => ({
      ...previous,
      status: previous.probes.length > 0 || previous.install ? 'refreshing' : 'loading',
      error: '',
    }))
    try {
      if (typeof listOfficialTools !== 'function') throw new Error('官方工具安装桥尚未加载。')
      const response = await listOfficialTools()
      if (!mounted.current || current !== request.current) return
      if (!response?.ok) throw new Error(remoteError(response, '无法检测官方工具。'))
      const probes = Array.isArray(response.value?.tools) ? response.value.tools : []
      const capabilities = Array.isArray(response.value?.executionCapabilities) ? response.value.executionCapabilities : []
      const readiness = Array.isArray(response.value?.executionReadiness) ? response.value.executionReadiness : []
      // A settings write can finish while the probes run. The probes still describe the
      // Host's own saved settings, so they are accepted; only the command preview — which
      // is what a stale settings signature would misrepresent — is held back.
      const install = response.value?.install
      const matches = settingsSignature === toolInstallSettingsSignature(settingsScope?.getSnapshot?.()?.value)
        && installSummaryMatchesSettings(install, settingsScope?.getSnapshot?.()?.value)
      setProbeState(previous => ({ status: 'ready', probes, capabilities, readiness,
        install: matches ? install : previous.install, error: '' }))
      setProbeSettingsStale(!matches)
      if (matches && !mutationPendingRef.current) {
        previewPendingRef.current = false
        setPreviewPending(false)
        setPreviewError('')
      }
      onProbes({ probes, capabilities, readiness, hostVersion: typeof response.value?.hostVersion === 'string' ? response.value.hostVersion : null })
    } catch (error) {
      if (!mounted.current || current !== request.current) return
      const message = remoteErrorText(text(error?.message), '无法检测官方工具。')
      let kept = false
      setProbeState(previous => {
        if (previous.probes.length > 0 || previous.install) {
          kept = true
          return { ...previous, status: 'ready', error: message }
        }
        return { status: 'error', probes: [], capabilities: [], readiness: [], install: null, error: message }
      })
      if (!kept) onProbes({ probes: [], capabilities: [], readiness: [] })
    }
  }

  const refreshInstallSettings = async () => {
    const current = ++previewRequest.current
    const snapshot = settingsScope?.getSnapshot?.()
    const signature = toolInstallSettingsSignature(snapshot?.value)
    previewPendingRef.current = true
    setPreviewPending(true)
    setPreviewError('')
    try {
      if (typeof loadOfficialInstallSettings !== 'function') throw new Error('安装设置桥尚未加载，请更新 Host 后重新打开工作台。')
      const response = await loadOfficialInstallSettings()
      if (!mounted.current || current !== previewRequest.current
        || signature !== toolInstallSettingsSignature(settingsScope?.getSnapshot?.()?.value)) return
      if (!response?.ok) throw new Error(remoteError(response, '无法读取安装设置。'))
      if (!installSummaryMatchesSettings(response.value?.install, settingsScope?.getSnapshot?.()?.value)) {
        throw new Error('设置已保存，但 Host 安装配置尚未同步；请刷新安装命令后再安装。')
      }
      setProbeState(previous => ({ ...previous, status: previous.status === 'loading' || previous.status === 'error' ? 'ready' : previous.status,
        install: response.value.install }))
      if (!mutationPendingRef.current) {
        previewPendingRef.current = false
        setPreviewPending(false)
      }
    } catch (error) {
      if (mounted.current && current === previewRequest.current) setPreviewError(text(error?.message) || '安装命令刷新失败。')
    }
  }

  React.useEffect(() => {
    mounted.current = true
    void refresh()
    void refreshInstallSettings()
    if (typeof officialToolInstallStatus === 'function') {
      void Promise.all(OFFICIAL_TOOLS.map(async tool => {
        try {
          const response = await officialToolInstallStatus(tool.id)
          return response?.ok && response.value?.job ? [tool.id, response.value.job] : null
        } catch { return null }
      })).then(entries => {
        if (!mounted.current) return
        rememberJobs(previous => {
          const next = { ...previous }
          for (const entry of entries) {
            if (!entry) continue
            const [id, job] = entry
            if (shouldApplyInstallStatus(previous[id], job)) next[id] = job
          }
          return next
        })
      })
    }
    return () => { mounted.current = false; request.current += 1; previewRequest.current += 1 }
  }, [])

  const refreshInstallSettingsRef = React.useRef(refreshInstallSettings)
  refreshInstallSettingsRef.current = refreshInstallSettings
  const beginSettingsMutation = React.useCallback(operations => {
    const generation = ++mutationGeneration.current
    mutationPendingRef.current = { generation, operations }
    previewPendingRef.current = true
    setPreviewPending(true)
    return () => {
      if (!mounted.current || mutationPendingRef.current?.generation !== generation) return false
      mutationPendingRef.current = null
      // A late SDK answer is reflected by its real snapshot. It never applies
      // the originally requested value or settles a newer operation's state.
      void refreshInstallSettingsRef.current()
      return true
    }
  }, [])
  React.useEffect(() => {
    if (typeof settingsScope?.subscribe !== 'function') return undefined
    const signature = snapshot => toolInstallSettingsSignature(snapshot?.value)
    let previous = signature(settingsScope.getSnapshot())
    return settingsScope.subscribe(() => {
      const snapshot = settingsScope.getSnapshot()
      setSettingsSnapshot(snapshot)
      const next = signature(snapshot)
      if (next === previous) return
      previous = next
      request.current += 1
      setProbeSettingsStale(true)
      setProbeState(previous => ({ ...previous, status: 'ready', probes: [], readiness: [], error: '' }))
      onProbes({ probes: [], capabilities: [], readiness: [] })
      previewPendingRef.current = true
      setPreviewPending(true)
      void refreshInstallSettingsRef.current()
    })
  }, [settingsScope])

  React.useEffect(() => {
    const active = Object.values(jobs).filter(job => job?.status === 'running').map(job => job.tool)
    if (active.length === 0 || typeof officialToolInstallStatus !== 'function') return undefined
    let listening = true
    const poll = async id => {
      if (polling.current.has(id)) return
      polling.current.add(id)
      try {
        const response = await officialToolInstallStatus(id)
        if (!listening || !mounted.current) return
        if (!response?.ok) throw new Error(remoteError(response, '无法获取安装进度。'))
        const job = response.value?.job
        const local = jobsRef.current[id]
        if (!job) {
          if (local?.status === 'running') return
          throw new Error('安装任务状态暂不可用。')
        }
        if (!shouldApplyInstallStatus(local, job)) return
        rememberJobs(previous => shouldApplyInstallStatus(previous[id], job) ? { ...previous, [id]: job } : previous)
        setRowErrors(previous => ({
          ...previous,
          [id]: job.status === 'failed' ? (text(job.error) || '安装失败。') : '',
        }))
        if (job.status !== 'running') void refresh()
      } catch (error) {
        if (listening && mounted.current) setRowErrors(previous => ({ ...previous, [id]: remoteErrorText(text(error?.message), '安装状态读取失败，将继续重试。') }))
      } finally {
        polling.current.delete(id)
      }
    }
    const timer = setInterval(() => active.forEach(id => { void poll(id) }), 1_500)
    return () => { listening = false; clearInterval(timer) }
  }, [jobs, officialToolInstallStatus])

  /**
   * Start one tool operation through the matching bridge. Install, repair and
   * uninstall share a job slot per tool, so only one of them can run at a time
   * and the row shows whichever one is in flight.
   */
  const run = async (id, operation) => {
    const tool = OFFICIAL_TOOLS.find(item => item.id === id)
    const summary = (probeState.install?.tools ?? []).find(item => item.id === id)
    const bridge = { install: installOfficialTool, repair: repairOfficialTool, uninstall: uninstallOfficialTool }[operation]
    const refusal = installClickRefusal({
      tool,
      submitting: submitting.current.has(id),
      running: jobsRef.current[id]?.status === 'running',
      operation,
      pendingSettings: settingsPendingRef.current || Boolean(methodSavingRef.current) || previewPendingRef.current,
      installError: operation === 'uninstall'
        ? summary?.uninstallError ?? (summary?.uninstallCommand ? '' : summary?.error ?? '')
        : summary?.installError ?? summary?.error ?? '',
    })
    if (refusal) {
      setRowErrors(previous => ({ ...previous, [id]: refusal }))
      return
    }
    if (typeof bridge !== 'function') {
      setRowErrors(previous => ({ ...previous, [id]: '官方工具安装桥尚未加载。' }))
      return
    }
    submitting.current.add(id)
    const startedAt = new Date().toISOString()
    setRowErrors(previous => ({ ...previous, [id]: '' }))
    rememberJobs(previous => ({
      ...previous,
      [id]: { tool: id, operation, status: 'running', outputTail: [], startedAt, error: null },
    }))
    try {
      const response = await bridge({ tool: id })
      if (!mounted.current) return
      const accepted = acceptedInstallJob(response)
      if (!accepted.job) throw new Error(remoteErrorText(accepted.error, '任务未被接受。'))
      rememberJobs(previous => (
        shouldApplyInstallStatus(previous[id], accepted.job) ? { ...previous, [id]: accepted.job } : previous
      ))
    } catch (error) {
      if (!mounted.current) return
      const message = remoteErrorText(text(error?.message), '启动失败。')
      rememberJobs(previous => ({
        ...previous,
        [id]: {
          ...(previous[id] ?? {}),
          tool: id,
          status: 'failed',
          error: message,
          startedAt: previous[id]?.startedAt || startedAt,
        },
      }))
      setRowErrors(previous => ({ ...previous, [id]: message }))
    } finally {
      submitting.current.delete(id)
    }
  }

  const install = id => run(id, 'install')
  const repair = id => run(id, 'repair')
  const uninstall = id => run(id, 'uninstall')

  /**
   * Pin one tool's install method. It is written to the same volatile config
   * the settings card edits, so `/tools install stepcode irm` and the agent
   * tools honour it too; the current map is read from the form rather than
   * from the last probe so two rows edited in a row cannot clobber each other.
   */
  const setInstallMethod = async (toolId, methodId) => {
    const snapshot = settingsScope?.getSnapshot?.()
    if (!snapshot?.writable || methodSavingRef.current || settingsPendingRef.current) return
    methodSavingRef.current = toolId
    setMethodSaving(toolId)
    setRowErrors(previous => ({ ...previous, [toolId]: '' }))
    let map = {}
    try { map = JSON.parse(String(snapshot.value?.toolInstallMethodsJson ?? '{}')) || {} } catch { map = {} }
    if (typeof map !== 'object' || Array.isArray(map)) map = {}
    if (methodId) map[toolId] = methodId
    else delete map[toolId]
    try {
      const operations = [{ op: 'set', path: ['toolInstallMethodsJson'], value: JSON.stringify(map) }]
      const finishMutation = beginSettingsMutation(operations)
      const onSettled = outcome => {
        if (finishMutation(outcome) && outcome.accepted) setRowErrors(previous => ({ ...previous, [toolId]: '' }))
      }
      const accepted = await mutateToolInstallSettings(settingsScope, operations, snapshot.revision, { onSettled })
      if (!accepted) throw new Error('安装方式未被保存，可能被其他页面修改。')
      setSettingsSnapshot(settingsScope.getSnapshot())
    } catch (error) {
      if (mounted.current) setRowErrors(previous => ({ ...previous, [toolId]: text(error?.message) || '安装方式保存失败。' }))
    } finally {
      methodSavingRef.current = null
      if (mounted.current) setMethodSaving(null)
    }
  }

  const cancel = async id => {
    if (typeof cancelOfficialToolInstall !== 'function' || jobs[id]?.status !== 'running' || jobs[id]?.cancelRequested) return
    setRowErrors(previous => ({ ...previous, [id]: '' }))
    try {
      const response = await cancelOfficialToolInstall(id)
      if (!mounted.current) return
      if (!response?.ok || !response.value?.accepted || !response.value?.job) throw new Error(remoteError(response, '取消请求未被接受。'))
      rememberJobs(previous => ({ ...previous, [id]: response.value.job }))
      if (response.value.job.status !== 'running') void refresh()
    } catch (error) {
      if (mounted.current) setRowErrors(previous => ({ ...previous, [id]: text(error?.message) || '无法取消安装。' }))
    }
  }

  const byId = Object.fromEntries(probeState.probes.map(probe => [probe.id, probe]))
  const capabilitiesById = Object.fromEntries(probeState.capabilities.map(item => [item.id, item]))
  const readinessById = Object.fromEntries(probeState.readiness.map(item => [item.id, item]))
  const installById = Object.fromEntries((probeState.install?.tools ?? []).map(item => [item.id, item]))
  const savedMethods = savedToolInstallMethods(settingsSnapshot.value)
  return (
    <section className="mr-card" aria-label="官方工具">
      <div className="mr-card-head"><div>
        <h2 className="mr-card-title">官方工具 · 体检</h2>
        <p className="mr-card-copy">检测本机官方工具的安装、版本和登录状态，并从固定注册表一键安装或更新到各厂商最新版（新版本未经插件测试）。可按工具选择 npm、pnpm、厂商安装脚本或经过校验的发行包，并统一设置安装目录与下载源；卸载只删除程序，配置与登录保留。未登录的工具点“去登录”查看登录命令。ZCode CLI 可选择 npm 社区包或 GitHub Release 发行包，按所选方式使用安装目录设置。</p>
      </div><button className="mr-button mr-button-secondary" type="button" disabled={probeState.status === 'loading'} onClick={() => { void refresh() }}>重新体检</button></div>
      <div className="mr-card-body">
        <InstallSettings settingsScope={settingsScope} install={probeState.install} onPendingChange={handleSettingsPending} onMutationStart={beginSettingsMutation} />
        {previewPending && <p className="mr-caption" role="status">安装设置已变更，正在刷新实际安装命令；仍可切换方式，刷新完成后可安装与更新。{!previewError && <button className="mr-button mr-button-secondary" type="button" onClick={() => { void refreshInstallSettings() }}>刷新安装命令</button>}</p>}
        {previewError && <p className="mr-error" role="alert">{previewError} <button className="mr-button mr-button-secondary" type="button" onClick={() => { void refreshInstallSettings() }}>刷新安装命令</button></p>}
        {probeSettingsStale && <p className="mr-caption" role="status">安装设置已更改，旧目标的版本与安装状态已过期。可安装所选目标；卸载前请重新体检。</p>}
        {probeState.status === 'loading' && <p className="mr-empty" role="status">正在检测本机官方工具…</p>}
        {probeState.error && <p className="mr-error" role="alert">{probeState.error}</p>}
        <div className="mr-tools" role="list" aria-label="官方工具注册表">
          {OFFICIAL_TOOLS.map(tool => {
            const summary = installById[tool.id]
            // The Host resolves the effective command against the current
            // settings; the registry copy is only the fallback for an older Host.
            const command = summary ? summary.command : installCommandLine(tool)
            const updateCommand = summary?.updateCommand ?? command
            const methods = summary?.methods ?? installMethodsFor(tool).map(method => ({ id: method.id, label: method.label }))
            const settingsBusy = settingsPending || Boolean(methodSaving) || previewPending
            const probe = byId[tool.id]
            const capability = capabilitiesById[tool.id]
            const readiness = readinessById[tool.id]
            const readyModes = readiness?.readyModes ?? readiness?.modes ?? capability?.modes ?? []
            const job = jobs[tool.id]
            const running = job?.status === 'running'
            const action = toolInstallAction({ tool, probe, readiness, job, probeStatus: probeState.status, latestVersion: healthById[tool.id]?.latestVersion ?? null })
            const maintenance = toolMaintenanceActions({
              tool, probe, job, probeStatus: probeState.status,
              summary: {
                installable: !(summary?.installError ?? summary?.error),
                removable: !(summary?.uninstallError ?? (summary?.uninstallCommand ? '' : summary?.error)),
              },
            })
            const verified = Boolean(probe) && job?.status === 'succeeded' && (job.operation === 'uninstall'
              ? job.postInstallProbe?.installed === false
              : job.postInstallProbe?.installed === true)
            const operation = job?.operation === 'uninstall' ? '卸载' : job?.operation === 'repair' ? '修复' : '安装'
            const status = running ? job.cancelRequested ? `正在取消${operation}…` : `${operation}中…`
              : job?.status === 'cancelled' ? `${operation}已取消，请重新检测`
                  : verified ? `${operation}成功并验证` : probe ? probeLabel(probe) : '所选安装目标尚未体检'
            return (
              <div className="mr-tool" role="listitem" key={tool.id}>
                <div className="mr-tool-info">
                  <div className="mr-route-name" title={tool.purpose}>{tool.label}</div>
                  <div className="mr-route-provider">{tool.vendor} · {tool.id}</div>
                  <div className="mr-tool-status" role="status"><span className={`mr-tool-dot ${running ? 'running' : probe?.installed ? 'installed' : 'missing'}`} />{status}{probe?.installed && probe.version ? ` · ${probe.version}` : ''}{healthById[tool.id]?.latestVersion ? ` · 最新 ${healthById[tool.id].latestVersion}` : ''}</div>
                  <ToolLoginLine entry={healthById[tool.id]} />
                  {probe?.installed && <p className="mr-caption mr-tool-detail">{tool.taskBackend === true ? '可登记为子任务：Bot 派发的 CLI 步骤会进入统一任务系统（依赖、取消、重试、收据），收据分别记录请求模型与实际模型。' : tool.headlessAdapter
                    ? '只读路由任务可尝试官方无界面 CLI；API 回退按计费与失败处理设置执行。此工具未支持官方隔离工作区团队入口。'
                    : readiness?.ready
                    ? `执行入口已核验：${readyModes.includes('read-only') ? '支持只读任务' : '不支持只读任务'}；${readyModes.includes('workspace-write') ? '支持可编辑隔离工作区任务（需审批）' : '不支持可编辑任务'}。实际调用还需当前会话权限、账号与模型可用。`
                    : `已安装，但当前不可托管执行：${readiness?.reason || capability?.reason || '执行入口尚未核验。'}`}</p>}
                  {command
                    ? <>
                      <p className="mr-caption mr-tool-detail">安装方式：{methods.find(method => method.id === summary?.methodId)?.label ?? tool.manager} · 实际安装目录：{probe?.installDir || summary?.installDir || '各厂商默认目录'}</p>
                      <code className="mr-tool-command" aria-label={`${tool.label} 安装命令`}>{command}</code>
                      {updateCommand !== command && <>
                        <p className="mr-caption mr-tool-detail">更新沿用原安装位置：{summary?.updateInstallDir || '各厂商默认目录'}</p>
                        <code className="mr-tool-command" aria-label={`${tool.label} 更新命令`}>{updateCommand}</code>
                      </>}
                    </>
                    : <p className="mr-caption" style={{ margin: '6px 0 0' }}>{summary?.error ?? tool.unsupportedReason}</p>}
                  {(summary?.notices ?? []).map(notice => <p className="mr-caption mr-tool-detail" key={notice}>{notice}</p>)}
                  {probe?.detail && <p className="mr-caption mr-tool-detail">{probe.detail}</p>}
                  {tool.tuiPrompt === true && tuiPrompt ? <TuiPromptBox tool={tool} tuiPrompt={tuiPrompt} /> : null}
                  {(rowErrors[tool.id] || job?.error) && <p className="mr-error mr-tool-error" role="alert">{rowErrors[tool.id] || job.error}</p>}
                  {Array.isArray(job?.outputTail) && job.outputTail.length > 0 && (
                    <details className="mr-tool-log"><summary>安装日志</summary><pre>{job.outputTail.slice(-6).join('\n')}</pre></details>
                  )}
                </div>
                {(command || methods.length > 0) && (
                  <div className="mr-tool-actions">
                    {methods.length > 0 && <div className="mr-tool-methods">
                      <label>
                        <span>安装方式</span>
                        <select
                          className="mr-mini-select"
                          value={savedMethods[tool.id] ?? ''}
                          disabled={running || settingsPending || Boolean(methodSaving) || settingsSnapshot.writable !== true}
                          onChange={event => { void setInstallMethod(tool.id, event.target.value) }}
                        >
                          <option value="">自动选择</option>
                          {methods.map(method => (
                            <option key={method.id} value={method.id} disabled={Boolean(method.blocked)}>
                              {method.label}{method.blocked ? `（${method.blocked}）` : ''}
                            </option>
                          ))}
                        </select>
                      </label>
                    </div>}
                    <button className="mr-button mr-tool-button" type="button" disabled={action.disabled || settingsBusy || !command || Boolean(summary?.error)} title={summary?.error || (settingsBusy ? '请先保存或放弃安装设置更改，并等待命令刷新。' : undefined)} onClick={() => { void install(tool.id) }}>
                      {methodSaving === tool.id ? '保存方式中…' : action.label}
                    </button>
                    <button className="mr-button mr-button-secondary mr-tool-button" type="button" disabled={maintenance.repair.disabled || settingsBusy} title={maintenance.repair.title} onClick={() => { void repair(tool.id) }}>
                      {maintenance.repair.label}
                    </button>
                    <button className="mr-button mr-button-secondary mr-tool-button" type="button" disabled={maintenance.uninstall.disabled || settingsBusy} title={maintenance.uninstall.title} onClick={() => { void uninstall(tool.id) }}>
                      {maintenance.uninstall.label}
                    </button>
                    {running && <button className="mr-button mr-button-secondary mr-tool-button" type="button" disabled={job.cancelRequested} onClick={() => { void cancel(tool.id) }}>
                      {job.cancelRequested ? '正在取消…' : `取消${operation}`}
                    </button>}
                  </div>
                )}
              </div>
            )
          })}
        </div>
        <p className="mr-caption" style={{ marginTop: 12 }}>
          安装目录与下载源使用已保存设置，命令上方显示实际执行方式。可点“取消”终止下载任务，随后重新检测版本。卸载保留配置、登录信息和历史记录；脚本方式只移除登记的命令入口，可能保留厂商版本目录。不支持安全卸载的方式会说明原因。ZCode CLI 可从已保存的 npm 源安装完整运行包，或下载固定 GitHub Release 并校验 SHA-256。会话与 Agent 也可使用 <code>/tools</code>、<code>model_router_tool_install</code>、<code>model_router_tool_repair</code> 和 <code>model_router_tool_uninstall</code>。
        </p>
      </div>
    </section>
  )
}

/** Root-scoped official Desktop panel. The plan is local; real calls remain in Host tools. */
const HEADLESS_TOOLS = new Set(['claude-code', 'codex', 'gemini'])
/** Workbench RPC state: health check, run ledger and security boundaries. */
function useWorkbenchData({ toolHealth, completeOnboarding, loadLedger, rateResult, rerunStep, loadBoundaries }) {
  const [health, setHealth] = React.useState({ report: null, error: '', refreshing: false })
  const [ledger, setLedger] = React.useState({ value: null, error: '', refreshing: false })
  const [boundaries, setBoundaries] = React.useState({ value: null, error: '' })
  const [busy, setBusy] = React.useState(false)
  const mounted = React.useRef(true)
  const ledgerRequest = React.useRef(0)
  const mutationBusy = React.useRef(false)
  React.useEffect(() => {
    mounted.current = true
    return () => { mounted.current = false; ledgerRequest.current += 1 }
  }, [])
  const call = async (operation, fallback) => {
    if (typeof operation !== 'function') throw new Error('工作台服务尚未加载，请更新插件后重试。')
    return unwrapRemote(await operation(), fallback)
  }
  const refreshHealth = async fresh => {
    setHealth(previous => ({ ...previous, refreshing: true, error: '' }))
    try {
      const report = await call(() => toolHealth(fresh === true), '体检失败。')
      if (mounted.current) setHealth({ report, error: '', refreshing: false })
    } catch (error) {
      if (mounted.current) setHealth(previous => ({ ...previous, refreshing: false, error: text(error?.message) || '体检失败。' }))
    }
  }
  const refreshLedger = async () => {
    const request = ++ledgerRequest.current
    if (mounted.current) setLedger(previous => ({ ...previous, error: '', refreshing: true }))
    try {
      const value = await call(loadLedger, '执行记录读取失败。')
      if (mounted.current && request === ledgerRequest.current) setLedger({ value, error: '', refreshing: false })
      if (!mounted.current || request !== ledgerRequest.current) return null
      return value
    } catch (error) {
      if (mounted.current && request === ledgerRequest.current) setLedger(previous => ({ ...previous, refreshing: false,
        error: `${text(error?.message) || '执行记录读取失败。'}${previous.value ? ' 下方保留最近一次摘要，尚未重新核验。' : ''}` }))
      return null
    }
  }
  const refreshBoundaries = async () => {
    try {
      const value = await call(loadBoundaries, '安全边界读取失败。')
      if (mounted.current) setBoundaries({ value, error: '' })
    } catch (error) {
      if (mounted.current) setBoundaries({ value: null, error: text(error?.message) || '安全边界读取失败。' })
    }
  }
  const finishOnboarding = async () => {
    try {
      const onboarding = await call(completeOnboarding, '无法保存体检状态。')
      if (mounted.current) setHealth(previous => ({ ...previous, report: { ...previous.report, onboarding } }))
    } catch (error) {
      if (mounted.current) setHealth(previous => ({ ...previous, error: text(error?.message) || '无法保存体检状态。' }))
    }
  }
  const rate = async (runId, packageId, rating, expectedFinishedAt) => {
    if (mutationBusy.current) return
    mutationBusy.current = true
    setBusy(true)
    try { await call(() => rateResult({ runId, packageId, rating, ...(expectedFinishedAt === undefined ? {} : { expectedFinishedAt }) }), '评价保存失败。'); await refreshLedger() }
    catch (error) { if (mounted.current) setLedger(previous => ({ ...previous, error: text(error?.message) || '评价保存失败。' })) }
    finally { mutationBusy.current = false; if (mounted.current) setBusy(false) }
  }
  const rerun = async (runId, packageId, override, choice = null) => {
    if (mutationBusy.current) return
    const run = ledger.value?.runs?.find(item => item.id === runId)
    const item = run?.packages?.find(entry => entry.id === packageId)
    const support = rerunSupport(run, ledger.value)
    if (!support.supported) {
      setLedger(previous => ({ ...previous, error: support.reason }))
      return
    }
    // One prompt lists every reason (file edits, unsandboxed CLI, budget); the Host re-checks all of them.
    const reasons = rerunConfirmations({ run, item, override, choice, ledger: ledger.value, health: health.report, toolFor: toolForProvider, headlessIds: HEADLESS_TOOLS })
    if (reasons.length && !window.confirm(reasons.length === 1
      ? `${reasons[0].text}\n继续吗？`
      : `重跑前需要确认以下 ${reasons.length} 项：\n${reasons.map((entry, index) => `${index + 1}. ${entry.text}`).join('\n')}\n全部确认并继续吗？`)) return
    const codes = new Set(reasons.map(entry => entry.code))
    if (mutationBusy.current) return
    mutationBusy.current = true
    setBusy(true)
    try {
      const request = { runId, packageId, ...(override ? { provider: override.provider, model: override.model } : {}), ...(choice ? { subscriptionChoice: choice } : {}),
        ...(codes.has('over-budget') ? { confirmOverBudget: true } : {}), ...(codes.has('workspace-write') ? { confirmWrite: true } : {}),
        ...(run?.executionEnvironment === 'cli-native' && codes.has('unsandboxed') ? { confirmUnsandboxed: true } : {}) }
      let result = await call(() => rerunStep(request), '重跑失败。')
      if (result?.paused && result.budget?.exceeded && !request.confirmOverBudget) {
        // The local estimate missed it (for example a reassigned route): ask once more for the budget only.
        if (!window.confirm(`${result.budget?.message ?? '本次重跑会超出预算。'}\n仍要继续吗？`)) return
        result = await call(() => rerunStep({ ...request, confirmOverBudget: true }), '重跑失败。')
      }
      await refreshLedger()
    } catch (error) {
      if (mounted.current) setLedger(previous => ({ ...previous, error: `${text(error?.message) || '重跑失败。'} 可以修正后再点“重跑此步”，或在官方会话中调用 model_router_rerun_step。` }))
    } finally {
      mutationBusy.current = false
      if (mounted.current) setBusy(false)
    }
  }
  React.useEffect(() => {
    void refreshHealth(false)
    void refreshLedger()
    void refreshBoundaries()
  }, [])
  return { health, ledger, boundaries, busy, refreshHealth, refreshLedger, refreshBoundaries, finishOnboarding, rate, rerun }
}

/**
 * Send one prompt to a terminal tool (dsh-TUI) and show what it rendered.
 * The Host types into a managed PTY, so the reply is terminal text, not a model answer with a
 * protocol shape; failures are reported as they are instead of being rephrased as model output.
 */
function TuiPromptBox({ tool, tuiPrompt }) {
  const [prompt, setPrompt] = React.useState('')
  const [reply, setReply] = React.useState(null)
  const [busy, setBusy] = React.useState(false)
  const send = async () => {
    if (busy || prompt.trim() === '') return
    setBusy(true)
    setReply(null)
    try {
      const result = await tuiPrompt({ tool: tool.id, prompt })
      if (result?.ok === false) setReply({ error: result.error ?? '运行失败' })
      else setReply({ text: result?.value?.text ?? '', durationMs: result?.value?.durationMs ?? null })
    } catch (error) {
      setReply({ error: String(error?.message ?? error) })
    } finally {
      setBusy(false)
    }
  }
  return <div className="mr-tui-prompt">
    <label className="mr-caption" htmlFor={`mr-tui-${tool.id}`}>向 {tool.label} 输入提示词（经受管终端执行，回复为终端文本）</label>
    <textarea
      id={`mr-tui-${tool.id}`}
      className="mr-tui-input"
      rows={3}
      value={prompt}
      disabled={busy}
      placeholder="例如：用一句话说明你当前使用的模型与会话"
      onChange={event => setPrompt(event.target.value)}
    />
    <div className="mr-tui-actions">
      <button className="mr-button mr-tool-button" type="button" disabled={busy || prompt.trim() === ''} onClick={() => { void send() }}>
        {busy ? '运行中…' : '发送'}
      </button>
      {reply?.durationMs != null && <span className="mr-caption">耗时 {Math.round(reply.durationMs / 1000)} 秒</span>}
    </div>
    {reply?.error && <p className="mr-error" role="alert">{reply.error}</p>}
    {reply?.text && <pre className="mr-tui-reply" aria-label={`${tool.label} 回复`}>{reply.text}</pre>}
  </div>
}

export function RouterMainPage({ loadCatalog, settingsScope, listOfficialTools, loadOfficialInstallSettings, installOfficialTool, uninstallOfficialTool, repairOfficialTool, cancelOfficialToolInstall, officialToolInstallStatus, toolHealth, completeOnboarding, loadLedger, rateResult, rerunStep, loadBoundaries, previewRun, startRun, runStatus, cancelRun, terminalApi, tuiPrompt }) {
  const workbench = useWorkbenchData({ toolHealth, completeOnboarding, loadLedger, rateResult, rerunStep, loadBoundaries })
  const [catalogState, setCatalogState] = React.useState({ status: 'loading', catalog: null, error: '' })
  const [task, setTask] = React.useState(() => workbenchDraft().task)
  const [mode, setMode] = React.useState(() => workbenchDraft().mode)
  const [directKey, setDirectKey] = React.useState(() => workbenchDraft().directKey)
  const [budget, setBudget] = React.useState(() => workbenchDraft().budget ?? String(settingsScope.getSnapshot().value?.budgetUsd ?? 0))
  const [templateUndo, setTemplateUndo] = React.useState(null)
  const [historyRunId, setHistoryRunId] = React.useState(null)
  const taskInput = React.useRef(null)
  const executionSection = React.useRef(null)
  const workspaceElement = React.useRef(null)
  const [query, setQuery] = React.useState('')
  const [plan, setPlan] = React.useState(null)
  const [assignmentMode, setAssignmentMode] = React.useState('algorithm')
  const [packageAssignments, setPackageAssignments] = React.useState({})
  const [planError, setPlanError] = React.useState('')
  const [toolProbes, setToolProbes] = React.useState(null)
  const [routingSettings, setRoutingSettings] = React.useState(() => {
    const value = settingsScope.getSnapshot().value ?? {}
    return routingSettingsSignature(value)
  })
  const [view, setView] = React.useState(savedWorkbenchView)
  const [attentionHidden, setAttentionHidden] = React.useState(() => {
    try { return globalThis.localStorage?.getItem(ATTENTION_VISIBILITY_KEY) === 'true' } catch { return false }
  })
  const restoreAttentionButton = React.useRef(null)
  const closeAttentionButton = React.useRef(null)
  const attentionVisibilityChanged = React.useRef(false)
  const tabRefs = React.useRef({})
  const resultHeading = React.useRef(null)
  const budgetEdited = React.useRef(workbenchDraft().budget !== undefined)
  const budgetValue = React.useRef(budget)
  const mounted = React.useRef(false)
  const catalogRequest = React.useRef(0)
  const generationRequest = React.useRef(0)
  const generationInputs = React.useRef('')
  generationInputs.current = JSON.stringify([task, budget, mode, directKey, routingSettings, catalogState.catalog, toolProbes, workbench.health.report?.tools])

  React.useEffect(() => {
    rememberWorkbenchDraft({ task, mode, directKey, budget: budgetEdited.current ? budget : undefined })
  }, [task, mode, directKey, budget])
  React.useEffect(() => { rememberWorkbenchView(view) }, [view])

  const changeAttentionVisibility = hidden => {
    try { globalThis.localStorage?.setItem(ATTENTION_VISIBILITY_KEY, String(hidden)) } catch { /* storage may be disabled */ }
    attentionVisibilityChanged.current = true
    setAttentionHidden(hidden)
  }
  React.useEffect(() => {
    if (!attentionVisibilityChanged.current) return
    attentionVisibilityChanged.current = false
    const button = attentionHidden ? restoreAttentionButton : closeAttentionButton
    button.current?.focus({ preventScroll: true })
  }, [attentionHidden])

  React.useEffect(() => {
    if (plan) {
      resultHeading.current?.scrollIntoView?.({ block: 'start', behavior: 'auto' })
      resultHeading.current?.focus({ preventScroll: true })
    }
  }, [plan])

  const selectView = id => {
    const next = validWorkbenchView(id)
    setView(next)
    if (workspaceElement.current) workspaceElement.current.scrollTop = 0
    tabRefs.current[next]?.focus({ preventScroll: true })
  }
  const goToExecution = () => {
    executionSection.current?.scrollIntoView?.({ block: 'start', behavior: 'auto' })
    executionSection.current?.focus({ preventScroll: true })
  }
  const openAttention = row => {
    if (row.target === 'history') setHistoryRunId(row.runId ?? null)
    selectView(row.target)
  }
  const navigateTabs = (event, index) => {
    const next = event.key === 'ArrowRight' ? (index + 1) % WORKSPACE_VIEWS.length
      : event.key === 'ArrowLeft' ? (index + WORKSPACE_VIEWS.length - 1) % WORKSPACE_VIEWS.length
        : event.key === 'Home' ? 0 : event.key === 'End' ? WORKSPACE_VIEWS.length - 1 : null
    if (next === null) return
    event.preventDefault()
    selectView(WORKSPACE_VIEWS[next].id)
  }

  React.useEffect(() => {
    const syncBudget = () => {
      const value = settingsScope.getSnapshot().value ?? {}
      const signature = routingSettingsSignature(value)
      setRoutingSettings(previous => {
        if (previous === signature) return previous
        return signature
      })
      if (budgetEdited.current) return
      const next = String(value.budgetUsd ?? 0)
      if (next !== budgetValue.current) {
        budgetValue.current = next
        setBudget(next)
        setPlan(null)
        setPlanError('')
      }
    }
    syncBudget()
    return settingsScope.subscribe(syncBudget)
  }, [settingsScope])

  React.useEffect(() => { setPlan(null); setPlanError('') }, [routingSettings])
  const dataRevision = workbench.ledger.value?.dynamicData?.revision ?? ''
  const feedbackRevision = workbench.ledger.value?.learning?.revision ?? ''
  const evidenceRevision = workbench.ledger.value?.routingEvidence?.revision ?? ''
  const manualAllowed = workbench.ledger.value?.settings?.allowManualReassign !== false
    && settingsScope.getSnapshot().value?.allowManualReassign !== false
  React.useEffect(() => {
    setAssignmentMode('algorithm')
    setPackageAssignments({})
  }, [plan, task, mode, routingSettings, catalogState.catalog, toolProbes, workbench.health.report?.tools, manualAllowed])
  React.useEffect(() => {
    if (plan && plan.workbenchRevision !== `${dataRevision}/${feedbackRevision}/${evidenceRevision}`) { setPlan(null); setPlanError('') }
  }, [dataRevision, feedbackRevision, evidenceRevision, plan])

  React.useEffect(() => {
    mounted.current = true
    const request = ++catalogRequest.current
    Promise.resolve().then(loadCatalog).then(response => {
      if (!mounted.current || request !== catalogRequest.current) return
      if (response?.ok) setCatalogState({ status: 'ready', catalog: response.value, error: '' })
      else setCatalogState({ status: 'error', catalog: null, error: text(response?.error?.message) || '模型目录读取失败' })
    }).catch(error => {
      if (mounted.current && request === catalogRequest.current) setCatalogState({ status: 'error', catalog: null, error: text(error?.message) || '模型目录读取失败' })
    })
    return () => { mounted.current = false; catalogRequest.current += 1 }
  }, [])

  const routes = routesFromModelCatalog(catalogState.catalog)
  const assignmentOptions = manualAssignmentOptions(routes, toolProbes, workbench.health.report)
  // \u201c\u6709\u4ec0\u4e48\u9700\u8981\u6211\u5904\u7406\u201d\u5148\u4e8e\u5176\u4ed6\u4e00\u5207\uff1a\u53ea\u5217\u771f\u6b63\u7b49\u4eba\u7684\u4e8b\uff0c\u5065\u5eb7\u65f6\u4e0d\u5360\u4f4d\u7f6e\u3002
  const attention = React.useMemo(() => deriveAttention({
    budget: workbench.ledger.value?.budget ?? null,
    reserved: workbench.ledger.value?.reserved ?? null,
    probes: toolProbes?.probes ?? [],
    health: (workbench.health.report?.tools ?? []).map(item => ({ ...item, label: OFFICIAL_TOOLS.find(tool => tool.id === item.id)?.label ?? item.id })),
    runs: workbench.ledger.value?.runs ?? [],
  }), [workbench.ledger.value, workbench.health.report, toolProbes])
  const currentPackagePlanKey = packagePlanKey(plan, task)
  const effectiveAssignmentMode = assignmentMode === 'manual' && currentPackagePlanKey && manualAllowed && mode !== 'direct' ? 'manual' : 'algorithm'
  const changeAssignmentMode = next => {
    if (next === 'manual') {
      if (!manualAllowed || !currentPackagePlanKey) return
      setPackageAssignments(initialPackageAssignments(plan))
      setAssignmentMode('manual')
    } else {
      setAssignmentMode('algorithm')
      setPackageAssignments({})
    }
  }
  const changePackageAssignment = (id, binding) => {
    if (!manualAllowed || effectiveAssignmentMode !== 'manual' || !plan.team.workPackages.some(item => item.id === id)) return
    setPackageAssignments(previous => ({ ...previous, [id]: binding }))
  }
  const providerCount = new Set(routes.map(route => route.provider)).size
  const refresh = async () => {
    const request = ++catalogRequest.current
    setCatalogState({ status: 'loading', catalog: null, error: '' })
    setPlan(null)
    try {
      const response = await loadCatalog()
      if (!mounted.current || request !== catalogRequest.current) return
      if (response?.ok) setCatalogState({ status: 'ready', catalog: response.value, error: '' })
      else setCatalogState({ status: 'error', catalog: null, error: text(response?.error?.message) || '模型目录读取失败' })
    } catch (error) {
      if (mounted.current && request === catalogRequest.current) setCatalogState({ status: 'error', catalog: null, error: text(error?.message) || '模型目录读取失败' })
    }
  }
  const invalidatePlan = () => {
    generationRequest.current += 1
    setPlan(null)
    setPlanError('')
  }
  const handleToolProbes = React.useCallback(snapshot => {
    generationRequest.current += 1
    setToolProbes(snapshot)
    setPlan(null)
    setPlanError('')
  }, [])
  const generate = async () => {
    const request = ++generationRequest.current
    const inputs = generationInputs.current
    setPlanError('')
    try {
      if (!text(task)) throw new Error('请先描述任务。')
      if (routes.length === 0) throw new Error('请先在官方“模型”页配置至少一条模型路线。')
      const parsedBudget = Number(budget)
      if (!Number.isFinite(parsedBudget) || parsedBudget < 0) throw new Error('预算必须是不小于 0 的数字。')
      const direct = mode === 'direct' ? routes.find(route => `${route.provider}/${route.model}` === directKey) ?? routes[0] : null
      if (mode === 'direct' && !direct) throw new Error('请选择要直接使用的模型。')
      // Read the Host's exact public snapshot and full-window feedback profile
      // before local planning. No task text goes to a public data endpoint.
      const signature = routingSettingsSignature(settingsScope.getSnapshot().value ?? {})
      const ledger = await workbench.refreshLedger()
      if (request !== generationRequest.current || inputs !== generationInputs.current || !mounted.current) return
      if (!ledger) throw new Error('请先恢复执行记录连接；无法核对最新数据与学习状态。')
      if (ledger.storageAvailable === false) throw new Error('执行记录存储暂不可用，无法核对费用与学习状态；请恢复连接后再规划。')
      if (ledger.budget?.historyVerified === false) throw new Error('费用历史不完整，请从备份恢复并核验后再规划。')
      if (signature !== routingSettingsSignature(settingsScope.getSnapshot().value ?? {})) throw new Error('规划设置已更新，请重新生成建议。')
      const next = createWorkspacePlan(task, catalogState.catalog, {
        ...ledger.routingData,
        learning: ledger.learning,
        routingEvidence: ledger.routingEvidence,
        mode,
        ...(direct ? { directProvider: direct.provider, directModel: direct.model } : {}),
        budgetUsd: parsedBudget,
        modelProfilesJson: settingsScope.getSnapshot().value?.modelProfilesJson ?? '[]',
        installedToolIds: (toolProbes?.probes ?? []).filter(probe => probe.installed).map(probe => probe.id),
        runnableToolIds: (toolProbes?.readiness ?? []).filter(item => item.ready).map(item => item.id),
        preset: settingsScope.getSnapshot().value?.routingPreset ?? 'balanced',
        loggedOutToolIds: (workbench.health.report?.tools ?? []).filter(item => item.installed && item.login?.state === 'logged-out').map(item => item.id),
      })
      setPlan({ ...next, workbenchRevision: `${ledger.dynamicData?.revision ?? ''}/${ledger.learning?.revision ?? ''}/${ledger.routingEvidence?.revision ?? ''}` })
    } catch (error) {
      if (request !== generationRequest.current || inputs !== generationInputs.current || !mounted.current) return
      setPlan(null)
      setPlanError(text(error?.message) || '无法生成路由建议。')
    }
  }

  const summary = healthSummary(workbench.health.report?.tools)
  return (
    <main className="mr-workspace" ref={workspaceElement}>
      <style>{stylesheet}</style>
      <div className="mr-shell">
        <header className="mr-header">
          <div>
            <p className="mr-eyebrow">Model Router · DeepSeek Harness</p>
            <h1 className="mr-title">模型路由工作台</h1>
            <p className="mr-subtitle">把任务交给合适的模型。从本地规划，到可确认的执行。</p>
          </div>
          <div className="mr-header-actions">
            <div className="mr-status"><span className={`mr-status-dot ${catalogState.status === 'loading' ? 'loading' : catalogState.status === 'error' ? 'error' : ''}`} />{catalogState.status === 'ready' ? `${providerCount} 个供应商 · ${routes.length} 条路线` : catalogState.status === 'loading' ? '正在读取模型目录' : '模型目录读取失败'}</div>
            {attentionHidden && <button ref={restoreAttentionButton} className="mr-button mr-button-secondary" type="button" onClick={() => changeAttentionVisibility(false)}>显示待处理提醒{attention.length > 0 ? `（${attention.length}）` : ''}</button>}
          </div>
        </header>

        <div className="mr-overview" aria-label="工作台概览">
          <button type="button" className="mr-overview-item" onClick={() => selectView('models')}><span className="mr-overview-label">模型路线</span><strong>{catalogState.status === 'ready' ? routes.length : '—'}</strong><span className="mr-overview-detail">{catalogState.status === 'ready' ? `${providerCount} 个供应商 · 配置价格与能力 →` : '等待目录加载'}</span></button>
          <button type="button" className="mr-overview-item" onClick={() => selectView('tools')}><span className="mr-overview-label">官方工具</span><strong>{workbench.health.report ? summary.installed : '—'}<small> / {OFFICIAL_TOOLS.length}</small></strong><span className="mr-overview-detail">{workbench.health.report ? `${summary.ready} 个已登录 · 查看体检 →` : '查看安装与登录状态 →'}</span></button>
          <button type="button" className="mr-overview-item" onClick={() => selectView('controls')}><span className="mr-overview-label">今日已发生 API 费用</span><strong>{workbench.ledger.value ? money(workbench.ledger.value.spent?.today ?? 0) : '—'}</strong><span className="mr-overview-detail">预占 {money(reservationSummary(workbench.ledger.value).today)} · 查看预算 →</span></button>
        </div>

        <div className="mr-workspace-tabs" role="tablist" aria-label="工作台功能">
          {WORKSPACE_VIEWS.map((item, index) => <button key={item.id} ref={element => { tabRefs.current[item.id] = element }} type="button" role="tab" id={`mr-tab-${item.id}`} aria-selected={view === item.id} aria-controls={`mr-panel-${item.id}`} tabIndex={view === item.id ? 0 : -1} onKeyDown={event => navigateTabs(event, index)} onClick={() => selectView(item.id)}><span className="mr-tab-number" aria-hidden="true">{item.number}</span>{item.label}</button>)}
        </div>

        {staleHostNotice({ hostVersion: toolProbes?.hostVersion, loaded: Boolean(toolProbes?.probes?.length) }) && <div className="mr-error" role="alert">{staleHostNotice({ hostVersion: toolProbes?.hostVersion })}</div>}
        {(workbench.health.report?.notices ?? []).map(notice => (
          <div key={`${notice.kind}-${notice.at}`} className="mr-error" role="alert">{notice.message}</div>
        ))}
        {!attentionHidden && attention.length > 0 && <section className="mr-card mr-attention" aria-label="需要你处理">
          <div className="mr-card-head"><div><h2 className="mr-card-title">需要你处理</h2><p className="mr-card-copy">{attentionSummary(attention)}</p></div>
            <button ref={closeAttentionButton} className="mr-attention-close" type="button" aria-label="关闭待处理提醒" title="关闭待处理提醒，可在工作台顶部重新显示" onClick={() => changeAttentionVisibility(true)}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>
            </button>
          </div>
          <ul className="mr-attention-list">
            {attention.map(row => <li key={row.key} className={`mr-attention-row mr-attention-${row.stage}`}>
              <div><strong>{row.title}</strong><p className="mr-caption">{row.detail}</p></div>
              <button className="mr-button mr-button-secondary" type="button" onClick={() => openAttention(row)}>{row.target === 'tools' ? '查看官方工具' : row.target === 'history' ? '查看执行记录' : '查看预算与用量'}</button>
            </li>)}
          </ul>
        </section>}
        <div className="mr-view mr-stack" role="tabpanel" id="mr-panel-plan" aria-labelledby="mr-tab-plan" hidden={view !== 'plan'}>
        <div className="mr-grid mr-planning-grid">
          <section className="mr-card" aria-label="任务规划">
            <div className="mr-card-head"><div><h2 className="mr-card-title">任务规划</h2><p className="mr-card-copy">写清目标与验收标准，先生成本地建议，再预览执行。</p></div><span className="mr-pill">本地规划 · 不消耗 token</span></div>
            <div className="mr-card-body">
              <label className="mr-label" htmlFor="mr-task">任务描述</label>
              <div className="mr-template-bar" aria-label="任务模板"><span className="mr-caption">快速开始</span>{TASK_TEMPLATES.map(template => <button key={template.id} type="button" className="mr-template-button" onClick={() => { setTemplateUndo({ task, mode, directKey }); setTask(template.task); setMode(template.mode); invalidatePlan(); taskInput.current?.focus({ preventScroll: true }) }}>{template.label}</button>)}{templateUndo && <button type="button" className="mr-template-button" onClick={() => { setTask(templateUndo.task); setMode(templateUndo.mode); setDirectKey(templateUndo.directKey); setTemplateUndo(null); invalidatePlan(); taskInput.current?.focus({ preventScroll: true }) }}>撤销模板</button>}</div>
              <textarea ref={taskInput} className="mr-textarea" id="mr-task" value={task} onChange={event => { setTask(event.target.value); invalidatePlan() }} placeholder="你想完成什么？希望得到什么结果？可以先选一个模板再修改。" aria-describedby="mr-task-hint" />
              <p className="mr-caption mr-task-hint" id="mr-task-hint">切换页面会保留当前窗口的任务草稿。模板只填写描述；是否调用模型、使用哪些工具，以执行预览和你的确认为准。</p>
              <details className="mr-form-options"><summary>路由与预算设置 · {{ single: '单任务', team: '团队分工', direct: '指定模型' }[mode]} · {Number.isFinite(Number(budget)) && Number(budget) >= 0 ? Number(budget) > 0 ? `本次估算上限 ${budget} USD` : '未设本次估算上限' : '预算待修正'}</summary>
              <div className="mr-controls">
                <div className="mr-control-group"><span className="mr-control-label">规划模式</span><div className="mr-segment" role="group" aria-label="规划模式"><button type="button" aria-pressed={mode === 'single'} onClick={() => { setMode('single'); invalidatePlan() }}>单任务</button><button type="button" aria-pressed={mode === 'team'} onClick={() => { setMode('team'); invalidatePlan() }}>团队分工</button><button type="button" aria-pressed={mode === 'direct'} onClick={() => { setMode('direct'); invalidatePlan() }}>指定模型</button></div></div>
                {mode === 'direct' && <div className="mr-control-group mr-direct"><label className="mr-control-label" htmlFor="mr-direct-model">直接使用</label><select className="mr-input" id="mr-direct-model" value={directKey || (routes[0] ? `${routes[0].provider}/${routes[0].model}` : '')} onChange={event => { setDirectKey(event.target.value); invalidatePlan() }}>{routes.map(route => <option key={`${route.provider}/${route.model}`} value={`${route.provider}/${route.model}`}>{route.provider}/{route.model}</option>)}</select></div>}
                <div className="mr-control-group mr-budget"><label className="mr-control-label" htmlFor="mr-budget">本次估算预算（USD）</label><input className="mr-input" id="mr-budget" type="number" min="0" step="0.01" value={budget} onChange={event => { budgetEdited.current = true; budgetValue.current = event.target.value; setBudget(event.target.value); invalidatePlan() }} /></div>
              </div>
              </details>
              <div className="mr-actions"><button className="mr-button" type="button" disabled={!text(task) || catalogState.status !== 'ready' || routes.length === 0} onClick={goToExecution}>下一步：预览执行</button><button className="mr-button mr-button-secondary" type="button" disabled={!text(task) || catalogState.status !== 'ready' || routes.length === 0 || toolProbes === null} onClick={generate}>比较路由（可选）</button></div>
              <p className="mr-caption">{catalogState.status === 'loading' ? '正在读取模型目录…' : catalogState.status === 'error' ? '目录读取失败，请在“模型配置”中刷新。' : routes.length === 0 ? '请先在 Harness 的“模型”页添加模型。' : '预览不会调用模型。需要比较路线或逐包手动分配时，可先比较路由。'}</p>
              {planError && <p className="mr-error" role="alert">{planError}</p>}
            </div>
          </section>

          <aside className="mr-planning-guide" aria-label="规划使用提示">
            <p className="mr-eyebrow">{text(task) ? '下一步：核对执行预览' : '从一个清楚的目标开始'}</p>
            <ol className="mr-workflow"><li><span>01</span><div><strong>填写目标</strong><p>可用模板起步；更多选项按需展开。</p></div></li><li><span>02</span><div><strong>预览执行方案</strong><p>检查模型、工具、工作区和预估费用。</p></div></li><li><span>03</span><div><strong>确认后开始</strong><p>结果在“执行记录”查看，失败步骤按记录处理。</p></div></li></ol>
            <div className="mr-guide-links"><button className="mr-button mr-button-secondary" type="button" onClick={() => selectView('models')}>配置模型价格与能力 →</button><button className="mr-button mr-button-secondary" type="button" onClick={() => selectView('tools')}>检查官方工具与登录 →</button></div>
            <p className="mr-caption">缺少价格时会提示“价格待配置”。只读检查可直接预览；修改文件时，先选“团队分工”，再在执行区选择“官方工具协作”和“编辑文件”权限，核对预览后确认执行。</p>
          </aside>
        </div>

        {plan && <PlanResults plan={plan} ledger={workbench.ledger.value} headingRef={resultHeading}
          assignmentMode={effectiveAssignmentMode} packageAssignments={packageAssignments} assignmentOptions={assignmentOptions} manualAllowed={manualAllowed}
          onAssignmentModeChange={changeAssignmentMode} onPackageAssignmentChange={changePackageAssignment}
          onRestoreAssignments={() => { if (manualAllowed && currentPackagePlanKey) setPackageAssignments(initialPackageAssignments(plan)) }} />}
        <div ref={executionSection} tabIndex={-1} className="mr-execution-section" aria-label="执行预览区域"><RunLauncher task={task} mode={mode} budgetUsd={budget} ledger={workbench.ledger.value} previewRun={previewRun} startRun={startRun} runStatus={runStatus} cancelRun={cancelRun}
          planningRevision={`${routingSettings}/${dataRevision}/${feedbackRevision}/${evidenceRevision}`}
          assignmentMode={effectiveAssignmentMode} packageAssignments={effectiveAssignmentMode === 'manual' ? packageAssignments : {}} packagePlanKey={currentPackagePlanKey}
          directRoute={mode === 'direct' ? routes.find(route => `${route.provider}/${route.model}` === directKey) ?? routes[0] ?? null : null}
          defaultPreset={settingsScope.getSnapshot().value?.routingPreset ?? 'balanced'}
          disabledReason={catalogState.status === 'loading' ? '正在读取模型目录…' : catalogState.status === 'error' ? '模型目录读取失败，请在“模型配置”中刷新。' : routes.length === 0 ? '请先在官方“模型”页配置至少一条模型路线。' : ''}
          onStarted={() => { void workbench.refreshLedger() }} /><div className="mr-actions"><button className="mr-button mr-button-secondary" type="button" onClick={() => selectView('history')}>打开执行记录</button><span className="mr-caption">查看任务结果、费用和受支持的重试。</span></div></div>
        </div>
        <div className="mr-view mr-stack" role="tabpanel" id="mr-panel-history" aria-labelledby="mr-tab-history" hidden={view !== 'history'}>
        <RunHistoryCard ledger={workbench.ledger.value} routes={routes} busy={workbench.busy} error={workbench.ledger.error}
          selectedRunId={historyRunId} onNewTask={() => selectView('plan')}
          onRefresh={() => { void workbench.refreshLedger() }} onRate={(runId, packageId, rating, expectedFinishedAt) => { void workbench.rate(runId, packageId, rating, expectedFinishedAt) }}
          onRerun={(runId, packageId, override, choice) => { void workbench.rerun(runId, packageId, override, choice) }} />
        </div>

        <div className="mr-view" role="tabpanel" id="mr-panel-models" aria-labelledby="mr-tab-models" hidden={view !== 'models'}>
          <div className="mr-view-heading"><h2>模型配置</h2><p>从官方目录选择路线，补齐比较所需的价格、能力与执行方式。</p></div>
          <div className="mr-grid mr-model-grid">
          <ModelProfileEditor routes={routes} settingsScope={settingsScope} onSaved={invalidatePlan} />

          <section className="mr-card" aria-label="模型目录">
            <div className="mr-card-head"><div><h2 className="mr-card-title">模型目录</h2><p className="mr-card-copy">{routes.length} 条路线 · 只读取官方目录，不读取 API Key。</p></div><button className="mr-button mr-button-secondary" type="button" disabled={catalogState.status === 'loading'} onClick={refresh}>刷新</button></div>
            <div className="mr-card-body">
              {catalogState.status === 'error' && <div className="mr-error" role="alert">{catalogState.error}</div>}
              {catalogState.status === 'loading' && <div className="mr-empty">正在加载官方模型目录…</div>}
              {catalogState.status === 'ready' && <><label className="mr-label" htmlFor="mr-model-search">搜索路线</label><input className="mr-input mr-search" id="mr-model-search" value={query} onChange={event => setQuery(event.target.value)} placeholder="模型或供应商" /><RouteList routes={routes} query={query} />{catalogState.catalog?.failures?.length > 0 && <p className="mr-caption">{catalogState.catalog.failures.length} 个供应商的目录读取失败，请在官方模型页检查配置。</p>}</>}
              <p className="mr-caption" style={{ marginTop: 13 }}>目录登记不代表凭据或网络当前可用；图像能力需要在实际使用前核对。</p>
            </div>
          </section>
        </div>
        </div>

        <div className="mr-view mr-stack" role="tabpanel" id="mr-panel-tools" aria-labelledby="mr-tab-tools" hidden={view !== 'tools'}>
        <div className="mr-view-heading"><h2>官方工具</h2><p>管理本机 CLI、检查登录状态，或打开交互式终端。</p></div>
        {terminalApi && <CliTerminalCard api={terminalApi} health={workbench.health.report}
          settingsSignature={toolInstallSettingsSignature(settingsScope?.getSnapshot?.()?.value)} />}
        {workbench.health.report && !workbench.health.report.onboarding?.completedAt && (
          <OnboardingBanner health={workbench.health.report} error={workbench.health.error} refreshing={workbench.health.refreshing}
            onRefresh={() => { void workbench.refreshHealth(true) }} onDone={() => { void workbench.finishOnboarding() }} />
        )}
        <OfficialToolsCard tuiPrompt={tuiPrompt} listOfficialTools={listOfficialTools} loadOfficialInstallSettings={loadOfficialInstallSettings} installOfficialTool={installOfficialTool} uninstallOfficialTool={uninstallOfficialTool} repairOfficialTool={repairOfficialTool} cancelOfficialToolInstall={cancelOfficialToolInstall} officialToolInstallStatus={officialToolInstallStatus} onProbes={handleToolProbes} settingsScope={settingsScope}
          health={workbench.health.report} onRefreshHealth={() => { void workbench.refreshHealth(true) }} />
        </div>

        <div className="mr-view mr-stack" role="tabpanel" id="mr-panel-controls" aria-labelledby="mr-tab-controls" hidden={view !== 'controls'}>
        <div className="mr-view-heading"><h2>预算与安全</h2><p>API 按金额管理预算，订阅单独核对用量与执行边界。</p></div>
        <TwoLedgerBooks books={workbench.ledger.value?.books} />
        <CostControlCard ledger={workbench.ledger.value} error={workbench.ledger.error || workbench.ledger.value?.storageNotice || ''} refreshing={workbench.ledger.refreshing} settingsScope={settingsScope}
          onChanged={() => { invalidatePlan(); return workbench.refreshLedger() }} />
        <SubscriptionUsageCard ledger={workbench.ledger.value} />
        <BillingCard billing={workbench.health.report?.billing ?? null} error={workbench.health.report ? '' : workbench.health.error}
          refreshing={workbench.health.refreshing} onRefresh={() => { void workbench.refreshHealth(true) }} />
        <SecurityCard data={workbench.boundaries.value} error={workbench.boundaries.error} onRefresh={() => { void workbench.refreshBoundaries() }} />
        </div>
        <footer className="mr-footer">主会话模型由 Harness 管理。更多设置：插件 → 已安装 → <code>{ROUTER_PACKAGE_NAME}</code>。</footer>
      </div>
    </main>
  )
}
