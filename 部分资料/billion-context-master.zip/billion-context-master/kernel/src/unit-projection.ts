import {
  activeBlocks,
  blockById,
  coveredMessageIds,
  isLiveCheckpointCarrier,
} from "./state.js";
import {
  buildIndexByMessageId,
  resolveBoundaries,
  blockVisibleInRange,
} from "./boundaries.js";
import { isSummaryMessageId } from "./prune.js";
import {
  collectFailedCompressCallIds,
  collectLatestProtected,
  hasUnrecoverableMediaPayload,
  isMessageLatestProtected,
  isMessageProtected,
  collectAgedCompressCallIds,
  lastUserAnchor,
} from "./protected.js";
import type { LatestProtected } from "./protected.js";
import {
  buildIntegrityPre,
  computeIntegrityWithdrawals,
} from "./turn-integrity.js";
import type { IntegrityPre } from "./turn-integrity.js";
import { adjustBoundariesForReasoningPairs } from "./reasoning-pairs.js";
import {
  adjustBoundariesForToolPairs,
  buildToolPairExtremes,
} from "./tool-pairs.js";
import type {
  CompressionState,
  CompressionTier,
  Config,
  CoreMessage,
} from "./types.js";

/**
 * #3236: the ONE definition of "can this range fold" — the exact sequence
 * applySingleRange runs before it creates a block: boundary resolution →
 * checkpoint-carrier exclusion (#335/#2663) → pair-boundary widening
 * (tool/reasoning pairs) → nested-block rescan → protected-tool/media/zone
 * carves → turn-integrity withdrawal (#684) → empty check.
 *
 * Before this module existed the recommendation side re-implemented parts of
 * that judgment with a DIFFERENT input scope: global integrity screening over
 * ALL compressible messages at once (so a turn whose partners sit in another
 * advertised unit passed screening), while apply judges each SUBMITTED range
 * alone and throws when its carves split a turn or empty the fold. Production
 * result: acp_status / nudge advertised ranges that every submission rejected
 * with "Range would split N turn(s)" — a permanent advertise/reject loop.
 *
 * Now both sides run this one function on the same array class (the exact
 * array applyCompression executes on — see ProcessTurnInput.applyView). Apply
 * consumes the full projection and throws the carried Error verbatim; the
 * recommendation side uses it as a screen and demotes doomed units to gaps;
 * the acp_status uncompressed view flags rows whose projection is fatal.
 * Swapping any single carve criterion (dead ref, live carrier, media,
 * protected tools, zone, turn integrity) therefore changes advertise and
 * execute together — the #2663 acceptance criterion.
 */
export interface UnitProjectionInput {
  /** The EXACT message array class applyCompression will run on for this
   * lane (the unpruned log when the render view differs from it). */
  messages: CoreMessage[];
  state: CompressionState;
  config: Config;
  startRef: string;
  endRef: string;
  /** Raw ids already covered by active blocks BEFORE this unit folds
   * (apply computes one such set per call; recommend passes the current one). */
  preExistingCoverage: Set<string>;
  /** REF ids (mNNNNN) of the soft-protection zone, computed on `messages` —
   * apply derives them from its own input array via computeProtectedRefs. */
  protectedMessageIds?: Set<string>;
  /** Warnings are pushed here in apply's original emission order so the
   * apply-side refactor stays byte-identical. Omit for read-only screens. */
  warnings?: string[];
  /** #5337 option A: per-pass O(n) derivations shared by every unit screened
   *  against the SAME (messages, state, config) triple — build once with
   *  {@link buildProjectionShared}. Omitted callers (the single-shot
   *  apply/report paths) compute inline exactly as before. */
  shared?: ProjectionShared;
  /** #5789 recovery ladder (internal): nested block ids kept ACTIVE even
   *  though they sit inside the span — the merge proceeds without consuming
   *  them. Set only by projectUnit's own shrink retry; external callers must
   *  never pass it. */
  excludeNestedBlockIds?: ReadonlySet<string>;
}

export interface UnitProjectionFatal {
  kind: "zone" | "split";
  error: Error;
}

export interface UnitProjection {
  /** Non-null when applySingleRange would THROW for this unit (and which
   * error, fully constructed). Null = the unit folds, possibly with warnings. */
  fatal: UnitProjectionFatal | null;
  rangeMessageIds: string[];
  skippedCarrierIds: string[];
  nestedBlockIds: string[];
  consumedBlockIds: string[];
  effectiveMessageIds: Set<string>;
  directMessageIds: string[];
  filteredIds: string[];
  withdrawnIds: Set<string>;
  splitTurnCount: number;
  splitPairCount: number;
  targetTier: CompressionTier;
  outputTier: CompressionTier;
  isBlockBoundary: boolean;
}

/** Read-only projection of one candidate range through the full apply
 * sequence. Never mutates `state`; never creates blocks. Throws
 * BoundaryNotFoundError when an endpoint ref cannot be resolved. */
export function projectUnit(input: UnitProjectionInput): UnitProjection {
  const warnings = input.warnings ?? [];
  // Declared up front: every exit path (including the zone fatal below)
  // assembles the result through finish(), which reads these bindings.
  let withdrawnIds = new Set<string>();
  let splitTurnCount = 0;
  let splitPairCount = 0;

  // #5337 option A: optional per-pass derivations (see buildProjectionShared).
  // Every use site below falls back to the legacy inline computation when the
  // caller provides no shared context, so standalone projections (apply,
  // report) stay byte-identical to the pre-sharing implementation.
  const shared = input.shared;
  const byId = shared?.byId;
  const msgById = (id: string): CoreMessage | undefined =>
    byId === undefined
      ? input.messages.find((m) => m.id === id)
      : input.messages[byId.get(id) ?? -1];

  const resolved = resolveBoundaries({
    startRef: input.startRef,
    endRef: input.endRef,
    messages: input.messages,
    state: input.state,
    indexByMessageId: byId,
  });

  // Host checkpoint carriers (#335): a host that renders its own compression
  // summaries marks each carrier with `summaryOfBlockId`. A plain message-ref
  // range does not go through the block-distillation path, so folding a live
  // carrier would silently drop the previous distillation from the visible
  // context while the result reports nothing superseded. Keep carriers of
  // still-active blocks visible; stale carriers (block already consumed, or
  // unknown id) fold like ordinary messages. Block-ref boundaries deliberately
  // distill across checkpoints and keep folding carriers.
  const plainRange = resolved.boundaryKind !== "block";
  const liveCarrierIds = new Set<string>(
    plainRange ? shared?.liveCarrierIds : undefined,
  );
  if (plainRange && !shared) {
    // #2663: the selector screens with this same predicate — one definition,
    // two call sites, so advertise/validate cannot drift apart again.
    for (const message of input.messages) {
      if (isLiveCheckpointCarrier(message, input.state)) {
        liveCarrierIds.add(message.id);
      }
    }
  }
  const adjustedIds = applyPairBoundaryAdjustments(
    resolved,
    input.messages,
    shared,
  );
  const skippedCarrierIds = adjustedIds.filter((id) => liveCarrierIds.has(id));
  if (skippedCarrierIds.length > 0) {
    warnings.push(
      `Excluded ${skippedCarrierIds.length} checkpoint message(s) ${skippedCarrierIds.join(
        ", ",
      )} from the compression range — they carry the visible summary of still-active block(s), which a plain message-ref range does not supersede. The checkpoints stay visible; to fold them, reference the block ids (bN..bM) instead.`,
    );
  }
  const rangeMessageIds = adjustedIds.filter(
    (id) => !isSummaryMessageId(id) && !liveCarrierIds.has(id),
  );

  // Re-scan for nested blocks in the ADJUSTED range (tool-pair extension may
  // have pulled in messages that are anchors of existing blocks).
  if (rangeMessageIds.length > resolved.messageIds.length) {
    const indexByMessageId =
      shared?.byId ?? buildIndexByMessageId(input.messages);
    const adjustedStart =
      rangeMessageIds.length > 0
        ? (indexByMessageId.get(rangeMessageIds[0]!) ?? resolved.startIndex)
        : resolved.startIndex;
    const adjustedEnd =
      rangeMessageIds.length > 0
        ? (indexByMessageId.get(rangeMessageIds[rangeMessageIds.length - 1]!) ??
          resolved.endIndex)
        : resolved.endIndex;
    const nestedSeen = new Set(resolved.nestedBlockIds);
    for (const block of activeBlocks(input.state)) {
      if (nestedSeen.has(block.blockId)) continue;
      if (
        blockVisibleInRange(block, indexByMessageId, adjustedStart, adjustedEnd)
      ) {
        nestedSeen.add(block.blockId);
        resolved.nestedBlockIds.push(block.blockId);
      }
    }
  }

  const isBlockBoundary = resolved.boundaryKind === "block";
  const targetTier = resolveTargetTier(
    input.state,
    resolved.nestedBlockIds,
    isBlockBoundary,
  );
  const outputTier = isBlockBoundary
    ? (Math.min(3, targetTier + 1) as CompressionTier)
    : 1;

  // #5789: blocks excluded by the recovery ladder stay ACTIVE and are simply
  // not consumed here — their ids drop out of effectiveMessageIds below
  // automatically (the union iterates consumedBlockIds), and because they
  // remain active they are part of preExistingCoverage, so none of their ids
  // re-enter as direct content either.
  const excludedNestedBlockIds = input.excludeNestedBlockIds
    ? resolved.nestedBlockIds.filter((id) =>
        input.excludeNestedBlockIds!.has(id),
      )
    : [];
  let consumedBlockIds = resolved.nestedBlockIds.filter((id) => {
    if (input.excludeNestedBlockIds?.has(id)) return false;
    const block = blockById(input.state, id);
    return block?.active && block.tier === targetTier;
  });

  const effectiveMessageIds = new Set<string>(rangeMessageIds);
  for (const consumedId of consumedBlockIds) {
    const consumed = blockById(input.state, consumedId);
    if (consumed) {
      for (const id of consumed.effectiveMessageIds)
        effectiveMessageIds.add(id);
    }
  }

  const directMessageIds = [...effectiveMessageIds].filter(
    (id) => !input.preExistingCoverage.has(id),
  );

  let filteredIds = filterProtectedToolMessages(
    directMessageIds,
    input.messages,
    input.config,
    shared,
  );

  // filterProtectedToolMessages drops protected tool calls (and their paired
  // results) from the compressible set. They must also leave effectiveMessageIds,
  // otherwise the block would record them as covered and hide them from view.
  // (Bug 39: protected tool messages folded into a block.)
  if (filteredIds.length < directMessageIds.length) {
    const kept = new Set(filteredIds);
    for (const id of directMessageIds) {
      if (!kept.has(id)) effectiveMessageIds.delete(id);
    }
  }

  const mediaExcluded = directMessageIds.filter((id) => {
    const msg = msgById(id);
    return !!msg && hasUnrecoverableMediaPayload(msg);
  });
  if (mediaExcluded.length > 0) {
    warnings.push(
      `Excluded ${mediaExcluded.length} message(s) carrying unrecoverable media (no stored bytes and no re-access handle in the message) from compression range — folding would destroy them permanently (billion-context#1188/#2609). Ref-based media (remote URL / file id) folds normally since #5620 with its handle recorded in the summary; inline images fold normally too and stay restorable via decompress({ imageRef }).`,
    );
  }

  // SOFT PROTECTION: the recent-N / last-user-message zone is advisory-only at
  // compress time. Instead of failing the whole range when it brushes protected
  // messages, exclude those messages and proceed with the rest (so the model
  // isn't blocked when it picks a range that slightly overlaps the recent
  // window). If excluding them empties the range entirely AND there are no
  // consumed blocks to merge, we still fail — there is genuinely nothing to
  // compress. `protectedMessageIds` holds REF ids (mNNNNN) from
  // computeProtectedRefs; filteredIds holds RAW message ids, so convert via
  // state.messageRefs.byRaw before testing membership.
  const protectedRefs = input.protectedMessageIds;
  const hitProtectedRaw = protectedRefs
    ? filteredIds.filter((id) => {
        const ref = input.state.messageRefs.byRaw[id];
        return ref !== undefined && protectedRefs.has(ref);
      })
    : [];
  if (hitProtectedRaw.length > 0) {
    const protectedSet = new Set(hitProtectedRaw);
    // #3953: a protected message INTERIOR to the range means the fold would
    // also cover messages that come AFTER it — typically the assistant
    // replies to the protected user message — while the summary anchor lands
    // at the earliest covered position, i.e. BEFORE the question it answers.
    // Truncate the fold at the first protected message instead of carving a
    // hole: everything from that position on (protected and post-protected
    // alike) stays visible and causality holds. A protected message at the
    // range TAIL (the advisory recent-zone brush this carve was built for)
    // has nothing after it inside the range — truncation is a no-op there.
    const firstProtectedIdx = filteredIds.findIndex((id) => protectedSet.has(id));
    let truncatedAfter = 0;
    if (firstProtectedIdx >= 0) {
      const truncatable = filteredIds.length - firstProtectedIdx - hitProtectedRaw.length;
      // Truncate only when the truncated prefix still has work to do AND the
      // cut does not strand a tool call/result pair across it (kept call,
      // dropped result or vice versa — the #684 gate would either fatal at
      // the protected-zone boundary or force a withdrawal the advisory carve
      // was never designed for). When truncation would empty the range or
      // split a pair (protected ids at the HEAD — e.g. absorb-context
      // protection around an absorbed pair), keep the advisory carve
      // semantics: fold what remains, exactly as before (#3953 changes
      // nothing there; the zone fatal below still fires only when even the
      // carve empties the range).
      // #5337 option A: pair map shared across units; the DROP side becomes a
      // Set so membership stays O(1) — the previous .includes() inside .some()
      // made this branch quadratic in unit width.
      const pairByCallId = shared?.pairByCallId ?? buildPairMap(input.messages);
      const keptIds = filteredIds.slice(0, firstProtectedIdx);
      const droppedIds = filteredIds.slice(firstProtectedIdx);
      const droppedSet = new Set(droppedIds);
      const strandsPair = keptIds.some((id) => {
        const m = msgById(id);
        if (!m || (m.contentType !== "tool-call" && m.contentType !== "tool-result")) return false;
        const pair = pairByCallId.get(m.toolCallId ?? m.id);
        return (
          !!pair &&
          pair.some(
            (half) => half !== "" && half !== id && droppedSet.has(half),
          )
        );
      });
      if (truncatable > 0 && firstProtectedIdx > 0 && !strandsPair) {
        truncatedAfter = truncatable;
        filteredIds = keptIds;
        for (const id of droppedIds) effectiveMessageIds.delete(id);
      }
    }
    filteredIds = filteredIds.filter((id) => !protectedSet.has(id));
    // Remove protected messages from effective coverage too, so they are NOT
    // hidden by the new block (they must stay fully visible).
    for (const id of hitProtectedRaw) effectiveMessageIds.delete(id);

    const hitRefs = hitProtectedRaw
      .map((id) => input.state.messageRefs.byRaw[id])
      .filter((v): v is string => typeof v === "string");

    if (filteredIds.length === 0 && consumedBlockIds.length === 0) {
      const recentN = input.config.preserveRecentMessages;
      // #5789: an empty-after-exclusion span is NOT the protected-zone case —
      // every nested block was excluded by the recovery ladder because its
      // coverage strands a live conflict. Zone fatals are treated as no-op
      // successes by applySingleRange (#4521); this one must stay a hard
      // error with actionable guidance.
      const excludedFatal =
        excludedNestedBlockIds.length > 0
          ? new Error(
              `Merging ${resolved.nestedBlockIds.join(", ")} cannot proceed: excluding ${excludedNestedBlockIds.join(", ")} (their coverage would strand a live turn-integrity conflict) leaves nothing left to fold in ${input.startRef}..${input.endRef}. Fold the stranded visible partner(s) first with a plain message-range compress so the turn closes, or retry once those block(s) can fold whole.`,
            )
          : null;
      return finish({
        fatal: {
          kind: excludedFatal ? "split" : "zone",
          error:
            excludedFatal ??
            new Error(
              `Range is entirely within the protected zone (the last ${recentN} messages and/or the most recent user message): ${hitRefs.join(
                ", ",
              )}. Adjust startId/endId to older messages.`,
            ),
        },
      });
    }
    const anchorMsg = shared
      ? shared.anchorMessage
      : lastUserAnchor(input.messages, coveredMessageIds(input.state), input.config);
    const anchorRef = anchorMsg ? input.state.messageRefs.byRaw[anchorMsg.id] : undefined;
    const anchorNote =
      anchorRef && anchorRef !== "BLOCKED"
        ? ` Last-user anchor: ${anchorRef} "${(anchorMsg!.text ?? "").replace(/\s+/g, " ").slice(0, 40)}".`
        : "";
    warnings.push(
      `Excluded ${hitProtectedRaw.length} protected message(s) ${hitRefs.join(
        ", ",
      )} from compression range (recent/last-user zone) — they stay visible outside the new block; do not target them in another compress call.` +
        anchorNote +
        (truncatedAfter > 0
          ? ` Range truncated at that boundary — ${truncatedAfter} later message(s) (including replies to the protected message) stay visible too, so no summary can land above the question it answers (#3953).`
          : ""),
    );
  }

  // TURN-INTEGRITY GATE (#684): the protected carve above (and the protected
  // tool filter before it) remove individual messages AFTER
  // applyPairBoundaryAdjustments completed the range, which can split a turn.
  // The DIRECTIONAL invariant that strict-echo providers enforce: an assistant
  // tool-call message that survives the fold must keep its reasoning run
  // (DeepSeek thinking mode: "reasoning_content ... must be passed back").
  // The reverse split — reasoning + text kept while the call and result fold —
  // leaves a valid message stream and stays allowed (#564 depends on it), so
  // only turns whose KEPT side carries a tool-call while the FOLDED side
  // carries the reasoning are withdrawn, entirely (all members stay visible).
  // The same carve can also strip a call and its result onto opposite sides of
  // the fold. Either half alone is invalid — a visible call whose result folded
  // is an unanswered tool_call_id, a visible result whose call folded answers
  // nothing — so those pairs are withdrawn together, both halves staying
  // visible. Whole pairs may still fold while the turn's reasoning and text
  // stay visible (#564).
  //
  // Both invariants are re-checked to a fixed point inside
  // computeIntegrityWithdrawals: withdrawing a pair for the result half can
  // strand a turn whose reasoning still folds and whose call now stays visible.
  {
    // #4484/#3322: on a MERGE (this unit consumes existing blocks) the integrity
    // gate needs two things a fresh fold does not. (a) Judge POST-FOLD coverage —
    // this unit's ids PLUS every still-active sibling block's coverage — so a tool
    // half already covered by an unconsumed sibling reads as folded, not a spurious
    // "visible" half (#3322 withdrew inherited coverage for exactly this reason).
    // (b) Never drop an id whose ONLY covering block is consumed here: those blocks
    // deactivate below, so removing their id strands it uncovered — the regression
    // the host pre-commit guard then refuses (#4484). We therefore unfold only ids
    // whose coverage does not depend on a consumed block, re-checking to a fixed
    // point; if consistency would force unfolding such an id we fail honestly rather
    // than emit a doomed regressive candidate. Fresh folds keep the legacy behavior.
    const isMerge = consumedBlockIds.length > 0;
    let consumedCoverage = new Set<string>();
    let survivingCoverage = new Set<string>();
    if (isMerge) {
      const consumedSet = new Set(consumedBlockIds);
      for (const block of activeBlocks(input.state)) {
        const target = consumedSet.has(block.blockId)
          ? consumedCoverage
          : survivingCoverage;
        for (const id of block.effectiveMessageIds) target.add(id);
      }
    }
    let foldedRef = effectiveMessageIds;
    if (isMerge) {
      foldedRef = new Set(effectiveMessageIds);
      for (const id of survivingCoverage) foldedRef.add(id);
    }
    // #5531: fresh folds judge on their OWN ids alone, so the coverage of OTHER
    // active blocks must arrive as the invisible set — a covered call is not
    // kept-visible and cannot strand its turn's reasoning (#564 reverse-split
    // residue, billion-context#5531). Merges already model post-fold coverage
    // through foldedRef ∪ survivingCoverage and stay untouched.
    const initial = computeIntegrityWithdrawals(
      input.messages,
      foldedRef,
      shared?.integrityPre,
      isMerge ? undefined : input.preExistingCoverage,
    );
    splitTurnCount = initial.splitTurnCount;
    splitPairCount = initial.splitPairCount;
    if (initial.withdrawn.size > 0) {
      const splitDesc = [
        splitTurnCount > 0 ? `${splitTurnCount} turn(s)` : null,
        splitPairCount > 0 ? `${splitPairCount} tool call/result pair(s)` : null,
      ]
        .filter((part): part is string => part !== null)
        .join(" and ");
      if (!isMerge) {
        withdrawnIds = initial.withdrawn;
        for (const id of initial.withdrawn) effectiveMessageIds.delete(id);
        const beforeWithdraw = filteredIds.length;
        filteredIds = filteredIds.filter((id) => !initial.withdrawn.has(id));
        if (filteredIds.length === 0 && consumedBlockIds.length === 0) {
          return finish({
            fatal: {
              kind: "split",
              error: new Error(
                `Range would split ${splitDesc} at the protected-zone boundary: a visible tool-call must keep its reasoning run and its results (strict providers reject a rebuilt request that lost either). Shrink the range to end before the turn starts, or wait until the whole turn ages out of the protected zone.`,
              ),
            },
          });
        }
        warnings.push(
          `Withdrawn ${beforeWithdraw - filteredIds.length} message(s) from compression range to keep ${splitDesc} intact (visible tool-call would lose its reasoning run or its results).`,
        );
      } else {
        const unfoldable = new Set<string>(
          [...effectiveMessageIds].filter((id) => !consumedCoverage.has(id)),
        );
        const unfolded = new Set<string>();
        let current = initial.withdrawn;
        let guard = unfoldable.size + 2;
        let stuck = false;
        while (current.size > 0 && guard-- > 0) {
          let progress = false;
          for (const id of current) {
            if (unfoldable.has(id) && !unfolded.has(id)) {
              unfolded.add(id);
              progress = true;
            }
          }
          if (!progress) {
            stuck = true;
            break;
          }
          const recheck = new Set(effectiveMessageIds);
          for (const id of unfolded) recheck.delete(id);
          for (const id of survivingCoverage) recheck.add(id);
          current = computeIntegrityWithdrawals(
            input.messages,
            recheck,
            shared?.integrityPre,
          ).withdrawn;
        }
        if (stuck || current.size > 0) {
          // #5789: a conflict whose withdrawn ids are ENTIRELY outside this
          // merge's fold set pre-dates it — the merge neither created nor
          // worsened it (every id it touches stays covered, owner aside).
          // Refusing over such conflicts kills EVERY merge in a session that
          // carries one historical split (the reported permanent T2 death:
          // survivingCoverage is global, so one poison block dooms all
          // merges, even of two adjacent clean blocks). Tolerate: inherit
          // the conflict as-is and warn honestly.
          // A conflict only binds THIS merge when it touches content the merge
          // newly folds (filteredIds) or re-owns (consumed coverage transfers
          // to the new block). Ids merely inside the span geometry, or owned
          // by surviving/excluded blocks, keep their covered status either way
          // — their conflicts are inherited, not caused. #4484's invariant
          // (a merge never drops existing coverage) holds: nothing here
          // unfolds a covered id into the visible stream permanently.
          const mergeOwned = new Set<string>([
            ...filteredIds,
            ...consumedCoverage,
          ]);
          const relevantUnresolved = [...current].filter((id) =>
            mergeOwned.has(id),
          );
          if (relevantUnresolved.length === 0) {
            // Merge-neutral: inherit and continue to the success path below
            // (do NOT return — the fatal must be skipped).
            warnings.push(
              `Inherited a pre-existing turn-integrity conflict this merge does not touch (${[...current].slice(0, 6).map((id) => input.state.messageRefs.byRaw[id] ?? id).join(", ")}): the partner(s) are already covered by other blocks or still visible. Left as-is — fold the visible partner(s) into coverage to clear it.`,
            );
          } else {
            // #5919: classify the stranded set BEFORE the exclusion dance.
            // A merge can only end one of two ways: by closing the turn
            // (every partner of every folded reasoning/call gets coverage)
            // or by keeping the poison block active AROUND a turn that is
            // already closed outside the span. A stranded partner that can
            // NEVER fold (BLOCKED / recent-zone / protected tool /
            // unrecoverable media) makes both impossible — pre-#5919 that
            // surfaced as a retryable "cannot satisfy turn integrity" fatal
            // promising the partner(s) would "age into coverage", which never
            // happens: every retry re-failed the same way and the advertised
            // merge dead-ended (billion-context#5919, session-ad47cd30).
            // Such a merge is now an idempotent no-op with exact guidance.
            const refOf5919 = (id: string): string =>
              input.state.messageRefs.byRaw[id] ?? id;
            const isNeverFoldable5919 = (id: string): boolean => {
              const ref = refOf5919(id);
              const msg = msgById(id);
              if (ref === "BLOCKED" || !msg) return true;
              if (input.protectedMessageIds?.has(ref)) return true;
              if (
                filterProtectedToolMessages(
                  [id],
                  input.messages,
                  input.config,
                  shared,
                ).length === 0
              )
                return true;
              return hasUnrecoverableMediaPayload(msg);
            };
            const visibleStranded = [...current].filter(
              (id) => !survivingCoverage.has(id) && !consumedCoverage.has(id),
            );
            const doomedStranded = visibleStranded.filter(isNeverFoldable5919);
            if (doomedStranded.length > 0) {
              const foldablePartners = visibleStranded.filter(
                (id) => !isNeverFoldable5919(id),
              );
              warnings.push(
                `Merge of ${consumedBlockIds.join(", ")} skipped — its turn cannot be closed now: ${doomedStranded.map(refOf5919).join(", ")} ${doomedStranded.length === 1 ? "is" : "are"} protected (never foldable) while the rest of their turn is covered by block(s). Do not retry this merge.${foldablePartners.length > 0 ? ` The foldable partner(s) ${foldablePartners.map(refOf5919).join(", ")} can only close their turn together with the protected member(s) — they stay visible until the protection lifts.` : ""}`,
              );
              // Consume nothing so the no-op below leaves every block active
              // (coverage intact — the #4484 invariant).
              consumedBlockIds = [];
              filteredIds = [];
              return finish({ fatal: null });
            }
            // #5919 rung 2 (fallback): rung 1 (the exclusion ladder) could
            // not complete the merge — it re-failed, or it "succeeded" by
            // folding nothing while the conflict stays live (the silent
            // variant of the same deadlock). Before surfacing the fatal, try
            // closing the turn by extending THIS fold to the stranded visible
            // partner(s): the exact manual unblock the old error text
            // instructed ("fold the stranded visible partner(s) first with a
            // plain message-range compress"), done automatically so the
            // advertised merge stops dead-ending (billion-context#5919).
            let extended5919 = false;
            const tryExtend5919 = (): boolean => {
              if (
                extended5919 ||
                visibleStranded.length === 0 ||
                visibleStranded.length > 16
              )
                return false;
              // Every stranded member is foldable (the doomed check above
              // already no-ops the protected/BLOCKED ones). Commit the
              // extension only if a fixed-point re-judge shows NO fold-side
              // withdrawal (the same judge the merge path below runs).
              const extended = new Set(effectiveMessageIds);
              for (const id of unfolded) extended.delete(id);
              for (const id of visibleStranded) extended.add(id);
              const checkBase = new Set(extended);
              for (const id of survivingCoverage) checkBase.add(id);
              let clean = false;
              let check = new Set(checkBase);
              for (let guard = 0; guard < 8; guard++) {
                const w = computeIntegrityWithdrawals(
                  input.messages,
                  check,
                  shared?.integrityPre,
                ).withdrawn;
                if (w.size === 0) {
                  clean = true;
                  break;
                }
                let touchesFold = false;
                for (const id of w) {
                  if (extended.has(id)) {
                    touchesFold = true;
                    break;
                  }
                }
                if (touchesFold) break;
                const next = new Set(check);
                for (const id of w) next.delete(id);
                if (next.size === check.size) break;
                check = next;
              }
              if (!clean) return false;
              for (const id of visibleStranded) {
                if (skippedCarrierIds.includes(id)) continue;
                effectiveMessageIds.add(id);
                if (!directMessageIds.includes(id))
                  directMessageIds.push(id);
                if (!filteredIds.includes(id)) filteredIds.push(id);
              }
              warnings.push(
                `Extended this merge to fold stranded partner(s) ${visibleStranded.map(refOf5919).join(", ")} so the turn closes (billion-context#5919) — the new block's coverage includes them.`,
              );
              extended5919 = true;
              return true;
            };
            let retried: UnitProjection | null = null;
            if ((input.excludeNestedBlockIds?.size ?? 0) < 64) {
              const ownerByMessageId = new Map<string, string>();
              for (const bid of consumedBlockIds) {
                const block = blockById(input.state, bid);
                if (!block) continue;
                for (const id of block.effectiveMessageIds)
                  ownerByMessageId.set(id, bid);
              }
              const offending = [
                ...new Set(
                  relevantUnresolved
                    .filter((id) => !survivingCoverage.has(id))
                    .map((id) => ownerByMessageId.get(id))
                    .filter((bid): bid is string => bid !== undefined),
                ),
              ].sort();
              if (offending.length > 0) {
                retried = projectUnit({
                  ...input,
                  excludeNestedBlockIds: new Set([
                    ...(input.excludeNestedBlockIds ?? []),
                    ...offending,
                  ]),
                });
                const retriedFoldedNothing =
                  retried.fatal === null &&
                  retried.filteredIds.length === 0 &&
                  retried.consumedBlockIds.length === 0;
                if (retried.fatal === null && !retriedFoldedNothing) {
                  warnings.push(
                    `Excluded ${offending.join(", ")} from this merge — their coverage cuts through a turn group whose partner(s) are still visible outside the span, and unfolding them would drop their only coverage. They stay ACTIVE (coverage intact); the merge proceeded around them.`,
                  );
                  return retried;
                }
                // Rung 1 could not complete the merge (re-failed, or folded
                // nothing while the conflict stays live) — rung 2.
                tryExtend5919();
              } else {
                // No consumed block owns the unresolved ids: nothing to
                // exclude — rung 2 directly.
                tryExtend5919();
              }
            } else {
              // Ladder exhausted (64 exclusions) — rung 2.
              tryExtend5919();
            }
            if (!extended5919) {
              if (retried !== null && retried.fatal === null) {
                // Rung 1 "succeeded" by folding nothing and rung 2 had no
                // foldable partner to extend to (the #5789 self-range no-op
                // shape): keep the pinned idempotent no-op — a retry here
                // must not arm the breaker.
                return retried;
              }
              return finish({
                fatal: {
                  kind: "split",
                  error: new Error(
                    actionableSplitError(consumedBlockIds, current, input),
                  ),
                },
              });
            }
            // #5919 rung 2 committed the extension: the fold now closes the
            // turn, so fall through to the common withdrawal handling below
            // (the same path merge-neutral inheritance takes).
          }
        }
        withdrawnIds = unfolded;
        for (const id of unfolded) effectiveMessageIds.delete(id);
        const beforeWithdraw = filteredIds.length;
        filteredIds = filteredIds.filter((id) => !unfolded.has(id));
        if (beforeWithdraw !== filteredIds.length) {
          warnings.push(
            `Withdrew ${beforeWithdraw - filteredIds.length} newly-folded message(s) from the merge to keep ${splitDesc} intact while preserving the existing coverage of ${consumedBlockIds.join(", ")}.`,
          );
        }
      }
    }
  }

  return finish({ fatal: null });

  function finish(
    partial: Pick<UnitProjection, "fatal">,
  ): UnitProjection {
    return {
      ...partial,
      rangeMessageIds,
      skippedCarrierIds,
      nestedBlockIds: [...resolved.nestedBlockIds],
      consumedBlockIds,
      effectiveMessageIds,
      directMessageIds,
      filteredIds,
      withdrawnIds,
      splitTurnCount,
      splitPairCount,
      targetTier,
      outputTier,
      isBlockBoundary,
    };
  }
}

/** #5337 option A: every per-screening-pass O(n) derivation over ONE message
 *  array, computed ONCE instead of once per screened unit. This was the
 *  quadratic term of the recommend node: U units x O(n) rescans (history
 *  index maps, carrier scan, protected/latest/aged collectors, tool-pairing
 *  map, last-user anchor, turn-integrity pre-scan) about O(n^2) total —
 *  ~17 s for a single processTurn at 23k core messages while Node's event
 *  loop was blocked (#5304 repro on v0.1.209).
 *
 *  Build once per (messages, state, config) triple via
 *  {@link buildProjectionShared} and pass to every projectUnit call on that
 *  triple. Semantics are byte-identical: each field is exactly the value the
 *  corresponding inline computation produced per unit (projectUnit screens
 *  many units against one immutable array within a turn). The judgment
 *  criteria themselves (#3236 discipline) are untouched — only how the
 *  inputs reach them changed. */
export interface ProjectionShared {
  /** Raw-id -> index over `messages` (last occurrence wins, map semantics). */
  byId: Map<string, number>;
  /** Host checkpoint carriers (#335/#2663) — the plain-range scan result. */
  liveCarrierIds: Set<string>;
  /** Failed-compress exchange toolCallIds (#4289). */
  failedCompressCallIds: Set<string>;
  /** Latest-only protection sets (protectedLatestTools). */
  latestProtected: LatestProtected;
  /** Aged compress-exchange toolCallIds (#4348 fold exemption lift). */
  agedCompressCallIds: Set<string>;
  /** latest.callIds plus the full-history protected-tool scan — the exact
   *  base set filterProtectedToolMessages builds without sharing. Callers
   *  must COPY it (per-unit passes add removed ids' toolCallIds). Immutable. */
  baseProtectedCallIds: Set<string>;
  /** tool-call/tool-result pairing keyed by toolCallId ?? id. */
  pairByCallId: Map<string, [string, string]>;
  /** Per-toolCallId [lowest, highest] positions over the whole array —
   *  #5751 id-exact boundary widening. Rebuilding it per unit is the #5337
   *  quadratic class (U units x O(n)) — hence shared. Immutable. */
  toolPairExtremes: Map<string, [number, number]>;
  /** Last visible user anchor (drives the #3953 truncation warning note). */
  anchorMessage: CoreMessage | undefined;
  /** Per-message inputs of computeIntegrityWithdrawals (#684 gate). */
  integrityPre: IntegrityPre;
}

/** One-pass build of {@link ProjectionShared}; see that interface for what
 *  each field mirrors and why one build serves an entire screening pass. */
export function buildProjectionShared(
  messages: CoreMessage[],
  state: CompressionState,
  config: Config,
): ProjectionShared {
  const liveCarrierIds = new Set<string>();
  for (const message of messages) {
    if (isLiveCheckpointCarrier(message, state)) liveCarrierIds.add(message.id);
  }
  const failedCompressCallIds = collectFailedCompressCallIds(messages, config);
  const latestProtected = collectLatestProtected(messages, config);
  const agedCompressCallIds = collectAgedCompressCallIds(messages, config);
  const baseProtectedCallIds = new Set<string>(latestProtected.callIds);
  const isExemptFold = (msg: CoreMessage): boolean =>
    !!msg.toolCallId && agedCompressCallIds.has(msg.toolCallId);
  for (const msg of messages) {
    if (
      isMessageProtected(msg, config, failedCompressCallIds) &&
      msg.toolCallId &&
      !isExemptFold(msg)
    ) {
      baseProtectedCallIds.add(msg.toolCallId);
    }
  }
  return {
    byId: buildIndexByMessageId(messages),
    liveCarrierIds,
    failedCompressCallIds,
    latestProtected,
    agedCompressCallIds,
    baseProtectedCallIds,
    pairByCallId: buildPairMap(messages),
    toolPairExtremes: buildToolPairExtremes(messages),
    anchorMessage: lastUserAnchor(messages, coveredMessageIds(state), config),
    integrityPre: buildIntegrityPre(messages),
  };
}

/** tool-call/tool-result pairing map over a whole message array (a side may
 *  be empty until its half shows up). Mirrors the inline map the #3953
 *  truncation check used to rebuild per unit. */
function buildPairMap(messages: CoreMessage[]): Map<string, [string, string]> {
  const pairByCallId = new Map<string, [string, string]>();
  for (const m of messages) {
    if (m.contentType === "tool-call" || m.contentType === "tool-result") {
      const key = m.toolCallId ?? m.id;
      const pair = pairByCallId.get(key) ?? ["", ""];
      if (m.contentType === "tool-call") pair[0] = m.id;
      else pair[1] = m.id;
      pairByCallId.set(key, pair);
    }
  }
  return pairByCallId;
}

/** Union of the raw ids covered by all active blocks — the set apply treats
 * as "already folded" before a new spec runs (one per applyCompression call). */
export function collectCoverage(state: CompressionState): Set<string> {
  const coverage = new Set<string>();
  for (const block of activeBlocks(state)) {
    for (const id of block.effectiveMessageIds) coverage.add(id);
  }
  return coverage;
}

function applyPairBoundaryAdjustments(
  resolved: {
    startIndex: number;
    endIndex: number;
    messageIds: string[];
    boundaryKind: string;
  },
  messages: CoreMessage[],
  shared?: ProjectionShared,
): string[] {
  if (resolved.boundaryKind === "block") {
    return resolved.messageIds;
  }
  // Compose tool-pair and reasoning-pair boundary adjustments to a fixpoint
  // (≤2 passes). Reasoning may pull in a tool-call whose result tool-pairs
  // then extends for; tool-pairs may pull in a tool-call whose preceding
  // reasoning is then drawn in. Both only ever WIDEN the range.
  let startIndex = resolved.startIndex;
  let endIndex = resolved.endIndex;
  for (let pass = 0; pass < 2; pass++) {
    const reasoningAdjusted = adjustBoundariesForReasoningPairs(
      startIndex,
      endIndex,
      messages,
    );
    const toolAdjusted = adjustBoundariesForToolPairs(
      reasoningAdjusted.startIndex,
      reasoningAdjusted.endIndex,
      messages,
      shared?.toolPairExtremes,
    );
    const changed =
      toolAdjusted.startIndex !== startIndex ||
      toolAdjusted.endIndex !== endIndex;
    startIndex = toolAdjusted.startIndex;
    endIndex = toolAdjusted.endIndex;
    if (!changed) break;
  }
  if (startIndex === resolved.startIndex && endIndex === resolved.endIndex) {
    return resolved.messageIds;
  }
  const ids: string[] = [];
  for (let i = startIndex; i <= endIndex; i++) {
    const msg = messages[i];
    if (msg) ids.push(msg.id);
  }
  return ids;
}

function filterProtectedToolMessages(
  directMessageIds: string[],
  messages: CoreMessage[],
  config: Config,
  shared?: ProjectionShared,
): string[] {
  // Protected tool calls (and their results, paired by toolCallId) stay in
  // visible context and are simply dropped from the compressible set. They are
  // NOT folded into the summary — the summary reflects what the author wrote,
  // nothing auto-appended.
  // #4289: failed compress exchanges (result = "[Compression FAILED…", zero
  // ranges applied) are NOT protected — they are dead drafts that must stay
  // foldable so a failing compress loop cannot permanently bloat context.
  // #5337 option A: each collector below is a full O(n) history scan. With a
  // shared context they were derived ONCE per screening pass (the ?? inline
  // fallbacks keep the single-shot apply/report paths identical to the
  // pre-sharing implementation). `baseProtectedCallIds` already unions
  // latest.callIds with the full-history protection scan; callers copy it
  // because the per-unit passes below may add to it.
  const failedCompressCallIds =
    shared?.failedCompressCallIds ??
    collectFailedCompressCallIds(messages, config);
  const protectedCallIds = new Set<string>(shared?.baseProtectedCallIds ?? []);
  const removedIds = new Set<string>();
  const latest =
    shared?.latestProtected ?? collectLatestProtected(messages, config);
  // #4348: compress exchanges older than the newest few lose the hard-coded
  // ALWAYS_PROTECTED_TOOLS exemption inside the FOLD path — their receipts
  // are exhaust and the summaries live on in block anchors. Newest exchanges
  // keep it (working memory). The lift overrides host protection patterns for
  // recognized compress dialects too — required, since the MCP lane's
  // hard-protection hook would otherwise pin mcp__bili__compress forever;
  // host patterns for all other tools are unaffected.
  const agedCompressCallIds =
    shared?.agedCompressCallIds ?? collectAgedCompressCallIds(messages, config);
  const isExemptFold = (msg: CoreMessage): boolean =>
    !!msg.toolCallId && agedCompressCallIds.has(msg.toolCallId);
  if (!shared) {
    for (const id of latest.callIds) protectedCallIds.add(id);
    for (const msg of messages) {
      if (
        isMessageProtected(msg, config, failedCompressCallIds) &&
        msg.toolCallId &&
        !isExemptFold(msg)
      ) {
        protectedCallIds.add(msg.toolCallId);
      }
    }
  }
  // Shared byId resolves duplicate ids to the LAST occurrence — the semantics
  // of every existing index-based path (resolveBoundaries always used maps).
  // The replaced .find() hits returned the FIRST, reachable only on invalid
  // duplicate-id inputs (message ids are ledger-unique in practice).
  const byId = shared?.byId;
  const lookupMsg = (id: string): CoreMessage | undefined =>
    byId === undefined
      ? messages.find((m) => m.id === id)
      : messages[byId.get(id) ?? -1];

  for (const id of directMessageIds) {
    const msg = lookupMsg(id);
    if (!msg) continue;
    if (
      hasUnrecoverableMediaPayload(msg) ||
      (isMessageProtected(msg, config, failedCompressCallIds) &&
        !isExemptFold(msg)) ||
      isMessageLatestProtected(msg, latest)
    ) {
      removedIds.add(id);
      if (msg.toolCallId) protectedCallIds.add(msg.toolCallId);
    }
  }

  for (const id of directMessageIds) {
    if (removedIds.has(id)) continue;
    const msg = lookupMsg(id);
    if (!msg) continue;
    if (
      msg.contentType === "tool-result" &&
      msg.toolCallId &&
      protectedCallIds.has(msg.toolCallId)
    ) {
      removedIds.add(id);
    }
  }

  return directMessageIds.filter((id) => !removedIds.has(id));
}

function resolveTargetTier(
  state: CompressionState,
  nestedBlockIds: string[],
  isBlockBoundary: boolean,
): CompressionTier {
  if (!isBlockBoundary) return 1;
  if (nestedBlockIds.length === 0) return 1;
  let minTier: CompressionTier = 3;
  for (const id of nestedBlockIds) {
    const block = blockById(state, id);
    if (block && block.tier < minTier) minTier = block.tier;
  }
  return minTier;
}

/** #5789: actionable refusal for merges the exclusion ladder cannot complete
 *  — names the exact conflicted refs, who covers them, and the concrete next
 *  moves (fold the stranded partner first / sub-span around the offender).
 *  Keeps the "cannot satisfy turn integrity" phrase the host and the #4484
 *  suite key on. */
function actionableSplitError(
  consumedBlockIds: string[],
  unresolved: ReadonlySet<string>,
  input: UnitProjectionInput,
): string {
  const refOf = (id: string): string =>
    input.state.messageRefs.byRaw[id] ?? id;
  const consumedOwners = new Map<string, string>();
  const survivingOwners = new Map<string, string>();
  for (const block of activeBlocks(input.state)) {
    const map = consumedBlockIds.includes(block.blockId)
      ? consumedOwners
      : survivingOwners;
    for (const id of block.effectiveMessageIds) map.set(id, block.blockId);
  }
  const detail = [...unresolved]
    .slice(0, 6)
    .map((id) => {
      const ref = refOf(id);
      const owner = consumedOwners.get(id) ?? survivingOwners.get(id);
      return owner ? `${ref} (covered by ${owner})` : `${ref} (visible)`;
    })
    .join(", ");
  const survivingOffenders = [
    ...new Set(
      [...unresolved]
        .map((id) => survivingOwners.get(id))
        .filter((bid): bid is string => bid !== undefined),
    ),
  ];
  const visibleRefs = [...unresolved]
    .filter((id) => !consumedOwners.has(id) && !survivingOwners.has(id))
    .map(refOf)
    .sort((a, b) => refNum5919(a) - refNum5919(b) || a.localeCompare(b))
    .slice(0, 6);
  const unblockHint =
    visibleRefs.length > 0
      ? ` The exact unblock: one plain message-range compress over ${visibleRefs[0]}..${visibleRefs[visibleRefs.length - 1]!} (it may cover extra messages — that is fine), then retry this merge — the conflict clears once those partner(s) are covered.`
      : ` The exact unblock: fold the stranded partner(s) listed above into coverage with a plain message-range compress, then retry this merge.`;
  const tail =
    survivingOffenders.length > 0
      ? ` Block(s) ${survivingOffenders.join(", ")} stay active with their current coverage; this merge will not touch them.`
      : ` Merge a sub-span that stops before or resumes after the offending block instead.`;
  return `Merging ${consumedBlockIds.join(", ")} cannot satisfy turn integrity without dropping existing coverage: folding would strand ${detail}. Do not retry the same span — fold the stranded visible partner(s) first with a plain message-range compress so the turn closes.${unblockHint}${tail}`;

/** #5919: numeric order for the unblock hint (BLOCKED sorts last). */
function refNum5919(ref: string): number {
  const m = /^m(\d+)$/.exec(ref);
  return m ? Number(m[1]!) : Number.MAX_SAFE_INTEGER;
}
}
