import type { Context } from '@deepseek-ai/cordis'
import type { FoldBounds } from './config'
import { asRecord } from './record'
import { serviceIdentityOf } from './serviceIdentity'
import { type ColdReadGate, makeColdReadGate } from './coldRead'
import { buildTimelineDetail, buildTimelineHead } from './foldWire'
import { withCost, withDetailCost, type CostSource } from './cost'
import { DetailShadow, foldLog } from './detailShadow'
import { failure, leaseOf, mountPostRoute, observeOf, readBody, reply, revisionOf } from './postRoute'
import type { ContextTimelineDetail, Snapshot } from '../shared/types'
import type { TimelineState } from './foldState'

export const DETAIL_ROUTE = '/api/dsh-context/detail'

const IDLE_SWEEP_MS = 20_000

const PAYLOAD_CACHE_MAX = 4

interface ColdPayload {
  persistence: unknown
  revision: string
  value: ContextTimelineDetail
}

function headPayloadOf(state: TimelineState, cost?: CostSource): { rev: number; head: Snapshot } {
  return { rev: state.detailRev ?? 0, head: withCost(cost, buildTimelineHead(state)) }
}

export interface DetailChannelGate {
  live: boolean
  retain(key: string, registration: unknown): void
  stateOf(session: unknown, key: string): unknown
}

interface ProjectionHandleLike {
  stateOf(session: unknown): unknown
}

function handleOf(value: unknown): ProjectionHandleLike | undefined {
  if (value === null || typeof value !== 'object') return undefined
  const stateOf = (value as { stateOf?: unknown }).stateOf
  return typeof stateOf === 'function' ? value as ProjectionHandleLike : undefined
}

export function createDetailGate(ctx: Context): DetailChannelGate {
  const handles = new Map<string, ProjectionHandleLike>()
  return {
    live: false,
    retain(key: string, registration: unknown): void {
      if (registration === null || (typeof registration !== 'object' && typeof registration !== 'function')) return
      const then = (registration as { then?: unknown }).then
      if (typeof then !== 'function') return
      void Promise.resolve(registration as Promise<unknown>).then(
        (handle) => {
          const retained = handleOf(handle)
          if (retained !== undefined) handles.set(key, retained)
        },
        (error: unknown) => { ctx.logger.error(error) },
      )
    },
    stateOf(session: unknown, key: string): unknown {
      const handle = handles.get(key)
      if (handle !== undefined) return handle.stateOf(session)
      const projections = ctx.sessionProjections as unknown as { stateOf?(session: unknown, key: string): unknown } | undefined
      return typeof projections?.stateOf === 'function' ? projections.stateOf(session, key) : undefined
    },
  }
}

interface SessionsHostFace {
  get?(id: string): unknown
}

export function watchDetailChannel(
  ctx: Context,
  bounds: FoldBounds,
  coldReads: ColdReadGate = makeColdReadGate(),
  gate: DetailChannelGate = createDetailGate(ctx),
  shadow: DetailShadow = new DetailShadow(ctx, bounds, coldReads, () => observeOf(ctx)),
  cost?: CostSource,
  options: { idleSweepMs?: number } = {},
): DetailChannelGate {
  const idleSweepMs = options.idleSweepMs ?? IDLE_SWEEP_MS
  const payloads = new Map<string, ColdPayload>()
  let sweepTimer: ReturnType<typeof setTimeout> | null = null
  const touch = (): void => {
    if (sweepTimer !== null) clearTimeout(sweepTimer)
    sweepTimer = setTimeout(() => {
      sweepTimer = null
      payloads.clear()
    }, idleSweepMs)
    ;(sweepTimer as { unref?: () => void }).unref?.()
  }
  ctx.effect(() => () => {
    if (sweepTimer !== null) clearTimeout(sweepTimer)
    sweepTimer = null
  }, 'dsh-context: detail payload sweep')
  mountPostRoute({
    ctx,
    deps: ['connection', 'sessions'],
    path: DETAIL_ROUTE,
    label: 'dsh-context: detail route',
    gate,
    handler: (c) => {
      const sessions = c.get('sessions') as SessionsHostFace | undefined
      const getSession = typeof sessions?.get === 'function' ? sessions.get.bind(sessions) : undefined
      if (getSession === undefined) return undefined

      return async (request: Request): Promise<Response> => {
        touch()
        const read = await readBody(request)
        if (!read.ok) return read.response
        const body = read.body
        const sessionId = body !== null && typeof body === 'object'
          ? (body as { sessionId?: unknown }).sessionId
          : undefined
        const headOnly = body !== null && typeof body === 'object' && (body as { head?: unknown }).head === true
        if (typeof sessionId !== 'string' || sessionId === '') {
          return failure('dsh-context/bad-request', 'missing sessionId')
        }
        try {
          const session = getSession(sessionId)
          if (session !== undefined && session !== null) {
            const state = gate.stateOf(session, 'contextTimeline') as TimelineState | undefined
            if (state === undefined) return reply({ ok: true, value: null })
            if (headOnly) return reply({ ok: true, value: headPayloadOf(state, cost) })
            const detailState = await shadow.stateOf(sessionId)
            if (detailState === null) return reply({ ok: true, value: null })
            return reply({ ok: true, value: withDetailCost(cost, buildTimelineDetail(detailState, bounds)) })
          }
          const observe = observeOf(ctx)
          if (observe === undefined) return reply({ ok: true, value: null })
          const value = await coldReads.admit(async () => {
            const observation = await observe(sessionId, { projectionMode: 'none' })
            const release = leaseOf(observation)
            try {
              const persistence = serviceIdentityOf(ctx.get('sessionPersistence'))
              const revision = revisionOf(observation)
              if (revision !== undefined) {
                const hit = payloads.get(sessionId)
                if (hit !== undefined && hit.revision === revision && hit.persistence === persistence) {
                  payloads.delete(sessionId)
                  payloads.set(sessionId, hit)
                  if (headOnly) {
                    /* v8 ignore next 1 */
                    return hit.value.head === undefined
                      ? { rev: hit.value.rev }
                      : { rev: hit.value.rev, head: withCost(cost, hit.value.head) }
                  }
                  return withDetailCost(cost, hit.value)
                }
              }
              const events = asRecord(observation)?.events
              if (!Array.isArray(events)) return null
              const state = (await foldLog(events, bounds)).state
              if (headOnly) return headPayloadOf(state, cost)
              const detail = buildTimelineDetail(state, bounds)
              if (revision === undefined) return withDetailCost(cost, detail)
              payloads.delete(sessionId)
              payloads.set(sessionId, { persistence, revision, value: detail })
              for (const oldest of payloads.keys()) {
                if (payloads.size <= PAYLOAD_CACHE_MAX) break
                payloads.delete(oldest)
              }
              return withDetailCost(cost, detail)
            } finally {
              release()
            }
          })
          return reply({ ok: true, value: value ?? null })
        } catch (err) {
          return failure('gateway/internal', err instanceof Error ? err.message : String(err))
        }
      }
    },
  })
  return gate
}
