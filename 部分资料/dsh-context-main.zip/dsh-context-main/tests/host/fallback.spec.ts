import assert from 'node:assert/strict'
import { describe, test } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import SessionStore from '@deepseek-ai/dsh-session'
import type { Session } from '@deepseek-ai/dsh-session'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'
import { createFallbackActivityDefinition, createFallbackHeadersDefinition, createFallbackTimelineDefinition } from '../../src/host/fallback'
import { BASELINE_DSH_VERSION } from '../../src/shared/version'

const CURRENT = '0.2.0-rc.1'

async function boot() {
  const ctx = new Context()
  await ctx.plugin(SessionStore)
  await ctx.plugin(SessionProjectionRegistry)
  ctx.sessionProjections.register(createFallbackTimelineDefinition(CURRENT) as never)
  ctx.sessionProjections.register(createFallbackHeadersDefinition() as never)
  return ctx
}

function appendAnything(session: Session): void {
  session.append('request/header', {
    header: { config: { model: 'deepseek-v4-flash', provider: 'deepseek' } },
    reason: 'initial',
  })
  session.append('user/message', {
    content: [{ type: 'text', text: 'hi' }],
    source: { kind: 'user' },
  } as never, { surfaceOp: 'append' })
}

describe('fallback units over the real registry', () => {
  test('the gate value arrives through the snapshot cut regardless of the log', async () => {
    const ctx = await boot()
    const session = ctx.sessions.create()
    appendAnything(session)

    const timeline = ctx.sessionProjections.snapshot(session).values.contextTimeline
    assert.ok(timeline !== undefined)
    assert.equal(timeline.ok, true)
    assert.deepEqual(timeline.unsupported, { current: CURRENT, minimum: BASELINE_DSH_VERSION })
    assert.equal(timeline.current.total, 0, 'nothing is folded')
    assert.equal(timeline.requests.length, 0)
    assert.equal(timeline.nodes.length, 0)
    assert.equal(timeline.archive.length, 0)
    assert.equal(timeline.droppedNodes, 0)
    assert.equal(timeline.model, undefined)

    const headers = ctx.sessionProjections.snapshot(session).values.contextHeaders
    assert.ok(headers !== undefined)
    assert.deepEqual(headers.headers, [])
  })

  test('apply is a total identity over any event', () => {
    const timeline = createFallbackTimelineDefinition(CURRENT)
    const state = timeline.init()
    assert.deepEqual(state, {})
    assert.ok(timeline.apply(state, { type: 'user/message', seq: 1, time: 0, data: {} } as never) === state)
    assert.ok(timeline.apply(state, { type: 'bogus/event' } as never) === state, 'unknown event types pass through')
    const headers = createFallbackHeadersDefinition()
    assert.ok(headers.apply(state, { type: 'request/header', seq: 1, time: 0, data: null } as never) === state)
  })

  test('the state schema strips any cached row instead of rejecting it', () => {
    const timeline = createFallbackTimelineDefinition(CURRENT)
    assert.deepEqual(timeline.stateSchema.parse({ headers: [{ seq: 1 }] }), {})
    assert.deepEqual(timeline.stateSchema.parse({ surface: [null], sums: {} }), {})
    assert.equal(timeline.stateVersion, 1)
  })

  test('both registry contract generations read their shape off one definition, for every unit', () => {
    const timeline = createFallbackTimelineDefinition(CURRENT)
    assert.equal(timeline.schema.safeParse(timeline.view({})).success, true)
    assert.deepEqual(timeline.view({}).unsupported, { current: CURRENT, minimum: BASELINE_DSH_VERSION })
    const headers = createFallbackHeadersDefinition()
    assert.equal(headers.schema.safeParse(headers.view({})).success, true)
    assert.deepEqual(headers.view({}), { headers: [] })
    const activity = createFallbackActivityDefinition()
    assert.equal(activity.key, 'contextActivity')
    assert.equal(activity.stateVersion, 1)
    assert.deepEqual(activity.init(), {})
    const state = activity.init()
    assert.ok(activity.apply(state, { type: 'assistant/message', seq: 1, time: 0, data: {} } as never) === state)
    assert.equal(activity.wire.viewSchema.safeParse(activity.wire.view({})).success, true)
    assert.equal(activity.schema.safeParse(activity.view({})).success, true)
    assert.deepEqual(activity.view({}), { days: {} })
  })
})
