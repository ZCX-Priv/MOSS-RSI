import assert from 'node:assert/strict'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, test } from 'vitest'
import { Context, Service } from '@deepseek-ai/cordis'
import { UNKNOWN_TOOL_SOURCE } from '../../src/shared/types'
import { callerPackageFrom, createToolAttribution, packageNameFrom, type ToolAttribution } from '../../src/host/attribution'

const fileUrl = (file: string) => 'file:///' + file.replace(/\\/g, '/')

const specFile = path.normalize(fileURLToPath(import.meta.url))

const CORDIS_ORIGINAL = Symbol.for('cordis.original')

class TrackedTools extends Service {
  layers = { global: { tools: new Map() } }
  constructor(ctx: Context) { super(ctx, 'tools') }
  register(_definition?: { name?: unknown }) {
    return () => {}
  }
}

describe('createToolAttribution', () => {
  test('falls back to the static chain when nothing was registered at runtime, ignoring non-tools reads', async () => {
    const app = new Context()
    const attribution = createToolAttribution(app)
    assert.equal(attribution.ownerOf('read'), '@deepseek-ai/dsh-tool-fs')
    assert.equal(attribution.ownerOf('bash'), '@deepseek-ai/dsh-tool-bash', 'the pinned map serves boot-time first-party tools')
    assert.equal(attribution.ownerOf('mcp__github__get_issue'), 'mcp:github')
    assert.equal(attribution.ownerOf('unknown_tool'), undefined)
    app.provide('bench', { value: 1 })
    await app.plugin({
      name: 'probe',
      apply(sub) {
        void (sub as any).bench.value
        void (sub as any).bench.value
      },
    })
    assert.equal(attribution.ownerOf('grep'), '@deepseek-ai/dsh-tool-fs-search')
  })

  test('the static chain follows the detected line for the moved schedule tools', () => {
    assert.equal(createToolAttribution(new Context(), '0.2.0-rc.2').ownerOf('schedule_create'), '@deepseek-ai/dsh-schedule')
    const current = createToolAttribution(new Context(), '0.2.2-rc.1')
    assert.equal(current.ownerOf('schedule_create'), '@deepseek-ai/dsh-tool-schedule')
    assert.equal(current.ownerOf('schedule_view'), '@deepseek-ai/dsh-tool-schedule')
  })

  test('attributes tools to the plugin that read ctx.tools and registered them', async () => {
    const app = new Context()
    const attribution = createToolAttribution(app)
    const fake = { register() { return () => {} } }
    app.provide('tools', fake)
    let release: () => void = () => {}
    await app.plugin({
      name: 'provider-a',
      apply(sub) {
        const tools = (sub as any).tools
        assert.equal((sub as any).tools, fake, 'a wrapped instance is returned as-is')
        release = tools.register({ name: 'alpha' })
        tools.register({ name: 'beta' })
      },
    })
    assert.equal(attribution.ownerOf('alpha'), 'provider-a')
    assert.equal(attribution.ownerOf('beta'), 'provider-a')
    release()
    assert.equal(attribution.ownerOf('alpha'), undefined, 'the disposer forgets the tool')
    assert.equal(attribution.ownerOf('beta'), 'provider-a')
  })

  test('forwards registration options and keeps the disposer attribution', async () => {
    const app = new Context()
    const seen: unknown[][] = []
    let receiver: unknown
    const fake = {
      register(this: unknown, ...args: unknown[]) {
        receiver = this
        seen.push(args)
        return () => {}
      },
    }
    app.provide('tools', fake)
    const attribution = createToolAttribution(app)
    const when = () => true
    let release: (() => void) | undefined
    await app.plugin({
      name: 'gated-provider',
      apply(sub) {
        release = (sub as any).tools.register({ name: 'gated' }, { when })
      },
    })
    assert.deepEqual(seen, [[{ name: 'gated' }, { when }]], 'the definition and its registration options both reach the original')
    assert.equal(receiver, fake, 'the original register keeps its receiver')
    assert.equal(attribution.ownerOf('gated'), 'gated-provider')
    release?.()
    assert.equal(attribution.ownerOf('gated'), undefined, 'the forwarded call still returns the wrapped disposer')
  })

  test('falls back to the caller stack when no tools read happened', async () => {
    const app = new Context()
    const fake = { register() { return () => {} } }
    app.provide('tools', fake)
    const attribution = createToolAttribution(app)
    const { registerBlind } = await import('./fixtures/anon-plugin/index.js')
    const tools = app.get('tools', false) as { register(def?: unknown): () => void }
    const release = registerBlind(tools)
    assert.equal(attribution.ownerOf('blind_tool'), 'anon-plugin', 'no reader → the caller stack wins')
    release()
    assert.equal(attribution.ownerOf('blind_tool'), undefined, 'the disposer forgets the tool')
  })

  test('root and self reader slots fall back to the caller stack', async () => {
    const app = new Context()
    const fake = { register() { return () => {} } }
    app.provide('tools', fake)
    const { registerBlind } = await import('./fixtures/anon-plugin/index.js')
    let attribution!: ToolAttribution
    await app.plugin({
      name: 'dsh-context',
      inject: ['tools'],
      apply(sub) {
        attribution = createToolAttribution(sub)
        registerBlind((sub as any).tools)
      },
    })
    await app.plugin({
      apply(sub) {
        registerBlind((sub as any).tools)
      },
    })
    assert.equal(attribution.ownerOf('blind_tool'), 'anon-plugin', 'self/root slots are never taken as-is')
  })

  test('tolerates falsy, non-object, and register-less tools values', async () => {
    for (const value of [undefined, 42, { register: 42 }, {}]) {
      const app = new Context()
      const attribution = createToolAttribution(app)
      app.provide('tools', value)
      await app.plugin({
        name: 'probe',
        apply(sub) {
          void (sub as any).tools
        },
      })
      assert.equal(attribution.ownerOf('x'), undefined)
    }
  })

  test('a foreign wrapper carrying a garbage attribution marker is left untouched', async () => {
    const app = new Context()
    const attribution = createToolAttribution(app)
    const foreign = Object.assign(() => 'not-a-disposer', { attributedOriginal: 42 })
    const fake = { register: foreign }
    app.provide('tools', fake)
    await app.plugin({
      name: 'probe',
      apply(sub) {
        void (sub as any).tools
      },
    })
    assert.equal((app.get('tools', false) as typeof fake).register, foreign, 'the instance was not re-wrapped')
    assert.equal(attribution.ownerOf('whatever'), undefined)
  })

  test('ignores registrations without a string tool name or a disposer', async () => {
    const app = new Context()
    const attribution = createToolAttribution(app)
    app.provide('tools', { register() { return undefined } })
    await app.plugin({
      name: 'weird',
      apply(sub) {
        const tools = (sub as any).tools
        tools.register()
        tools.register({ name: 42 })
        tools.register({ name: 'sticky' })
      },
    })
    assert.equal(attribution.ownerOf('sticky'), 'weird', 'records even without a disposer')
    assert.equal(attribution.ownerOf('42'), undefined, 'non-string tool names are not recorded')
  })

  test('the live record outranks the pinned map; name-derived MCP labels outrank the live record', async () => {
    const app = new Context()
    const attribution = createToolAttribution(app)
    const fake = { register() { return () => {} } }
    app.provide('tools', fake)
    await app.plugin({
      name: 'third-party',
      apply(sub) {
        const tools = (sub as any).tools
        tools.register({ name: 'bash' })
        tools.register({ name: 'mcp__github__x' })
        tools.register({ name: 'brand_new_tool' })
      },
    })
    assert.equal(attribution.ownerOf('bash'), 'third-party', 'a post-boot registration is the truth, even under a first-party name')
    assert.equal(attribution.ownerOf('mcp__github__x'), 'mcp:github', 'the name-derived MCP label names the actual provider')
    assert.equal(attribution.ownerOf('brand_new_tool'), 'third-party', 'live record fills the gap')
  })

  test('re-installing or re-applying the hook re-wraps without stacking wrappers', async () => {
    const app = new Context()
    let calls = 0
    app.provide('tools', { register() { calls++; return () => {} } })
    createToolAttribution(app)
    const second = createToolAttribution(app)
    await app.plugin({
      name: 'provider-b',
      apply(sub) {
        ;((sub as any).tools as { register(def?: unknown): () => void }).register({ name: 'reload_tool' })
      },
    })
    assert.equal(calls, 1, 'the original register ran once, through one wrapper only')
    assert.equal(second.ownerOf('reload_tool'), 'provider-b', 'the fresh hook records the registration')

    const reapplied = new Context()
    let reCalls = 0
    reapplied.provide('tools', { register() { reCalls++; return () => {} } })
    let attribution!: ToolAttribution
    const plugged = reapplied.plugin({ name: 'dsh-context', apply(sub) { createToolAttribution(sub) } })
    await plugged
    await plugged.dispose()
    const replugged = reapplied.plugin({
      name: 'dsh-context',
      apply(sub) {
        attribution = createToolAttribution(sub)
      },
    })
    await replugged
    await reapplied.plugin({
      name: 'provider-d',
      apply(sub) {
        ;((sub as any).tools as { register(def?: unknown): () => void }).register({ name: 'reloaded_tool' })
      },
    })
    assert.equal(reCalls, 1, 'the original register ran once, through one wrapper only')
    assert.equal(attribution.ownerOf('reloaded_tool'), 'provider-d', 'the re-applied hook records the registration')
  })

  test('unload restores the original register; an older incarnation unload leaves a newer wrapper installed', async () => {
    const app = new Context()
    const fake = { register(_definition?: unknown) { return () => {} } }
    app.provide('tools', fake)
    const original = fake.register
    let attribution!: ToolAttribution
    const fiber = app.plugin({
      name: 'dsh-context',
      apply(sub) {
        attribution = createToolAttribution(sub)
      },
    })
    await fiber
    assert.notEqual(fake.register, original, 'the hook wrapped the instance at apply')
    await fiber.dispose()
    assert.equal(fake.register, original, 'unload put the original register back on the instance')
    fake.register({ name: 'orphan_tool' })
    assert.equal(attribution.ownerOf('orphan_tool'), undefined, 'no dead-hook recording after unload')

    const stacked = new Context()
    const stackedFake = { register() { return () => {} } }
    stacked.provide('tools', stackedFake)
    const stackedOriginal = stackedFake.register
    let second!: ToolAttribution
    const older = stacked.plugin({ name: 'older-hook', apply(sub) { createToolAttribution(sub) } })
    await older
    assert.notEqual(stackedFake.register, stackedOriginal, 'the first hook wrapped the instance')
    const newer = stacked.plugin({ name: 'newer-hook', apply(sub) { second = createToolAttribution(sub) } })
    await newer
    assert.notEqual(stackedFake.register, stackedOriginal, 'the newer incarnation re-wrapped the instance')
    await older.dispose()
    assert.notEqual(stackedFake.register, stackedOriginal, 'the older disposer did not strip the newer wrapper')
    await stacked.plugin({
      name: 'provider-c',
      apply(sub) {
        ;((sub as any).tools as { register(def?: unknown): () => void }).register({ name: 'late_tool' })
      },
    })
    assert.equal(second.ownerOf('late_tool'), 'provider-c', 'the surviving hook still records')
    await newer.dispose()
    assert.equal(stackedFake.register, stackedOriginal, 'the newer disposer restores the true original')
  })

  test('a tracked service is wrapped once on its stable identity and restored on unload', async () => {
    const app = new Context()
    const tools = new TrackedTools(app)
    const original = tools.register
    let attribution!: ToolAttribution
    const fiber = app.plugin({
      name: 'dsh-context',
      apply(sub) {
        attribution = createToolAttribution(sub)
      },
    })
    await fiber
    assert.notEqual(tools.register, original, 'the hook wrapped the tracked instance at apply')
    const wrappedOnce = tools.register
    await app.plugin({
      name: 'agent-scope',
      apply(sub) {
        const first = (sub as unknown as { tools: TrackedTools & Record<symbol, unknown> }).tools
        const second = (sub as unknown as { tools: TrackedTools & Record<symbol, unknown> }).tools
        assert.notEqual(first, second, 'cordis hands out a fresh traced proxy per read')
        assert.equal(first[CORDIS_ORIGINAL], tools, 'the proxy peels to the underlying service')
        assert.equal(second[CORDIS_ORIGINAL], tools)
        assert.equal(tools.register, wrappedOnce, 'repeated reads never re-wrap the stable instance')
        first.register({ name: 'scoped_tool' })
      },
    })
    assert.equal(attribution.ownerOf('scoped_tool'), 'agent-scope', 'the hook still attributes scoped registrations')
    await fiber.dispose()
    assert.equal(tools.register, original, 'unload restored the prototype register of the tracked service')
    const orphan = tools.register({ name: 'orphan_tool' })
    assert.equal(attribution.ownerOf('orphan_tool'), undefined, 'no dead-hook recording after unload')
    orphan()
  })

  test('tags boot-time tools whose providers predate the hook as unknown', () => {
    const app = new Context()
    const fake = {
      register() { return () => {} },
      layers: { global: { tools: { entries: () => [
        ['claim_files', {}],
        ['pending_write', {}],
        ['read', {}],
      ] } } },
    }
    app.provide('tools', fake)
    const attribution = createToolAttribution(app)
    assert.equal(attribution.ownerOf('claim_files'), UNKNOWN_TOOL_SOURCE, 'boot-only tools carry the unknown sentinel')
    assert.equal(attribution.ownerOf('pending_write'), UNKNOWN_TOOL_SOURCE)
    assert.equal(attribution.ownerOf('read'), '@deepseek-ai/dsh-tool-fs', 'the pinned map wins over the unknown tag')
    assert.equal(attribution.ownerOf('nope'), undefined, 'names outside the boot snapshot stay untagged')
  })

  test('a later runtime registration overrides the boot-time unknown tag', async () => {
    const app = new Context()
    const fake = {
      register() { return () => {} },
      layers: { global: { tools: { entries: () => [['claim_files', {}]] } } },
    }
    app.provide('tools', fake)
    const attribution = createToolAttribution(app)
    await app.plugin({
      name: 'claim-like',
      apply(sub) {
        ;((sub as any).tools as { register(def?: unknown): () => void }).register({ name: 'claim_files' })
      },
    })
    assert.equal(attribution.ownerOf('claim_files'), 'claim-like', 'a later live record beats the boot unknown tag')
  })

  test('tolerates tools values without an enumerable boot layer', () => {
    for (const tools of [
      undefined,
      { register() { return () => {} } },
      { register() { return () => {} }, layers: {} },
      { register() { return () => {} }, layers: { global: {} } },
      { register() { return () => {} }, layers: { global: { tools: {} } } },
      {
        register() { return () => {} },
        layers: { global: { tools: { entries() { throw new Error('boom') } } } },
      },
    ]) {
      const app = new Context()
      if (tools !== undefined) app.provide('tools', tools)
      const attribution = createToolAttribution(app)
      assert.equal(attribution.ownerOf('whatever'), undefined, 'no boot entries → no unknown tag')
    }
  })

  test('resolves root-named local-link plugins through the register call stack', async () => {
    const app = new Context()
    const attribution = createToolAttribution(app)
    const fake = { register() { return () => {} } }
    app.provide('tools', fake)
    const { registerTool } = await import('./fixtures/local-plugin/index.js')
    await app.plugin({
      apply(sub) {
        registerTool((sub as any).tools)
      },
    })
    assert.equal(attribution.ownerOf('local_tool'), 'local-plugin')
  })

  test('callerPackageFrom resolves the registering package from a stack', () => {
    const anon = path.normalize(fileURLToPath(new URL('./fixtures/anon-plugin/index.js', import.meta.url)))
    const local = path.normalize(fileURLToPath(new URL('./fixtures/local-plugin/index.js', import.meta.url)))
    assert.equal(callerPackageFrom(undefined), undefined)
    assert.equal(callerPackageFrom('no frames here'), undefined)
    assert.equal(callerPackageFrom(`Error\n  note\n  at ${local}:1:2`), 'local-plugin')
    assert.equal(callerPackageFrom('Error\n    at x (file:///D:/no-position.js)\n    at y (file:///D:/has-position.js:1:2)'), undefined)
    assert.equal(callerPackageFrom(`Error\n    at ${local}:1:2\n    at ${specFile}:3:4`), 'local-plugin')
    assert.equal(callerPackageFrom(`Error\n    at registerBlind (${fileUrl(anon)}:1:2)\n    at run (${fileUrl(specFile)}:3:4)`), 'anon-plugin')
    assert.equal(callerPackageFrom(`Error\n    at ${specFile}:1:2\n    at ${local}:3:4`), 'local-plugin')
    const attributionFile = path.normalize(fileURLToPath(new URL('../../src/host/attribution.ts', import.meta.url)))
    assert.equal(callerPackageFrom(`Error\n    at ${attributionFile}:1:2\n    at ${local}:3:4`), 'local-plugin')
    assert.equal(callerPackageFrom(`Error\n    at x (file:///D:/bad%zz.js:1:2)\n    at y (${fileUrl(local)}:3:4)`), 'local-plugin')
    assert.equal(callerPackageFrom(`Error\n    at ModuleJob.run (node:internal/modules/esm/module_job.js:346:20)\n    at y (${fileUrl(local)}:3:4)`), 'local-plugin')
    assert.equal(callerPackageFrom(`Error\n    at async fn (${fileUrl(anon)}:1:2)`), 'anon-plugin')
  })

  test('packageNameFrom walks up to the nearest readable package.json', () => {
    const local = fileURLToPath(new URL('./fixtures/local-plugin/index.js', import.meta.url))
    assert.equal(packageNameFrom(local), 'local-plugin')
    assert.equal(packageNameFrom(local), 'local-plugin', 'results are cached per directory')
    const malformed = fileURLToPath(new URL('./fixtures/bad-pkg/index.js', import.meta.url))
    assert.equal(packageNameFrom(malformed), 'dsh-context', 'a malformed package.json is skipped, the walk continues upward')
    const rootless = path.join(path.parse(process.cwd()).root, '__dsh_context_nonexistent__', 'file.js')
    assert.equal(packageNameFrom(rootless), undefined, 'no readable boundary up to the filesystem root')
    const deep = path.join(path.parse(process.cwd()).root, ...Array.from({ length: 13 }, (_, i) => `__dsh_ctx_l${i}__`), 'file.js')
    assert.equal(packageNameFrom(deep), undefined, 'the walk-depth cap returns undefined before reaching the root')
  })
})