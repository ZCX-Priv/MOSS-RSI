import assert from 'node:assert/strict'
import { describe, test } from 'vitest'
import { assemble, headerAt, systemAt } from '../../src/client/assemble'
import type { ContextHeaders, ContextTimeline, HeaderRecord } from '../../src/shared/types'
import { surfaceNodeAt } from './helpers/kit'

function epoch(seq: number): HeaderRecord {
  return { seq, time: 0, tools: [] }
}

function headers(...seqs: number[]): ContextHeaders {
  return { headers: seqs.map(epoch) }
}

function timeline(over: Partial<ContextTimeline> = {}): ContextTimeline {
  return {
    ok: true,
    current: { system: 0, tools: 0, user: 0, inject: 0, skill: 0, assistant: 0, tool: 0, total: 0 },
    requests: [],
    events: [],
    nodes: [],
    droppedNodes: 0,
    archive: [],
    ...over,
  }
}

describe('headerAt', () => {
  test('absent/empty headers or a seq at or before every epoch yield null; otherwise the newest epoch in force', () => {
    assert.equal(headerAt(null, 10), null)
    assert.equal(headerAt({ headers: [] }, 10), null)
    assert.equal(headerAt(headers(10, 20), 10), null)
    const h = headers(10, 20)
    assert.equal(headerAt(h, null), h.headers[1], 'a null seq picks the newest epoch')
    assert.equal(headerAt(h, 15), h.headers[0])
    assert.equal(headerAt(h, 25), h.headers[1])
  })
})

describe('assemble live view', () => {
  test('a null seq returns all live nodes for the next request, with the resolved system prompt; dropped nodes count as live', () => {
    const sys = { seq: 3, time: 300, tokens: 10 }
    const data = timeline({ nodes: [surfaceNodeAt(1), surfaceNodeAt(5)], systems: [sys] })
    const h = headers(10)
    const out = assemble(data, h, null)
    assert.equal(out.live, true)
    assert.deepEqual(out.nodes.map(n => n.seq), [1, 5])
    assert.notEqual(out.nodes, data.nodes)
    assert.equal(out.header, h.headers[0])
    assert.deepEqual(out.system, sys)
    assert.equal(out.missingLive, 0)
    assert.equal(out.approximate, false)
    const dropped = timeline({ nodes: [surfaceNodeAt(5)], droppedNodes: 3, surfaceFloor: 4 })
    assert.equal(assemble(dropped, null, null).missingLive, 3)
  })
})

describe('assemble past step', () => {
  test('the surface is live nodes before the step plus still-alive archive nodes in seq order, with the header in force', () => {
    const data = timeline({
      nodes: [surfaceNodeAt(1), surfaceNodeAt(3), surfaceNodeAt(8)],
      archive: [
        surfaceNodeAt(2, { gone: 10 }),
        surfaceNodeAt(4, { gone: 5 }),
        surfaceNodeAt(6),
        surfaceNodeAt(9, { gone: 12 }),
      ],
    })
    const h = headers(2, 10)
    const out = assemble(data, h, 7)
    assert.equal(out.live, false)
    assert.deepEqual(out.nodes.map(n => n.seq), [1, 2, 3])
    assert.equal(out.header, h.headers[0])
    assert.equal(assemble(timeline(), h, 1).header, null)
  })
})

describe('assemble missingLive for past steps', () => {
  test('a step after the surface floor contains every dropped live node; at/below it or without one flags nothing', () => {
    const data = timeline({ droppedNodes: 2, surfaceFloor: 5 })
    assert.equal(assemble(data, null, 6).missingLive, 2)
    assert.equal(assemble(data, null, 5).missingLive, 0)
    assert.equal(assemble(data, null, 3).missingLive, 0)
    assert.equal(assemble(timeline({ droppedNodes: 2 }), null, 6).missingLive, 0)
  })
})

describe('assemble approximate flag', () => {
  test('a step older than the archive floor is approximate; at/after it or without one is exact', () => {
    const data = timeline({ archiveFloor: 10 })
    assert.equal(assemble(data, null, 6).approximate, true)
    assert.equal(assemble(data, null, 10).approximate, false)
    assert.equal(assemble(timeline(), null, 6).approximate, false)
  })
})

describe('systemAt — the system prompt in force', () => {
  const sys = (seq: number, tokens: number, time = seq * 100) => ({ seq, time, tokens })

  test('the last nonempty live node wins; a step resolves the prompt logged before it; dormant-only lists yield none', () => {
    const data = timeline({ systems: [sys(3, 10), sys(8, 0), sys(12, 20)] })
    assert.deepEqual(systemAt(data, null, null), sys(12, 20))
    assert.deepEqual(systemAt(timeline({ systems: [sys(3, 10), sys(8, 0)] }), null, null), sys(3, 10))
    assert.deepEqual(systemAt(data, null, 12), sys(3, 10))
    assert.deepEqual(systemAt(data, null, 13), sys(12, 20))
    assert.equal(systemAt(data, null, 3), null, 'at the node itself the prompt is not yet in force')
    assert.equal(systemAt(timeline({ systems: [sys(3, 0)] }), null, null), null)

    const epoch: HeaderRecord = { seq: 15, time: 1500, systemTokens: 42, tools: [] }
    assert.deepEqual(systemAt(timeline(), epoch, null), { seq: 15, time: 1500, tokens: 42 })
    assert.deepEqual(systemAt(timeline({ systems: [] }), epoch, 20), { seq: 15, time: 1500, tokens: 42 })
    assert.equal(systemAt(timeline(), { seq: 15, time: 1500, tools: [] }, null), null, 'an epoch without a price yields none')
    assert.equal(systemAt(timeline(), null, null), null)
  })
})
