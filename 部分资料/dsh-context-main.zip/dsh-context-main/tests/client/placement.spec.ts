import assert from 'node:assert/strict'
import { describe, test } from 'vitest'
import { createContextSettings } from '../../src/client/settings'
import { watchPlacement } from '../../src/client/placement'

function mountSpy(): { factory: () => () => void; mounted: () => number; disposed: () => number } {
  let mountedCount = 0
  let disposedCount = 0
  return {
    factory: () => {
      mountedCount += 1
      return () => { disposedCount += 1 }
    },
    mounted: () => mountedCount,
    disposed: () => disposedCount,
  }
}

describe('watchPlacement', () => {
  test("the default 'all' mounts both; flips dispose only the dropped side and remount it on return, with no churn", () => {
    const settings = createContextSettings()
    const tab = mountSpy()
    const sidebar = mountSpy()
    const dispose = watchPlacement(settings, { tab: tab.factory, sidebar: sidebar.factory })
    assert.equal(tab.mounted(), 1)
    assert.equal(sidebar.mounted(), 1)

    settings.set('defaultPlacement', 'sidebar')
    assert.equal(tab.disposed(), 1, 'the dropped tab registration was disposed')
    assert.equal(tab.mounted(), 1, 'no remount churn')
    assert.equal(sidebar.disposed(), 0, 'the sidebar stays mounted')
    assert.equal(sidebar.mounted(), 1)

    settings.set('defaultPlacement', 'tab')
    assert.equal(sidebar.disposed(), 1)
    assert.equal(sidebar.mounted(), 1)
    assert.equal(tab.mounted(), 2, 'the tab comes back')
    assert.equal(tab.disposed(), 1)
    dispose()
  })

  test("'hide' unwinds both without remount churn; 'all' restores both; unrelated preference changes never remount", () => {
    const settings = createContextSettings()
    const tab = mountSpy()
    const sidebar = mountSpy()
    const dispose = watchPlacement(settings, { tab: tab.factory, sidebar: sidebar.factory })

    settings.set('defaultGranularity', 'turn')
    assert.equal(tab.mounted(), 1)
    assert.equal(sidebar.mounted(), 1)

    settings.set('defaultPlacement', 'hide')
    assert.equal(tab.disposed(), 1)
    assert.equal(sidebar.disposed(), 1)
    settings.set('defaultPlacement', 'hide')
    assert.equal(tab.mounted(), 1, 'a hidden panel entry never churns')
    assert.equal(sidebar.mounted(), 1)

    settings.set('defaultPlacement', 'all')
    assert.equal(tab.mounted(), 2)
    assert.equal(sidebar.mounted(), 2)
    settings.set('defaultPlacement', 'tab')
    settings.set('defaultPlacement', 'all')
    assert.equal(tab.mounted(), 2, 'the kept side is never churned')
    assert.equal(sidebar.mounted(), 3, 'the dropped side remounts once')
    assert.equal(sidebar.disposed(), 2)
    dispose()
    assert.equal(tab.disposed(), 2)
    assert.equal(sidebar.disposed(), 3)
  })

  test("a 'tab'-only or 'sidebar'-only start mounts just that side", () => {
    const settings = createContextSettings()
    settings.set('defaultPlacement', 'tab')
    const tab = mountSpy()
    const sidebar = mountSpy()
    const dispose = watchPlacement(settings, { tab: tab.factory, sidebar: sidebar.factory })
    assert.equal(tab.mounted(), 1)
    assert.equal(sidebar.mounted(), 0)
    dispose()
    assert.equal(tab.disposed(), 1)
    assert.equal(sidebar.disposed(), 0)

    const again = createContextSettings()
    again.set('defaultPlacement', 'sidebar')
    const tab2 = mountSpy()
    const sidebar2 = mountSpy()
    const dispose2 = watchPlacement(again, { tab: tab2.factory, sidebar: sidebar2.factory })
    assert.equal(tab2.mounted(), 0)
    assert.equal(sidebar2.mounted(), 1)
    dispose2()
  })

  test('the watcher disposer unwinds every mount and detaches the store', () => {
    const settings = createContextSettings()
    const tab = mountSpy()
    const sidebar = mountSpy()
    const dispose = watchPlacement(settings, { tab: tab.factory, sidebar: sidebar.factory })
    dispose()
    assert.equal(tab.disposed(), 1)
    assert.equal(sidebar.disposed(), 1)
    settings.set('defaultPlacement', 'sidebar')
    assert.equal(tab.mounted(), 1)
    assert.equal(sidebar.mounted(), 1)
    assert.doesNotThrow(dispose)
    assert.equal(tab.disposed(), 1, 'no double unwind')
  })

  test('a disposerless mount is tolerated and still counted as mounted — later publishes never register a second copy', () => {
    const settings = createContextSettings()
    const dispose = watchPlacement(settings, {
      tab: () => undefined,
      sidebar: () => undefined,
    })
    assert.doesNotThrow(() => { settings.set('defaultPlacement', 'tab') })
    assert.doesNotThrow(() => { dispose() })

    const counted = createContextSettings()
    let tabs = 0
    let sidebars = 0
    watchPlacement(counted, {
      tab: () => { tabs += 1; return undefined },
      sidebar: () => { sidebars += 1; return undefined },
    })
    assert.equal(tabs, 1)
    assert.equal(sidebars, 1)
    counted.set('defaultGranularity', 'turn')
    counted.set('defaultPlacement', 'tab')
    assert.equal(tabs, 1, 'the tab is never mounted twice')
    assert.equal(sidebars, 1, 'the sidebar unwound once and does not come back on its own')
    counted.set('defaultPlacement', 'all')
    assert.equal(tabs, 1)
    assert.equal(sidebars, 2)
  })
})
