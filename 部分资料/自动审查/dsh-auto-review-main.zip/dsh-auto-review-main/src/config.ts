/**
 * Config schema and resolution for `dsh-auto-review`. Every tunable is a
 * validated {@link Config} field changeable from cordis.yml; the resolution
 * step compiles risk-rule regexes and fails loud on invalid input.
 * @module dsh-auto-review/config
 */

import z from '@deepseek-ai/schemastery'
import type { UiLanguage } from './messages.ts'

/**
 * What one approval request does at the auto-review answerer:
 *
 * - `'ai'` — the AI reviewer decides (allow/deny) and the request never
 *   reaches a human answerer.
 * - `'human'` — the request is delegated (`next()`) to the human answerer;
 *   auto-review does not short-circuit the chain.
 * - `'never'` — the answerer rejects deterministically. Only for tools an
 *   admin wants hard-disabled whenever approval is required.
 */
export type ToolReviewPolicy = 'ai' | 'human' | 'never'

/** Risk levels the reviewer may attach to a verdict. */
export type RiskLevel = 'low' | 'medium' | 'high'

/**
 * Which engine answers an `ai`-policy review:
 *
 * - `'agent'` — the generative reviewer (an isolated read-only child, or a
 *   tool-less `llm` call on hosts that dropped `subagents.start`).
 * - `'phocinae'` — the local non-generative Phocinae decision service
 *   (`POST /v1/systemone`). It answers one typed question per review and never
 *   generates text, so it needs no API key, no subagent seam and no `llm`
 *   service: an offline, deterministic, millisecond-scale reviewer.
 *
 * Unset resolves from {@link Config.reviewerModel}: a model name starting with
 * `Phocinae` selects `'phocinae'`, anything else keeps `'agent'`. That makes
 * `reviewerModel: Phocinae-Largha-150M-v1` work without a second knob.
 */
export type ReviewerBackend = 'agent' | 'phocinae'

/**
 * The local Phocinae decision service (`phocinae-server`, model
 * `Phocinae-Largha-150M-v1`). The model answers typed decisions — boolean,
 * option index, 2..10 level — and never emits tokens, so a review costs one
 * forward pass instead of a generation. The endpoint and model defaults match
 * the sibling `dsh-phocinae` plugin so one running server serves both; the
 * confidence floor is this plugin's own, measured on commands.
 */
export interface PhocinaeConfig {
  /** Decision-service URL. Loopback only unless {@link allowRemoteEndpoint}. */
  endpoint?: string
  /** Served model name; the server answers 422 for any other value. */
  model?: string
  /**
   * Per-request HTTP timeout in milliseconds. One attempt, no retry: a retry
   * would multiply the reviewer's already-dominant latency on this path.
   */
  timeoutMs?: number
  /**
   * Calibrated-confidence floor for an `allow` answer. A `deny` always stands;
   * an allow below this floor is NOT a verdict and resolves through
   * `fallbackPolicy` (default fail-closed rejection).
   *
   * The default 0.45 is measured, not conventional: on the versioned
   * 97-command set the released weights allowed 0 of 61 destructive commands
   * at 0.45; at 0.4 two system-file commands passed (`cat /etc/shadow`,
   * `cp /dev/null /etc/passwd`, confidences 0.4036 and 0.4265). The path and
   * operator guards are the second line of defence. Lowering the floor is a
   * safety change, not a tuning tweak.
   */
  minConfidence?: number
  /** Cap on the rendered decision state, in characters (head is kept). */
  maxStateChars?: number
  /**
   * Permit a non-loopback {@link endpoint}. Default `false`: the decision state
   * carries the reviewed tool call's text, so a remote endpoint would be an
   * egress decision this plugin must not make silently.
   */
  allowRemoteEndpoint?: boolean
}

/** The published model id served by `phocinae-server`. */
export const PHOCINAE_DEFAULT_MODEL = 'Phocinae-Largha-150M-v1'

/** The sibling plugin's default endpoint: `phocinae-server` on loopback port 8155. */
export const PHOCINAE_DEFAULT_ENDPOINT = 'http://127.0.0.1:8155/v1/systemone'

/** One CPU forward pass is ~1.5 s single-threaded; 5 s is a full-request budget. */
export const PHOCINAE_DEFAULT_TIMEOUT_MS = 5000

/** The confidence floor an allow must reach; see {@link PhocinaeConfig.minConfidence}. */
export const PHOCINAE_DEFAULT_MIN_CONFIDENCE = 0.45

/** State cap shared with the sibling plugin's tool-call renderer. */
export const PHOCINAE_DEFAULT_MAX_STATE_CHARS = 4096

/** Hosts treated as loopback: the decision service is a local process by design. */
const LOOPBACK_HOSTS: ReadonlySet<string> = new Set(['127.0.0.1', 'localhost', '::1', '[::1]'])

/**
 * Whether a reviewer model id names the Phocinae decision model. Used only to
 * infer the backend when `reviewerBackend` is unset: `Phocinae-…`,
 * `phocinae:…` and a bare `phocinae` all select the local service.
 * @param model - the configured `reviewerModel`, if any.
 * @returns true when the name belongs to the Phocinae family.
 */
export function isPhocinaeModelName(model: string | undefined): boolean {
  return typeof model === 'string' && /^phocinae(?:[-_/ :]|$)/iu.test(model.trim())
}

/** The risk-level ordering, low first — the comparison base of {@link RiskPolicyConfig}. */
export const RISK_ORDER: readonly RiskLevel[] = ['low', 'medium', 'high']

/** What a risk-rule pattern is matched against. */
export type RiskRuleField = 'reason' | 'toolName' | 'arguments'

/**
 * What happens when the reviewer cannot deliver a verdict (crash, timeout,
 * subagent unavailable, schema mismatch):
 *
 * - `'rejected'` — fail closed; the request is denied (the default).
 * - `'delegate'` — the request is passed down the answerer chain (a human
 *   answerer, when one is composed).
 * - `'allow-once'` — the request is granted once. Deliberately dangerous:
 *   the grant is unconditional, not "readonly" in any enforced sense; it
 *   exists for unattended deployments whose admin accepts that risk. Renamed
 *   from `allow-readonly` in 0.2.0 for honesty; the old spelling is rejected
 *   loudly.
 */
export type FallbackPolicy = 'rejected' | 'delegate' | 'allow-once'

/**
 * How much of the session transcript the reviewer receives as compact
 * context (the calling session's recent user/assistant messages and tool
 * results, redacted and truncated). `turns: 0` disables the section.
 *
 * The default is {@link DEFAULT_CONTEXT_TURNS}, not 0: without a transcript
 * the reviewer never sees the user's request, so the only evidence for a
 * user-authorized action is the calling agent's own self-report — and the
 * verdict rules say to DENY when the evidence is insufficient. A blind
 * reviewer therefore denies every user-authorized escalation, which is
 * indistinguishable from a broken plugin.
 */
export interface ContextBudgetConfig {
  /** How many completed turns (plus the current one) of transcript to include; 0 disables. */
  readonly turns: number
  /** Character cap applied to the whole context section, spent newest-line first. */
  readonly maxChars: number
}

/**
 * Default {@link ContextBudgetConfig.turns}: the open turn (which carries the
 * pending call and, usually, the request that authorized it) plus the one
 * before it, which is where an authorization stated a moment earlier lives.
 * One turn is the bare minimum and leaves no slack; a larger window costs
 * prompt tokens and widens what a non-default `reviewerModel` is shown, and
 * `maxChars` bounds it either way.
 */
export const DEFAULT_CONTEXT_TURNS = 2

/** What a tripped rejection circuit breaker does to later ai-policy requests in the turn. */
export type CircuitAction = 'delegate' | 'reject' | 'abort-turn'

/**
 * The rejection circuit breaker: after a run of denials the turn stops
 * asking the reviewer. Trips on {@link consecutiveDenies} consecutive deny
 * verdicts in the turn OR {@link windowDenies} denials inside the last
 * {@link windowSize} verdicts of the turn, whichever comes first.
 */
export interface CircuitBreakerConfig {
  /** Consecutive deny verdicts in one turn that trip the breaker. */
  readonly consecutiveDenies: number
  /** Deny count inside the window that trips the breaker. */
  readonly windowDenies: number
  /** How many recent verdicts the window counts. */
  readonly windowSize: number
  /** What later requests in the turn do once tripped. */
  readonly action: CircuitAction
}

/**
 * How the reviewer's verdict risk level constrains the outcome: an `allow`
 * verdict whose risk exceeds {@link maxAutoAllow} never settles the request
 * — it delegates to the human chain (or denies) per {@link onHighRisk}.
 */
export interface RiskPolicyConfig {
  /** The highest risk level an allow verdict may settle with. */
  readonly maxAutoAllow: RiskLevel
  /** What happens to an allow verdict above the cap. */
  readonly onHighRisk: 'delegate' | 'deny'
}

/** One risk rule: a regex matched against the request reason, tool name, or redacted call arguments. */
export interface RiskRuleConfig {
  /** Regular expression source (compiled without flags). */
  pattern: string
  /** The policy a matching request resolves to. */
  policy: ToolReviewPolicy
  /** What the pattern is matched against. Default `'reason'`; `'arguments'` matches the redacted presented call arguments. */
  field?: RiskRuleField
}

/** Per-tool policy table: explicit overrides, then a default for unlisted tools. */
export interface ToolsPolicyConfig {
  /** Policy for tools not named in {@link overrides}. Default `'human'` (delegate). */
  default: ToolReviewPolicy
  /** Exact tool-name → policy mapping. */
  overrides: Record<string, ToolReviewPolicy>
}

/** Raw plugin config — every field optional; {@link Config} supplies the defaults. */
export interface Config {
  /**
   * Whether sessions start with auto-review enabled. The `/auto-review`
   * command writes a durable per-session override that beats this default.
   */
  enableByDefault?: boolean
  /** Tool policy table (defaults + per-tool overrides). */
  toolsPolicy?: Partial<ToolsPolicyConfig>
  /** Risk rules matched (first match wins) against the request reason before the tool table. */
  riskRules?: RiskRuleConfig[]
  /** Subagent provider name for the reviewer (default `fork`, the in-process fork backend). */
  reviewerProvider?: string
  /** Reviewer Agent Preset id; required when the host only exposes startActivation. */
  reviewerPreset?: string
  /** Reviewer model id; when unset the reviewer inherits the session agent's route. */
  reviewerModel?: string
  /** LLM provider route for {@link reviewerModel}; unset inherits the session agent's provider. */
  reviewerModelProvider?: string
  /**
   * Which engine answers an `ai`-policy review (see {@link ReviewerBackend}).
   * Unset infers from {@link reviewerModel}: a `Phocinae…` name selects the
   * local decision service, everything else keeps the generative reviewer.
   */
  reviewerBackend?: ReviewerBackend
  /**
   * Local Phocinae decision-service settings
   * (see {@link PhocinaeConfig}). Relevant only when the resolved backend is
   * `'phocinae'`; the defaults match the sibling `dsh-phocinae` plugin.
   */
  phocinae?: Partial<PhocinaeConfig>
  /** Verdict deadline in milliseconds. Default 60000. */
  reviewerTimeoutMs?: number
  /**
   * The reviewer's tool allow-list — read-only tools by default. The subagent
   * `toolFilter` is an allow-list: anything not named here is invisible to
   * and unexecutable by the reviewer child. Must be non-empty.
   */
  reviewerTools?: string[]
  /** Reviewer failure policy (see {@link FallbackPolicy}). Default `'rejected'`. */
  fallbackPolicy?: FallbackPolicy
  /** Maximum real AI verdicts per open turn; further requests delegate to humans. */
  maxReviewsPerTurn?: number
  /**
   * Maximum reviewer failures (timeout/unavailable/schema — not user
   * cancellations) per open turn; beyond it, further requests delegate
   * instead of paying another full timeout. Defaults to
   * {@link maxReviewsPerTurn}.
   */
  maxFailuresPerTurn?: number
  /** Cap applied to reviewer reasons, the request reason, and the redacted argument preview before they enter prompts or logs. */
  reasonMaxChars?: number
  /** Optional extra guidance appended to the reviewer prompt (advisory, not a hard rule). */
  reviewerGuidance?: string
  /**
   * Optional policy text injected into the reviewer prompt as the ruling
   * policy (Markdown: always-deny / always-allow / require-justification
   * sections), like Codex `auto_review.policy`. A template ships at
   * `fixtures/config/policy-template.md`.
   */
  reviewerPolicyText?: string
  /** Guidance appended to every injected deny reason (anti-circumvention). */
  denyGuidance?: string
  /** Compact transcript budget for the reviewer prompt (see {@link ContextBudgetConfig}). */
  contextBudget?: Partial<ContextBudgetConfig>
  /** Verdict risk-level constraints (see {@link RiskPolicyConfig}). */
  riskPolicy?: Partial<RiskPolicyConfig>
  /** The rejection circuit breaker (see {@link CircuitBreakerConfig}). */
  circuitBreaker?: Partial<CircuitBreakerConfig>
  /** How long a `/auto-review approve` override stays usable, in milliseconds. Default 5 minutes. */
  overrideTtlMs?: number
  /**
   * How long an identical `tool + arguments` fingerprint reuses its last
   * verdict before the second model is consulted again, in milliseconds.
   * `0` disables the cache. Default 60000.
   */
  verdictCacheTtlMs?: number
  /** Hard cap on cached verdict fingerprints; the oldest entry is evicted beyond it. Default 256. */
  verdictCacheMaxEntries?: number
  /** UI language of the `/auto-review` command output (`en` | `zh`). Default `'en'`. */
  language?: UiLanguage
  /**
   * Force session-log audit even though the host cannot write the `ignorable`
   * envelope marker. Deliberately dangerous, and NOT a compatibility
   * workaround: no published `Session.append` can stamp the marker (verified
   * 2026-09-12 against the host source, every relevant published tarball, and
   * a live append on the `0.1.5-rc.2` line), so enabling this writes unmarked
   * `autoReview/*` events — and the persistence read path refuses unknown
   * unmarked types, which makes those sessions unloadable on every validating
   * harness. Default `false`: the runtime detects the host and degrades to an
   * in-memory audit mirror instead. If you enabled it and sessions stopped
   * loading, repair them with `scripts/repair-session-logs.mjs` from
   * `dsh-permission-rules`.
   */
  allowUnmarkedAudit?: boolean
}

/** Config after {@link resolveConfig}: every optional field has its explicit default. */
export interface ResolvedConfig {
  readonly enableByDefault: boolean
  readonly toolsPolicy: ToolsPolicyConfig
  readonly riskRules: readonly ResolvedRiskRule[]
  readonly reviewerProvider: string
  readonly reviewerPreset?: string | undefined
  readonly reviewerModel: string | undefined
  readonly reviewerModelProvider: string | undefined
  /** The resolved reviewer engine (see {@link ReviewerBackend}). */
  readonly reviewerBackend: ReviewerBackend
  /** The resolved Phocinae settings; relevant only when {@link reviewerBackend} is `'phocinae'`. */
  readonly phocinae: ResolvedPhocinaeConfig
  readonly reviewerTimeoutMs: number
  readonly reviewerTools: readonly string[]
  readonly fallbackPolicy: FallbackPolicy
  readonly maxReviewsPerTurn: number
  readonly maxFailuresPerTurn: number
  readonly reasonMaxChars: number
  readonly reviewerGuidance: string | undefined
  readonly reviewerPolicyText: string | undefined
  readonly denyGuidance: string
  readonly contextBudget: ContextBudgetConfig
  readonly riskPolicy: RiskPolicyConfig
  readonly circuitBreaker: CircuitBreakerConfig
  readonly overrideTtlMs: number
  readonly verdictCacheTtlMs: number
  readonly verdictCacheMaxEntries: number
  readonly language: UiLanguage
  readonly allowUnmarkedAudit: boolean
}

/** A compiled {@link RiskRuleConfig}, ready to test against its configured field. */
export interface ResolvedRiskRule {
  /** The original pattern source, kept for prompts and audit. */
  readonly pattern: string
  readonly regex: RegExp
  readonly policy: ToolReviewPolicy
  readonly field: RiskRuleField
}

/** A {@link PhocinaeConfig} with every default applied. */
export interface ResolvedPhocinaeConfig {
  readonly endpoint: string
  readonly model: string
  readonly timeoutMs: number
  readonly minConfidence: number
  readonly maxStateChars: number
  readonly allowRemoteEndpoint: boolean
}

const POLICY = z.union(['ai', 'human', 'never'] as const)
const FALLBACK = z.union(['rejected', 'delegate', 'allow-once'] as const)
const RISK = z.union(['low', 'medium', 'high'] as const)
const FIELD = z.union(['reason', 'toolName', 'arguments'] as const)
const CIRCUIT_ACTION = z.union(['delegate', 'reject', 'abort-turn'] as const)
const REVIEWER_BACKEND = z.union(['agent', 'phocinae'] as const)

/** Default anti-circumvention guidance appended to every injected deny reason. */
export const DEFAULT_DENY_GUIDANCE = 'Do not attempt to work around this denial. '
  + 'Choose a materially safer alternative that stays inside your permissions, or ask the user before retrying this action.'

/** Schemastery schema: the loader validates and fills defaults before `apply`. */
export const Config: z<Config> = z.object({
  enableByDefault: z.boolean().default(true),
  toolsPolicy: z.object({
    default: POLICY.default('human'),
    overrides: z.dict(POLICY).default({}),
  }).default({ default: 'human', overrides: {} }),
  riskRules: z.array(z.object({
    pattern: z.string(),
    policy: POLICY,
    field: FIELD.default('reason'),
  })).default([]),
  reviewerProvider: z.string().default('fork'),
  reviewerPreset: z.string(),
  reviewerModel: z.string(),
  reviewerModelProvider: z.string(),
  reviewerBackend: REVIEWER_BACKEND,
  phocinae: z.object({
    endpoint: z.string(),
    model: z.string(),
    timeoutMs: z.number(),
    minConfidence: z.number(),
    maxStateChars: z.number(),
    allowRemoteEndpoint: z.boolean(),
  }),
  reviewerTimeoutMs: z.number().default(60_000),
  reviewerTools: z.array(z.string()).default(['read', 'glob', 'grep']),
  fallbackPolicy: FALLBACK.default('rejected'),
  maxReviewsPerTurn: z.number().default(10),
  maxFailuresPerTurn: z.number(),
  reasonMaxChars: z.number().default(2000),
  reviewerGuidance: z.string(),
  reviewerPolicyText: z.string(),
  denyGuidance: z.string().default(DEFAULT_DENY_GUIDANCE),
  contextBudget: z.object({
    turns: z.number().default(DEFAULT_CONTEXT_TURNS),
    maxChars: z.number().default(4000),
  }).default({ turns: DEFAULT_CONTEXT_TURNS, maxChars: 4000 }),
  riskPolicy: z.object({
    maxAutoAllow: RISK.default('high'),
    onHighRisk: z.union(['delegate', 'deny'] as const).default('delegate'),
  }).default({ maxAutoAllow: 'high', onHighRisk: 'delegate' }),
  circuitBreaker: z.object({
    consecutiveDenies: z.number().default(3),
    // The window defaults must stay reachable under the default
    // maxReviewsPerTurn (10): a window trip needs 6 denies inside the turn's
    // at most 10 verdicts, so interleaved denials trip it even when no
    // 3-deny run occurs (a 10-in-50 default could never trip first).
    windowDenies: z.number().default(6),
    windowSize: z.number().default(10),
    action: CIRCUIT_ACTION.default('delegate'),
  }).default({ consecutiveDenies: 3, windowDenies: 6, windowSize: 10, action: 'delegate' }),
  overrideTtlMs: z.number().default(5 * 60_000),
  verdictCacheTtlMs: z.number().default(60_000),
  verdictCacheMaxEntries: z.number().default(256),
  language: z.union(['en', 'zh'] as const).default('en'),
  allowUnmarkedAudit: z.boolean().default(false),
})

/**
 * Whether any resolved policy can route a request to the AI reviewer — the
 * table default, one per-tool override, or one risk rule. Combined with
 * `contextBudget.turns: 0` this is the deny-everything configuration the
 * runtime warns about at mount time.
 * @param config - the resolved config.
 * @returns true when at least one policy is `ai`.
 */
export function hasAiPolicy(config: ResolvedConfig): boolean {
  if (config.toolsPolicy.default === 'ai') return true
  if (Object.values(config.toolsPolicy.overrides).includes('ai')) return true
  return config.riskRules.some(rule => rule.policy === 'ai')
}

/** Whether `level` ranks strictly above `cap` in {@link RISK_ORDER}. */
export function riskExceeds(level: RiskLevel, cap: RiskLevel): boolean {
  return RISK_ORDER.indexOf(level) > RISK_ORDER.indexOf(cap)
}

/**
 * Validate and complete the Phocinae decision-service settings. Every illegal
 * value throws here, at load time: a security-relevant reviewer must not
 * degrade silently at run time (a bad endpoint would otherwise read as
 * "service unavailable", which is safe but indistinguishable from a killed
 * server, and a negative timeout would disarm the deadline).
 * @param raw - partial `phocinae` config.
 * @param reviewerModel - `reviewerModel`, so a Phocinae model id selects the
 *   served model name without repeating it under `phocinae.model`.
 * @returns the resolved settings.
 */
export function resolvePhocinaeConfig(
  raw: Partial<PhocinaeConfig> | undefined,
  reviewerModel?: string,
): ResolvedPhocinaeConfig {
  if (raw !== undefined && (typeof raw !== 'object' || raw === null || Array.isArray(raw))) {
    throw new TypeError(`phocinae must be an object, got ${JSON.stringify(raw)}`)
  }
  const allowRemoteEndpoint = raw?.allowRemoteEndpoint ?? false
  if (typeof allowRemoteEndpoint !== 'boolean') {
    throw new TypeError(`phocinae.allowRemoteEndpoint must be a boolean, got ${JSON.stringify(raw?.allowRemoteEndpoint)}`)
  }
  const rawEndpoint = raw?.endpoint ?? PHOCINAE_DEFAULT_ENDPOINT
  if (typeof rawEndpoint !== 'string' || rawEndpoint.trim() === '') {
    throw new TypeError(`phocinae.endpoint must be a non-empty URL string, got ${JSON.stringify(raw?.endpoint)}`)
  }
  let url: URL
  try {
    url = new URL(rawEndpoint)
  } catch {
    throw new TypeError(`phocinae.endpoint must be an absolute URL, got ${JSON.stringify(rawEndpoint)}`)
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new TypeError(`phocinae.endpoint must use http or https, got ${JSON.stringify(url.protocol)}`)
  }
  // Credentials in the URL would be echoed by every transport error and would
  // not be a supported authentication mechanism (the client sends no
  // Authorization header). Refuse them rather than risk logging a secret.
  if (url.username !== '' || url.password !== '') {
    throw new TypeError('phocinae.endpoint must not embed credentials; the decision client sends no Authorization header')
  }
  if (!allowRemoteEndpoint && !LOOPBACK_HOSTS.has(url.hostname)) {
    throw new TypeError(
      `phocinae.endpoint host ${JSON.stringify(url.hostname)} is not loopback. The decision state carries the `
      + 'reviewed tool call\'s text, so a remote endpoint would leak it; set phocinae.allowRemoteEndpoint: true '
      + 'if that egress is intended.',
    )
  }
  const rawModel = raw?.model ?? (isPhocinaeModelName(reviewerModel) ? reviewerModel?.trim() : undefined)
  const model = rawModel ?? PHOCINAE_DEFAULT_MODEL
  if (typeof model !== 'string' || model.trim() === '') {
    throw new TypeError(`phocinae.model must be a non-empty string, got ${JSON.stringify(raw?.model)}`)
  }
  const timeoutMs = raw?.timeoutMs ?? PHOCINAE_DEFAULT_TIMEOUT_MS
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0) {
    throw new TypeError(`phocinae.timeoutMs must be a positive safe integer, got ${String(raw?.timeoutMs)}`)
  }
  const minConfidence = raw?.minConfidence ?? PHOCINAE_DEFAULT_MIN_CONFIDENCE
  if (typeof minConfidence !== 'number' || !Number.isFinite(minConfidence) || minConfidence < 0 || minConfidence > 1) {
    throw new TypeError(`phocinae.minConfidence must be a number in [0, 1], got ${JSON.stringify(raw?.minConfidence)}`)
  }
  const maxStateChars = raw?.maxStateChars ?? PHOCINAE_DEFAULT_MAX_STATE_CHARS
  if (!Number.isSafeInteger(maxStateChars) || maxStateChars <= 0) {
    throw new TypeError(`phocinae.maxStateChars must be a positive safe integer, got ${String(raw?.maxStateChars)}`)
  }
  return {
    endpoint: url.toString(),
    model,
    timeoutMs,
    minConfidence,
    maxStateChars,
    allowRemoteEndpoint,
  }
}

/**
 * Validate raw values and compile the resolved config. Defaults are applied
 * HERE — the explicit resolution step — so a partially-specified config from
 * a direct `ctx.plugin` mount behaves like the loader-filled one.
 * @param config - raw (possibly partial) plugin config.
 * @returns the fully resolved config.
 * @throws TypeError on invalid risk-rule regexes, non-positive budgets, or
 *   out-of-range numbers (misconfiguration fails loud).
 */
export function resolveConfig(config: Config = {}): ResolvedConfig {
  if (!Number.isSafeInteger(config.reviewerTimeoutMs ?? 60_000) || (config.reviewerTimeoutMs ?? 60_000) <= 0) {
    throw new TypeError(`reviewerTimeoutMs must be a positive safe integer, got ${String(config.reviewerTimeoutMs)}`)
  }
  if (!Number.isSafeInteger(config.maxReviewsPerTurn ?? 10) || (config.maxReviewsPerTurn ?? 10) <= 0) {
    throw new TypeError(`maxReviewsPerTurn must be a positive safe integer, got ${String(config.maxReviewsPerTurn)}`)
  }
  if (!Number.isSafeInteger(config.maxFailuresPerTurn ?? 10) || (config.maxFailuresPerTurn ?? 10) <= 0) {
    throw new TypeError(`maxFailuresPerTurn must be a positive safe integer, got ${String(config.maxFailuresPerTurn)}`)
  }
  if (!Number.isSafeInteger(config.reasonMaxChars ?? 2000) || (config.reasonMaxChars ?? 2000) <= 0) {
    throw new TypeError(`reasonMaxChars must be a positive safe integer, got ${String(config.reasonMaxChars)}`)
  }
  const turns = config.contextBudget?.turns ?? DEFAULT_CONTEXT_TURNS
  if (!Number.isSafeInteger(turns) || turns < 0) {
    throw new TypeError(`contextBudget.turns must be a non-negative safe integer, got ${String(turns)}`)
  }
  const contextChars = config.contextBudget?.maxChars ?? 4000
  if (!Number.isSafeInteger(contextChars) || contextChars <= 0) {
    throw new TypeError(`contextBudget.maxChars must be a positive safe integer, got ${String(contextChars)}`)
  }
  const breaker = config.circuitBreaker ?? {}
  for (const [key, value] of [['consecutiveDenies', breaker.consecutiveDenies ?? 3], ['windowDenies', breaker.windowDenies ?? 6], ['windowSize', breaker.windowSize ?? 10]] as const) {
    if (!Number.isSafeInteger(value) || value <= 0) {
      throw new TypeError(`circuitBreaker.${key} must be a positive safe integer, got ${String(value)}`)
    }
  }
  if (!Number.isSafeInteger(config.overrideTtlMs ?? 5 * 60_000) || (config.overrideTtlMs ?? 5 * 60_000) <= 0) {
    throw new TypeError(`overrideTtlMs must be a positive safe integer, got ${String(config.overrideTtlMs)}`)
  }
  if (!Number.isSafeInteger(config.verdictCacheTtlMs ?? 60_000) || (config.verdictCacheTtlMs ?? 60_000) < 0) {
    throw new TypeError(`verdictCacheTtlMs must be a non-negative safe integer (0 disables the cache), got ${String(config.verdictCacheTtlMs)}`)
  }
  if (!Number.isSafeInteger(config.verdictCacheMaxEntries ?? 256) || (config.verdictCacheMaxEntries ?? 256) <= 0) {
    throw new TypeError(`verdictCacheMaxEntries must be a positive safe integer, got ${String(config.verdictCacheMaxEntries)}`)
  }
  if (config.allowUnmarkedAudit !== undefined && typeof config.allowUnmarkedAudit !== 'boolean') {
    throw new TypeError(`allowUnmarkedAudit must be a boolean, got ${String(config.allowUnmarkedAudit)}`)
  }
  const rawBackend = config.reviewerBackend
  if (rawBackend !== undefined && rawBackend !== 'agent' && rawBackend !== 'phocinae') {
    throw new TypeError(`reviewerBackend must be one of "agent", "phocinae", got ${JSON.stringify(rawBackend)}`)
  }
  // An explicit backend always wins; otherwise a Phocinae model id selects the
  // local decision service, which makes `reviewerModel: Phocinae-…` sufficient.
  const reviewerBackend: ReviewerBackend = rawBackend
    ?? (isPhocinaeModelName(config.reviewerModel) ? 'phocinae' : 'agent')
  const phocinae = resolvePhocinaeConfig(config.phocinae, config.reviewerModel)
  const reviewerTools = config.reviewerTools ?? ['read', 'glob', 'grep']
  if (reviewerTools.length === 0) {
    throw new TypeError('reviewerTools must name at least one tool: an empty allow-list would leave the reviewer with no tool face')
  }
  const riskRules = (config.riskRules ?? []).map((rule, index): ResolvedRiskRule => {
    let regex: RegExp
    try {
      // Flags are stripped: a global flag would make repeated .test() calls
      // stateful (lastIndex), and other flags would silently change semantics.
      regex = new RegExp(rule.pattern, 'u')
    } catch (error: unknown) {
      throw new TypeError(`riskRules[${index}]: pattern ${JSON.stringify(rule.pattern)} is not a valid regular expression: ${String(error)}`)
    }
    return { pattern: rule.pattern, regex, policy: rule.policy, field: rule.field ?? 'reason' }
  })
  return {
    enableByDefault: config.enableByDefault ?? true,
    toolsPolicy: {
      default: config.toolsPolicy?.default ?? 'human',
      overrides: config.toolsPolicy?.overrides ?? {},
    },
    riskRules,
    reviewerProvider: config.reviewerProvider ?? 'fork',
    reviewerPreset: config.reviewerPreset,
    reviewerModel: config.reviewerModel ?? undefined,
    reviewerModelProvider: config.reviewerModelProvider ?? undefined,
    reviewerBackend,
    phocinae,
    reviewerTimeoutMs: config.reviewerTimeoutMs ?? 60_000,
    reviewerTools,
    fallbackPolicy: config.fallbackPolicy ?? 'rejected',
    maxReviewsPerTurn: config.maxReviewsPerTurn ?? 10,
    maxFailuresPerTurn: config.maxFailuresPerTurn ?? config.maxReviewsPerTurn ?? 10,
    reasonMaxChars: config.reasonMaxChars ?? 2000,
    reviewerGuidance: config.reviewerGuidance,
    reviewerPolicyText: config.reviewerPolicyText,
    denyGuidance: config.denyGuidance ?? DEFAULT_DENY_GUIDANCE,
    contextBudget: { turns, maxChars: contextChars },
    riskPolicy: {
      maxAutoAllow: config.riskPolicy?.maxAutoAllow ?? 'high',
      onHighRisk: config.riskPolicy?.onHighRisk ?? 'delegate',
    },
    circuitBreaker: {
      consecutiveDenies: breaker.consecutiveDenies ?? 3,
      windowDenies: breaker.windowDenies ?? 6,
      windowSize: breaker.windowSize ?? 10,
      action: breaker.action ?? 'delegate',
    },
    overrideTtlMs: config.overrideTtlMs ?? 5 * 60_000,
    verdictCacheTtlMs: config.verdictCacheTtlMs ?? 60_000,
    verdictCacheMaxEntries: config.verdictCacheMaxEntries ?? 256,
    language: config.language ?? 'en',
    allowUnmarkedAudit: config.allowUnmarkedAudit ?? false,
  }
}
