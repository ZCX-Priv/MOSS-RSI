/**
 * Trace collection for dsh-eval: fold one agent session's durable event log
 * (from an anchor sequence) into an owned, JSON-serializable case trace —
 * tool-call/result pairs, the final assistant text, summed token usage, the
 * final turn outcome, and the last request header (system prompt + tool
 * catalog). Pure functions over `readonly SessionEvent[]`; no live DSH
 * references survive into the returned values.
 * @module dsh-auto-review/eval/trace
 */

import type { SessionEvent, SessionId } from '@deepseek-ai/dsh-session'
import { readToolResult, toolResultIsError, toolResultText } from '../session-message.ts'

/** One collected tool invocation: the call and, when present, its paired result. */
export interface ToolCallRecord {
  /** The call id pairing `tool/call` and `tool/result`. */
  readonly callId: string
  /** The requested tool name. */
  readonly name: string
  /** The raw arguments JSON exactly as the model produced it. */
  readonly arguments: string
  /** The parsed arguments, when they are valid JSON. */
  readonly argumentsJson?: unknown
  /** The paired result, when the log has it. */
  readonly result?: {
    /** The concatenated text of the result message's content blocks. */
    readonly text: string
    /** Whether the result carries an error identity. */
    readonly isError: boolean
    /** The structured error identity, when the log recorded one. */
    readonly error?: { name: string; code: string }
  }
}

/** Summed token accounting across the traced interval. */
export interface TraceTokenUsage {
  readonly inputTokens: number
  readonly outputTokens: number
  readonly cacheReadTokens: number
  readonly cacheWriteTokens: number
  readonly reasoningTokens: number
}

/** Owned copy of one turn-end reason (unknown kinds degrade to a label). */
export type TraceTurnEnd =
  | { kind: 'completed' }
  | { kind: 'aborted' }
  | { kind: 'blocked' }
  | { kind: 'error'; code: string; message: string }
  | { kind: 'max-tokens' }
  | { kind: 'interrupted' }
  /** Fork-seed construction closed a turn still open at the fork boundary (host `TurnEndReasonMap.forked`). */
  | { kind: 'forked' }
  | { kind: 'unknown' }

/** One collected request header: the model-visible prompt and tool catalog. */
export interface TraceRequestHeader {
  /** The rendered system prompt text (the last non-empty `system/message` node on the 0.1.5 line, `request/header.header.system` on the 0.1.2/0.1.3 lines), when the request had one. */
  readonly system?: string
  /** The assembled tool schemas (the request-time tool catalog). */
  readonly tools: readonly TraceToolSchema[]
  /** The provider/model route the request used. */
  readonly provider?: string
  readonly model?: string
  readonly contextWindow?: number
}

/** Owned copy of one tool schema entry (name + description). */
export interface TraceToolSchema {
  readonly name: string
  readonly description?: string
}

/** Owned per-step timing record, folded from the event log's `time` stamps. */
export interface TraceStep {
  /** The turn this step belongs to. */
  readonly turn: number
  /** The step index inside its turn. */
  readonly step: number
  /** The `step/start` wall-clock time, when the log has it. */
  readonly startMs?: number
  /** The first stream-delta wall-clock time (time-to-first-token base): `assistant/chunk` on the 0.1.2 line, the message's timed stream on the 0.1.3 line. */
  readonly firstTokenMs?: number
  /** The last stream-delta wall-clock time (same dual-line source as `firstTokenMs`). */
  readonly lastTokenMs?: number
  /** The `step/end` wall-clock time, when the step completed. */
  readonly endMs?: number
  /** The step's output tokens, when the adapter reported usage. */
  readonly outputTokens?: number
}

/** The complete collected trace of one case run. */
export interface CaseTrace {
  /** The agent/session id the run executed in. */
  readonly sessionId: string
  /** The first event sequence number included (the anchor). */
  readonly firstSeq: number
  /** The last event sequence number included. */
  readonly lastSeq: number
  /** Tool calls in log order. */
  readonly toolCalls: readonly ToolCallRecord[]
  /** The last non-empty assistant text, or '' when the run produced none. */
  readonly finalOutput: string
  /** Summed token usage; absent when the adapter reported none. */
  readonly tokenUsage?: TraceTokenUsage
  /** The final turn-end reason of the traced interval. */
  readonly turnEnd?: TraceTurnEnd
  /** The last request header of the traced interval. */
  readonly requestHeader?: TraceRequestHeader
  /** Per-step timing records (step latency, TTFT, token speed), in turn/step order. */
  readonly steps?: readonly TraceStep[]
}

/** Extract the text blocks of a message's content as one string. */
function contentText(content: readonly { type: string }[]): string {
  return content
    .filter(block => block.type === 'text')
    .map(block => (block as unknown as { text: string }).text)
    .join('')
}

/** Parse JSON without throwing. */
function tryParseJson(text: string): unknown | undefined {
  try {
    return JSON.parse(text) as unknown
  } catch {
    return undefined
  }
}

/**
 * Copy one turn-end reason into the owned {@link TraceTurnEnd} shape.
 *
 * The host's `TurnEndReasonMap` is merge-extensible, so this is deliberately
 * NOT exhaustive: `default` labels a kind this build does not know instead of
 * silently falling through. `forked` (host `dsh-v0.1.7-alpha.1`) has its own
 * case rather than landing in `default`, so a fork-seed cut is reported as
 * itself instead of as an unrecognized reason.
 */
function copyTurnEnd(value: unknown): TraceTurnEnd {
  if (typeof value !== 'object' || value === null) return { kind: 'unknown' }
  const record = value as Record<string, unknown>
  const kind = record.kind
  switch (kind) {
    case 'completed': return { kind: 'completed' }
    case 'blocked': return { kind: 'blocked' }
    case 'max-tokens': return { kind: 'max-tokens' }
    case 'interrupted': return { kind: 'interrupted' }
    case 'forked': return { kind: 'forked' }
    case 'aborted': return { kind: 'aborted' }
    case 'error': {
      const error = record.error
      if (typeof error === 'object' && error !== null) {
        const fact = error as Record<string, unknown>
        return {
          kind: 'error',
          code: typeof fact.code === 'string' ? fact.code : 'UNKNOWN',
          message: typeof fact.message === 'string' ? fact.message : String(fact),
        }
      }
      return { kind: 'error', code: 'UNKNOWN', message: String(error) }
    }
    default: return { kind: 'unknown' }
  }
}

/**
 * Fold the session events at or after `firstSeq` into a {@link CaseTrace}.
 * Events before the anchor (startup/seed) are excluded; the anchor is what
 * makes one case's trace independent of the agent's creation noise.
 * @param sessionId - the session the events belong to.
 * @param events - the session's event log in order.
 * @param firstSeq - the anchor sequence (inclusive).
 * @returns the owned trace.
 */
/** Mutable per-step accumulator, finalized into owned {@link TraceStep}s. */
interface MutableStep {
  readonly turn: number
  readonly step: number
  startMs: number | undefined
  firstTokenMs: number | undefined
  lastTokenMs: number | undefined
  endMs: number | undefined
  outputTokens: number | undefined
}

/** Finalize one mutable accumulator into an owned trace step. */
function toTraceStep(step: MutableStep): TraceStep {
  return {
    turn: step.turn,
    step: step.step,
    ...(step.startMs !== undefined ? { startMs: step.startMs } : {}),
    ...(step.firstTokenMs !== undefined ? { firstTokenMs: step.firstTokenMs } : {}),
    ...(step.lastTokenMs !== undefined ? { lastTokenMs: step.lastTokenMs } : {}),
    ...(step.endMs !== undefined ? { endMs: step.endMs } : {}),
    ...(step.outputTokens !== undefined ? { outputTokens: step.outputTokens } : {}),
  }
}

export function collectTrace(sessionId: SessionId, events: readonly SessionEvent[], firstSeq: number): CaseTrace {
  const toolCalls: ToolCallRecord[] = []
  const resultsByCall = new Map<string, { text: string; isError: boolean; error?: { name: string; code: string } }>()
  const stepsById = new Map<string, MutableStep>()
  const stepOf = (turn: number, step: number): MutableStep => {
    const key = `${turn}:${step}`
    const existing = stepsById.get(key)
    if (existing !== undefined) return existing
    const created: MutableStep = { turn, step, startMs: undefined, firstTokenMs: undefined, lastTokenMs: undefined, endMs: undefined, outputTokens: undefined }
    stepsById.set(key, created)
    return created
  }
  let finalOutput = ''
  let usage: TraceTokenUsage | undefined
  let turnEnd: TraceTurnEnd | undefined
  let requestHeader: TraceRequestHeader | undefined
  // Dual-line system prompt: the 0.1.2/0.1.3 lines carry the rendered prompt
  // on `request/header.header.system`; the 0.1.5 line removed that field and
  // represents the prompt as surface node zero (a `system/message` event).
  // An empty node clears the older text, matching the host's effective-prompt
  // rule, so only the latest non-empty text survives the fold.
  let systemPrompt: string | undefined
  let lastSeq = firstSeq - 1
  for (const event of events) {
    if (event.seq < firstSeq) continue
    lastSeq = event.seq
    // Dual-line stream timing: the 0.1.2 log exposes per-delta timing as
    // `assistant/chunk`; the 0.1.3 line dropped that event (its committed
    // messages carry an exact timed `stream` instead, and `assistant/attempt`
    // records settled attempts that carry no timing). Fold the 0.1.2 shape
    // here so the trace works against either published host line.
    if ((event.type as string) === 'assistant/chunk') {
      const chunk = event as unknown as { data: { turn: number; step: number } }
      const step = stepOf(chunk.data.turn, chunk.data.step)
      if (step.firstTokenMs === undefined) step.firstTokenMs = event.time
      step.lastTokenMs = event.time
      continue
    }
    switch (event.type) {
      case 'step/start': {
        stepOf(event.data.turn, event.data.step).startMs = event.time
        break
      }
      case 'step/end': {
        stepOf(event.data.turn, event.data.step).endMs = event.time
        break
      }
      case 'tool/call': {
        toolCalls.push({
          callId: event.data.callId,
          name: event.data.name,
          arguments: event.data.arguments,
          ...((): { argumentsJson?: unknown } => {
            const parsed = tryParseJson(event.data.arguments)
            return parsed === undefined ? {} : { argumentsJson: parsed }
          })(),
        })
        break
      }
      case 'tool/result': {
        // The result shape differs by host line (V4 first-class tool message vs
        // the retired V3 `tool-result` wrapper); `readToolResult` reads both.
        const result = readToolResult(event.data.message)
        if (result === undefined) break
        resultsByCall.set(result.callId, {
          text: toolResultText(result),
          isError: toolResultIsError(event.data.error, result),
          ...(event.data.error !== undefined ? { error: { name: event.data.error.name, code: event.data.error.code } } : {}),
        })
        break
      }
      case 'assistant/message': {
        const joined = contentText(event.data.message.content as readonly { type: string }[])
        if (joined !== '') finalOutput = joined
        if (event.data.usage !== undefined) {
          const acc = usage ?? { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0, reasoningTokens: 0 }
          usage = {
            inputTokens: acc.inputTokens + event.data.usage.inputTokens,
            outputTokens: acc.outputTokens + event.data.usage.outputTokens,
            cacheReadTokens: acc.cacheReadTokens + (event.data.usage.cacheReadTokens ?? 0),
            cacheWriteTokens: acc.cacheWriteTokens + (event.data.usage.cacheWriteTokens ?? 0),
            reasoningTokens: acc.reasoningTokens + (event.data.usage.reasoningTokens ?? 0),
          }
          const step = stepOf(event.data.turn, event.data.step)
          step.outputTokens = (step.outputTokens ?? 0) + event.data.usage.outputTokens
        }
        // 0.1.3 line: the message's exact timed stream carries the per-step
        // timing the 0.1.2 line exposed as `assistant/chunk` deltas.
        const timed = event.data as { stream?: readonly { time0?: number; dt?: readonly number[] }[] }
        const stream = timed.stream
        if (stream !== undefined && stream.length > 0) {
          const step = stepOf(event.data.turn, event.data.step)
          const first = stream[0]?.time0
          const lastRecord = stream[stream.length - 1]
          const last = lastRecord !== undefined && lastRecord.time0 !== undefined
            ? lastRecord.time0 + (lastRecord.dt?.[lastRecord.dt.length - 1] ?? 0)
            : undefined
          if (first !== undefined && step.firstTokenMs === undefined) step.firstTokenMs = first
          if (last !== undefined) step.lastTokenMs = last
        }
        break
      }
      case 'turn/end': {
        turnEnd = copyTurnEnd(event.data.reason)
        break
      }
      case 'system/message': {
        const text = contentText(event.data.message.content as readonly { type: string }[])
        systemPrompt = text === '' ? undefined : text
        break
      }
      case 'request/header': {
        const header = event.data.header
        // Read the retired 0.1.3 field structurally: the installed 0.1.5 type
        // no longer declares it, while the 0.1.2/0.1.3 peers still write it.
        const legacySystem = (header as { system?: unknown }).system
        const system = typeof legacySystem === 'string' ? legacySystem : systemPrompt
        requestHeader = {
          ...(system !== undefined ? { system } : {}),
          tools: (header.tools ?? []).map(tool => {
            const schema = tool as { name?: string; description?: string }
            return {
              ...(schema.name !== undefined ? { name: schema.name } : { name: '(unnamed)' }),
              ...(schema.description !== undefined ? { description: schema.description } : {}),
            }
          }),
        }
        break
      }
      case 'request/context': {
        requestHeader = {
          ...(requestHeader ?? { tools: [] }),
          provider: event.data.provider,
          model: event.data.model,
          ...(event.data.contextWindow !== undefined ? { contextWindow: event.data.contextWindow } : {}),
        }
        break
      }
      default: break
    }
  }
  for (const call of toolCalls) {
    const result = resultsByCall.get(call.callId)
    if (result !== undefined) (call as { result?: ToolCallRecord['result'] }).result = result
  }
  const steps: TraceStep[] = [...stepsById.values()]
    .sort((a, b) => a.turn - b.turn || a.step - b.step)
    .map(toTraceStep)
  return {
    sessionId: sessionId as string,
    firstSeq,
    lastSeq,
    toolCalls,
    finalOutput,
    ...(usage !== undefined ? { tokenUsage: usage } : {}),
    ...(turnEnd !== undefined ? { turnEnd } : {}),
    ...(requestHeader !== undefined ? { requestHeader } : {}),
    steps,
  }
}

/** Render one tool call as a compact single line (reports, review prompts). */
export function renderToolCall(call: ToolCallRecord): string {
  const result = call.result === undefined
    ? '(no result recorded)'
    : `${call.result.isError ? 'error' : 'ok'}: ${call.result.text.slice(0, 300)}`
  return `${call.name} ${call.arguments.slice(0, 300)} → ${result}`
}
