/**
 * @description dsh-auto-pass 客户端半：注册两个面板——
 *   1) 对话区标签页「审批设置」：连续放行阈值 + 项目/全局 × 白名单/黑名单的查看与撤销；
 *   2) 右侧栏「审批时间线」：倒序展示审批记录，并支持把某条记录一键升级为白名单
 *      （以后直接放行）或降级为黑名单（以后直接转人工）；规则文本由 Reviewer 模型产出，
 *      记录里没有模型建议时精确回落到该次动作签名。
 *   放置位置参照 dsh-context：placement=auto 时优先右侧栏座位，座位不可用退回对话标签页。
 * @author simon300000
 * @date 2026-09-15
 * @modify 2026-09-15 对话区改放「审批设置」，时间线移入右侧栏并加升级/降级操作
 * @modify 2026-09-15 面板改为与消息列同宽的居中卡片；时间线行内展示审批意见摘要
 * @modify 2026-09-15 右侧栏 chip 标题加图标；审批意见只显示一行
 * @modify 2026-09-15 时间线切到「全部会话」时，在每条记录最下面用小字标出会话名
 * @modify 2026-09-15 时间线加「全部 / 白名单 / 黑名单 / 自动 / 人工」快捷筛选（多选叠加，按钮带条数）
 * @modify 2026-09-15 升级/降级结果如实区分「已更新同名规则 / 已被已有规则覆盖 / 已合并窄规则」
 * @modify 2026-09-15 自动打开时间线改为「只要触发审批、且时间线没打开就展开」：常驻观察器按当前会话最新记录 id 判断新审批，首次观测只记基线
 * @modify 2026-09-15 计数说明文案同步「最终结果为准、管道之后不参与区分」
 * @modify 2026-09-15 规则可微调：时间线详情加可编辑表单（匹配条件/匹配值/标签，四个按钮按你填的内容写入），设置面板每条规则可「编辑」（op=update 原地更新）
 * @modify 2026-09-15 规则表单改用自带分段按钮（原生 <select> 深色主题下弹层白底）、切条件时值立刻刷新、操作区改竖排
 * @modify 2026-09-15 换匹配条件后让模型按该条件重新生成（/rule/draft，提示词带上条件与当前草稿）；路径前缀的通配符即时校验与口径提示
 * @modify 2026-09-15 这次动作用不上的匹配条件（没有命令 / 没有路径）按钮禁用并说明原因
 * @modify 2026-09-16 详情里的「权限指纹」显示归一化后的签名 key（与规则表单生成的签名逐字一致），
 *   可读文本另起一行「签名摘要」；模型建议里不等于本次签名的假签名不再当表单默认值
 * @modify 2026-09-16 「加入名单」可撤销：详情里列出被顶掉的规则，并可通过 /rule/revert 还原；
 *   覆盖命中（没写入任何条目）不给撤销；设置面板编辑规则也会列出被合并掉的窄规则
 * @modify 2026-09-16 权限指纹只读 + 可视化：原始串（含 NUL）不再显示/不再靠选中复制——
 *   界面显示渲染后的文案，整串复制走「复制指纹」按钮（剪贴板 API）；详情里拆成工具/命令/额外参数
 * @modify 2026-09-18 达阈值自动加入白名单的记录在折叠行就给标识（RuleAutoBadge）：
 *   标出条件来源是审查模型的建议还是本次动作的权限指纹；覆盖命中时说明没新增条目
 * @modify 2026-09-18 展开详情重排成两层（用户要求：引导优先 + 排查折叠）——明面只留决定依据，
 *   「这次写没写规则」合并成一张 RuleCard（含撤销，替代原「已应用」字段与 UndoRule 行），
 *   「加入名单」表单与「排查信息」（全部技术字段）默认收起；两个入口的开合状态放在 RecordRow 上
 * @modify 2026-09-18 按预览页（preview/detail-options.html）选定的「融合版」定稿：结论条
 *   （.ap-callout + 风险/授权/命中/连续计数 chip）+「依据」分组 + 规则卡 + 底部右对齐的两个文字入口；
 *   命中规则并进结论条 chip（t.policyHit 删除），Reviewer 行改挂审查模型路由
 * @modify 2026-09-18 第二轮（同样先出预览页）：加入名单表单改成「三行可见标签 + 作用域选一次 + 两个动作按钮」
 *   （t.promote/t.demote 与 4 个作用域按钮删除），排查信息改成两组（这次动作 / 审查与用量）+ 去重
 *   —— 去掉「工具」「签名摘要」「已自动升级」与 Reviewer 的「0 steps」，「一个字段都不删」这条被用户推翻
 * @modify 2026-09-18 第三轮（预览页 timeline-*.html 逐项定稿后落地）时间线整体重排：
 *   ① 列表骨架：左侧 18px 轨道（竖线 + 按结论着色的圆点）+ 按天分组（t.dayToday/dayYesterday，日期进组标题、
 *      行头只留时分秒）+ **两行行头**（时间 · 工具 · 来源 chip ·（+白名单）· 结论/结果徽标 ／ 审批意见）；
 *      时间**紧贴圆点**（行头不留左内边距、展开箭头删除，整行就是按钮），「第几轮第几步」撤出折叠行；
 *      命中规则说明进 chip 的 tooltip（与审批意见只能留一个）
 *   ② 展开态：整块背景把轨道/圆点/时间一起包进来（.ap-item.open::before，用伪元素避免把 8px 记录间隔也染上），
 *      行头与详情之间一条分割线且整条跨过去（.ap-detailBox 负 margin 顶到面板左边缘），展开块圆点放大到 10px；
 *      RuleAutoBadge 由长句压成短标记（+白名单 / 白名单已覆盖），条件来源仍留在 tooltip
 *   ③ 两块改「卡头即入口」（FoldCard）：卡头行本身就是开关（data-ui 仍挂在它上面），
 *      底部那行重复的文字入口（.ap-detailFoot / .ap-btnGhost）删除；正文用函数传入，收起时不构造元素
 *   ④ 移除「本次会话 / 全部会话」切换（面板固定看本次会话），记录字段与宿主 /log 接口一律保留——
 *      随之删掉会话名那行小字（.ap-session）与 t.scopeSession / t.scopeAll，sessionNameOf 成为死代码被删
 * @modify 2026-09-18 「自动打开审批时间线」按钮按工作区区分（用户要求）：runtimeStore 多出
 *   sessionId / autoOpenSession / autoOpenScoped 与 autoOpenFor(sessionId)，load(cwd, sessionId) / save(patch, {cwd, session})
 *   （POST 带 cwd 时宿主写该项目策略文件的 prefs）；面板里的开关读写本工作区那份，
 *   设置页卡片仍是所有工作区的默认值
 * @modify 2026-10-09 「自动打开审批时间线」改回**一个全局开关**（用户要求：关掉之后老是自己打开）：
 *   runtimeStore 去掉会话/工作区那两层的字段与 autoOpenFor，load() / save() 回到不带 cwd / session；
 *   面板与设置页卡片写的是同一个值，观察器每轮直接读 runtimeStore.autoOpenTimeline
 */
window.__ModuleLoader__.load({
  id: 'dsh-auto-pass',
  factory: (require) => {
    const module = { exports: {} }
    const exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })
    const react = require('react')

    /** 客户端日志前缀。 */
    const LOG = '[dsh-auto-pass]'
    /** 宿主接口。 */
    const API_CONFIG = '/api/dsh-auto-pass/config'
    /** 模型候选：宿主模型目录（provider → models，含每个模型的思考强度）。 */
    const API_MODELS = '/api/dsh-auto-pass/models'
    const API_LOG = '/api/dsh-auto-pass/log'
    const API_POLICY = '/api/dsh-auto-pass/policy'
    const API_RULE = '/api/dsh-auto-pass/rule'
    /** 只生成不落盘：换匹配条件时让模型按那个条件重新生成一遍。 */
    const API_RULE_DRAFT = API_RULE + '/draft'
    /** 撤销一次「加入名单」：宿主按记录里的凭据还原名单。 */
    const API_RULE_REVERT = API_RULE + '/revert'
    /** 启动信标：把客户端半走到哪一步写进宿主日志（排查「看不到面板」用）。 */
    const API_BEACON = '/api/dsh-auto-pass/beacon'
    /** 时间轴轮询间隔（毫秒）。 */
    const POLL_MS = 3_000
    /** 自动打开审批时间线失败后的重试延迟（毫秒）。 */
    const AUTO_OPEN_RETRY_MS = 150
    /**
     * 「刚发生」窗口（毫秒）：只有最新记录落在这个窗口内才自动展开审批时间线。
     * 2026-09-20 用户口径：按**记录新鲜度**判，而不是按「这个会话本轮页面有没有被看过」判——
     * 于是「刚切过去 / 刚刷新就赶上审批」照样会弹，而翻到的历史记录只记基线。
     */
    const AUTO_OPEN_FRESH_MS = 60_000
    /**
     * 切进一个会话时允许自动展开的未读上限（用户 2026-09-20 口径）：攒得比这还多就一定弹一次。
     */
    const UNREAD_AUTO_OPEN_MAX = 5
    /**
     * 切进一个会话时，「上次看过它」距今超过这个时长（毫秒）而期间攒了未读 → 自动展开一次。
     */
    const AUTO_OPEN_AFTER_AWAY_MS = 60_000
    /**
     * 未读角标每次取多少条记录：一次请求同时喂「自动展开」与「未读计数」（不带 session 查全部会话，
     * 最新在前）。只关心刚发生的审批，30 条足够。
     */
    const UNREAD_FETCH_LIMIT = 30
    /** 右侧栏 tab 类型标识，同时是正文/标题席位的 key。 */
    const SIDEBAR_ID = 'dsh-auto-pass'
    const SIDEBAR_KIND = 'dsh-auto-pass-log'
    /** 对话区标签页的席位 id（conversation.view 内必须唯一）。 */
    const VIEW_ID = 'dsh-auto-pass'
    const PLACEMENTS = ['auto', 'tab', 'sidebar', 'all']

    /**
     * 上报一次启动阶段：既打宿主日志（fetch），也写 localStorage 轨迹
     * （后者不依赖 fetch，可直接从渲染器的 leveldb 文件里读出来核对）。
     * 两条通道都失败也不影响插件本体。
     */
    function beacon(stage, detail = '') {
      try {
        const trail = JSON.parse(localStorage.getItem('dsh-auto-pass:boot') ?? '[]')
        trail.push(stage + (detail === '' ? '' : '(' + detail + ')'))
        localStorage.setItem('dsh-auto-pass:boot', JSON.stringify(trail.slice(-24)))
      } catch (error) {
        // localStorage 不可用时只靠宿主日志；这里不打断流程
        void error
      }
      try {
        void fetch(API_BEACON + '?stage=' + encodeURIComponent(stage) + '&detail=' + encodeURIComponent(detail), {
          headers: { accept: 'application/json' },
        }).catch(() => {})
      } catch (error) {
        // fetch 本身不可用时忽略
        void error
      }
    }
    try {
      localStorage.removeItem('dsh-auto-pass:boot')
    } catch (error) {
      // 清不掉上一轮轨迹不影响功能
      void error
    }
    beacon('factory')

    /** 取界面语言：跟随浏览器语言，中文用简体文案。 */
    const ZH = /^zh/i.test(typeof navigator === 'object' && navigator !== null ? String(navigator.language ?? '') : '')
    const COPY = {
      zh: {
        timelineTab: '审批时间线',
        policyTab: '审批设置',
        guideDescription: '自动审批的自动批准与转人工记录，可一键升级为白名单或降级为黑名单',
        title: '审批时间线',
        subtitle: '最新的在最上面',
        // 按天分组（用户 2026-09-18 定）：日期交给组标题，行头里只留时分秒
        dayToday: '今天',
        dayYesterday: '昨天',
        reload: '刷新',
        empty: '还没有审批记录',
        loading: '加载中…',
        autoApproved: '自动批准',
        referred: '转人工',
        denyRejected: '直接拒绝',
        reviewFailed: '审查未完成',
        outcomeAllowed: '已批准',
        outcomeRejected: '已拒绝',
        outcomeUnavailable: '无人应答',
        outcomeCancelled: '已取消',
        risk: '风险',
        authorization: '授权',
        rationale: '审批意见',
        action: '动作',
        latency: '耗时',
        tokens: 'Token 消耗',
        usageIn: '输入',
        usageOut: '输出',
        usageTotal: '合计',
        reason: '审批原因',
        time: '时间',
        signature: '权限指纹',
        // 「签名摘要」不在界面上了（用户 2026-09-18：与「工具 + 命令」同义，排查区去重时删掉）
        suggestedRule: '模型建议规则',
        // 命中规则不再单独占一行：并进「结论条」的 chip（见 kvChip 与 calloutChips）
        hitAllow: '白名单',
        hitDeny: '黑名单',
        filterAll: '全部',
        filterAuto: '自动',
        filterHuman: '人工',
        filterEmpty: '没有符合筛选条件的记录',
        approvals: '连续放行',
        denials: '连续被拒',
        decidedAuto: '自动',
        decidedHuman: '人工',
        decidedBy: '决策来源',
        ruleAuto: '自动',
        ruleManual: '手动',
        decidedAutoText: '模型自动审批',
        decidedHumanText: '人工审批',
        decidedUnknown: '无人工结论',
        decidedAutoTitle: '模型自动审批',
        decidedHumanTitle: '人工审批通过或拒绝',
        ruleAsk: '规则询问',
        ruleDeclined: '已询问，未加入',
        // 「加入名单」表单的两个动作按钮（用户 2026-09-18 从预览页选定：4 个作用域按钮收成「作用域 + 两个动作」）
        actionAllow: '以后直接放行',
        actionDeny: '以后直接转人工',
        scopeProject: '本项目',
        scopeGlobal: '全局',
        working: '处理中…',
        appliedModel: '已加入（模型优化）',
        appliedRecord: '已加入（采用审查时的模型建议）',
        appliedFallback: '已加入（没有可用的模型建议，已回落到本次动作的权限指纹）',
        appliedReplaced: labels => '（已更新同名规则' + (labels === '' || labels === undefined ? '' : '：' + labels) + '）',
        appliedCovered: '（已有规则已覆盖这个动作，未重复添加）',
        appliedAuto: by => '（连续放行达阈值，自动加入，未询问'
          + (by === 'record' ? '；条件来自审查模型的建议' : by === 'signature' ? '；条件是本次动作的权限指纹' : '') + '）',
        // 达阈值触发自动写入、但已有规则已覆盖这次动作（一条都没写进去）：只说这一句，
        // 免得「未重复添加」紧接着「自动加入」这种自相矛盾的读法
        appliedAutoCovered: '（连续放行达阈值，但已有规则覆盖这次动作，未新增条目）',
        // 折叠行的标识（用户 2026-09-18 要求，第二次调整口径）：不用展开就能看到这条记录顺手把规则
        // 写进了白名单。行头压到两行之后只放得下短标记（`+白名单`），条件来源（模型建议 / 权限指纹）
        // 与作用域 + 规则标签一并挪进 tooltip（见 ruleAutoTitle）；覆盖命中时如实说明没新增条目。
        ruleAutoBadge: list => (list === 'deny' ? '+黑名单' : '+白名单'),
        ruleAutoCovered: list => (list === 'deny' ? '黑名单已覆盖' : '白名单已覆盖'),
        ruleAutoTitle: (by, detail) => '连续放行达阈值后自动写入白名单，未询问'
          + (by === 'record' ? '；条件来自审查模型的建议' : by === 'signature' ? '；条件是本次动作的权限指纹' : '')
          + '：' + detail,
        // 覆盖命中那次的 tooltip：达阈值确实触发了自动写入，但一条都没写进去——不能照抄上面那句
        ruleAutoCoveredTitle: detail => '连续放行达阈值触发了自动写入，但已有规则已覆盖这次动作、未新增条目：' + detail,
        // 规则卡上的条件来源标（用户 2026-09-18）：先分清「没问过你直接写的」与「你确认后写的」，再说条件从哪来
        ruleSourceAutoRecord: '自动 · 模型建议',
        ruleSourceAutoFingerprint: '自动 · 权限指纹',
        ruleSourceRecord: '模型建议',
        ruleSourceModel: '模型优化',
        ruleSourceManual: '你手填的',
        // 「加入名单」与「排查信息」两块（用户 2026-09-18 最后定「卡头即入口」）：
        // 卡头那一行就是开关，底部不再有第二处文字入口（那是同一件事的两处文字）
        blockRuleTitle: '加入名单',
        blockRuleHint: '写一条规则，以后按它匹配',
        blockDebugTitle: '排查信息',
        blockDebugHint: '对账用，平时不用看',
        // 「结论条」与「依据」分组（用户 2026-09-18 从预览页选定「融合版」）
        // 认不出来的等级返回 undefined：命中黑名单 / 老记录根本没有 risk_level，别说成「?风险」
        riskWord: level => ({ low: '低', medium: '中', high: '高', critical: '极高' }[level]),
        calloutLead: (verdict, riskWord) => (riskWord === undefined ? verdict : verdict + ' · ' + riskWord + '风险'),
        groupBasis: '依据',
        chipHit: label => '命中 ' + label,
        // 「加入名单」表单的作用域（用户 2026-09-18 选定：A 的行 + B 的按钮）
        formScope: '作用域',
        // 「排查信息」的两组小标题（用户 2026-09-18 选定：分组 + 去重）
        debugGroupAction: '这次动作',
        debugGroupReview: '审查与用量',
        reviewModel: '审查模型',
        appliedMerged: (count, labels) => '（已合并 ' + String(count) + ' 条被它覆盖的窄规则'
          + (labels === '' || labels === undefined ? '' : '：' + labels) + '）',
        appliedManual: '已按你填写的条件加入',
        // 「加入名单」可以撤销（用户 2026-09-16 要求）：一条更宽的前缀会把之前确认过的窄规则合并掉，得能还原
        undoRule: '撤销这次加入',
        ruleUndoLabel: '本次加入的规则',
        ruleDropped: labels => '顶掉了：' + labels,
        ruleUndone: '已撤销，名单已还原',
        // 表单不再有独立标题（用户 2026-09-18：每行左侧已给可见标签，标题是多余的一层）
        ruleKind: '匹配条件',
        ruleValue: '匹配值',
        ruleLabelField: '规则标签',
        ruleDraftFromModel: '默认来自这次审查的模型建议，可以直接改',
        ruleDraftFromSignature: '默认是本次动作的权限指纹（同一动作换个输出截断/说明仍是同一个）；想覆盖同一命令的其他参数就切到「命令前缀」',
        ruleDraftEdited: '值已按所选条件刷新，仍可继续手改（管道 | 之后的部分只决定怎么显示输出）',
        ruleDraftRegenerating: '正在让模型按所选条件重新生成…',
        ruleDraftRegenerated: '已让模型按所选条件重新生成，仍可继续手改',
        ruleDraftRegenFailed: '模型这次没能生成（已按条件本地推导，可继续手改）',
        ruleNeedLabel: '规则标签不能为空',
        ruleNeedValue: '匹配值不能为空',
        ruleNeedLongerPrefix: '前缀类条件至少 3 个字符',
        rulePathGlobHint: '路径前缀支持单层通配：D:/work/x/src/*.js 只匹配该目录下的 .js 文件（不跨目录）',
        ruleNoDoubleStar: '路径规则不支持 **（跨目录通配太宽）',
        ruleNoOtherGlob: '只支持 * 这一个通配符（不支持 ? 与 []）',
        ruleStarLastSegment: '* 只能出现在路径的最后一段（文件名部分）',
        ruleCommandStarHint: '命令前缀里的 * 是字面量、不会展开：这样写只会命中「命令文本里真的带 tests/*」的调用。想覆盖一类命令请把前缀写短，例如 pnpm vitest run',
        ruleKindUnavailable: kind => kind + '匹配不到这次动作（它没有对应的命令或路径参数），已禁用',
        edit: '编辑',
        saveEdit: '保存修改',
        cancelEdit: '取消',
        sourceUser: '手动',
        sourceModel: '模型',
        sourceMemory: '记忆',
        kindSignature: '权限指纹',
        // 权限指纹是机器算出来的串：界面上只读，并按它的结构摊开给人看（用户 2026-09-16 要求）
        // 指纹摊开的明细不再单独列「工具」（用户 2026-09-18：指纹行本身就以工具名开头）
        fingerprintCommand: '命令',
        fingerprintArgs: '参数',
        fingerprintExtra: '额外参数',
        fingerprintReadonly: '权限指纹由插件算出、不能手改；想覆盖同一命令的其他参数请切到「命令前缀」',
        fingerprintLocked: '权限指纹不能手填（只能由时间线上的某条记录生成）',
        copyFingerprint: '复制指纹',
        copiedFingerprint: '已复制完整指纹',
        copyFingerprintFailed: '复制不了（这个环境没有剪贴板权限）',
        kindCommandPrefix: '命令前缀',
        kindPathPrefix: '路径前缀',
        settingsTitle: '审批设置',
        settingsDesc: '连续放行达到阈值后，插件会把这次动作的匹配条件直接自动加入白名单，不再询问；连续被拒达到阈值后，仍会先让 DSH 模型把动作优化成一条匹配条件，再询问你是否加入黑名单。',
        thresholdLabel: '连续放行阈值',
        thresholdLabelDeny: '连续被拒阈值',
        thresholdHintAllow: '达到后自动加入白名单（不再询问）',
        thresholdHintDeny: '达到后询问是否加入黑名单',
        thresholdUnit: '次',
        ruleAskNote: '自动审批与你本人的放行都计入「连续放行」（哪怕模型原本判了拒绝，只要你点了允许一次就算放行）；最终没被批准才计入「连续被拒」。计数只看命令本身，管道 | 后面的输出截断不参与区分。白名单那侧达阈值直接写入、不再询问；黑名单那侧问过一次并选择「不加入」后，这个动作不会再被询问。',
        save: '保存',
        saved: '已保存',
        globalScope: '全局（所有项目）',
        projectScope: '项目',
        allowList: '白名单 · 直接放行',
        denyList: '黑名单 · 直接转人工',
        emptyList: '（空）',
        remove: '删除',
        projectUnknown: '还没有本会话的审批记录，暂时无法确定项目目录；本会话产生第一条审批记录后即可管理项目规则。',
        cardName: '自动审批面板',
        placementTitle: '面板显示位置',
        placementDesc: '审批设置显示在对话标签页，审批时间线显示在右侧栏（auto 优先右侧栏，座位不可用时退回对话标签页）',
        noticeTitle: '注入审批结果到上下文',
        noticeHint: '关闭后，审批结果不再写进模型的对话上下文（审批时间线不受影响）',
        denyDirectTitle: '黑名单直接拒绝',
        denyDirectHint: '命中黑名单时直接把这次调用判为拒绝（工具调用失败），不再弹人工审批卡',
        autoOpenTitle: '自动打开审批时间线',
        autoOpenHint: '有刚发生的审批（1 分钟内）时自动展开审批时间线；切进一个攒着未读的会话（离开超过 1 分钟、或未读超过 5 条）也会展开一次。切会话 / 刷新后翻到的历史记录不弹，已显示、或时间线 tab 还开着而右侧栏停在其他工具上时也不打扰（手动关掉时间线 tab 后，下一次审批会把它重新打开）——其余情况由 tab 上的未读角标提示，**角标按会话隔离、只显示当前会话的未读数**。这是**全局开关**（关一次即所有会话都不再自动展开，包括以后新建的）',
        unreadTitle: '有未读的审批记录（打开时间线、或在界面里任意操作即清除）',
        askReasonTitle: '拒绝后追问理由',
        askReasonHint: '你拒绝一次审批后，插件问一句拒绝理由并注入模型上下文（默认选项就是本次的模型审批意见）',
        saveFailed: '保存失败',
        switchOn: '开',
        switchOff: '关',
        turnStep: '轮次/步数',
        turnStepLabel: (turn, step) => '第 ' + String(turn) + ' 轮 · 第 ' + String(step) + ' 步',
        rejectReason: '人工拒绝理由',
        savedTip: '已保存',
        placementAuto: '自动',
        placementTab: '只保留审批设置',
        placementSidebar: '只保留时间线',
        placementAll: '两处都显示',
        panelCardDesc: '面板显示在哪里，以及四个行为开关：是否把审批结果注入模型上下文、命中黑名单是否直接拒绝、侧栏收起时是否自动展开审批时间线（已显示或停在其他工具上时不打扰）、人工拒绝后是否追问一句拒绝理由。',
        modelTitle: '审查模型',
        modelDesc: '自动审查用哪个模型、以及调用参数。provider 与模型都留空 = 跟随当前会话；候选来自宿主的模型目录，也可以直接填写。',
        modelProvider: '提供方',
        modelProviderHint: '留空 = 跟随当前会话',
        modelName: '模型',
        modelEffort: '思考强度',
        modelEffortHint: '留空 = 用模型默认',
        modelTimeout: '审查超时（毫秒）',
        modelTimeoutHint: '单轮审查的总时限',
        modelMaxTokens: '输出上限（tokens）',
        modelMaxTokensHint: '审查回复的最大长度',
        modelPlaceholder: '点开输入框看候选，或直接填写',
        modelClear: '清空',
        modelClearHint: '路由两列都留空 = 跟随当前会话；思考强度留空 = 用模型默认',
        modelSave: '保存模型配置',
        modelSaved: '模型配置已保存',
        modelNumbersInvalid: '审查超时与输出上限必须是正整数',
        catalogLoading: '正在读取宿主模型目录…',
        catalogEmpty: '宿主模型目录里没有候选（仍可直接填写）',
        catalogUnavailable: '宿主没有提供模型目录，候选不可用（仍可直接填写）',
      },
      en: {
        timelineTab: 'Approval timeline',
        policyTab: 'Approval policy',
        guideDescription: 'Auto Approve auto-approvals and hand-offs; promote or demote each one',
        title: 'Approval timeline',
        subtitle: 'newest first',
        dayToday: 'Today',
        dayYesterday: 'Yesterday',
        reload: 'Refresh',
        empty: 'No approvals recorded yet',
        loading: 'Loading…',
        autoApproved: 'auto-approved',
        referred: 'handed to user',
        denyRejected: 'rejected outright',
        reviewFailed: 'review incomplete',
        outcomeAllowed: 'allowed',
        outcomeRejected: 'rejected',
        outcomeUnavailable: 'no answerer',
        outcomeCancelled: 'cancelled',
        risk: 'Risk',
        authorization: 'Authorization',
        rationale: 'Rationale',
        action: 'Action',
        latency: 'Latency',
        tokens: 'Token usage',
        usageIn: 'in',
        usageOut: 'out',
        usageTotal: 'total',
        reason: 'Approval reason',
        time: 'Time',
        signature: 'Permission fingerprint',
        // the readable signature summary is no longer shown (it duplicates tool + command)
        suggestedRule: 'Suggested rule',
        // the matched rule is no longer a row of its own: it becomes a chip in the callout
        hitAllow: 'Allowlist',
        hitDeny: 'Denylist',
        filterAll: 'All',
        filterAuto: 'Auto',
        filterHuman: 'Human',
        filterEmpty: 'No records match the filters',
        approvals: 'Consecutive approvals',
        denials: 'Consecutive denials',
        decidedAuto: 'auto',
        decidedHuman: 'human',
        decidedBy: 'Decided by',
        ruleAuto: 'auto',
        ruleManual: 'manual',
        decidedAutoText: 'allowed by the model automatically',
        decidedHumanText: 'human decision',
        decidedUnknown: 'no human outcome',
        decidedAutoTitle: 'allowed by the model automatically',
        decidedHumanTitle: 'approved or rejected by the human',
        ruleAsk: 'Rule prompt',
        ruleDeclined: 'Asked, not added',
        actionAllow: 'Allow it from now on',
        actionDeny: 'Hand it to me from now on',
        scopeProject: 'This project',
        scopeGlobal: 'Global',
        working: 'Working…',
        appliedModel: 'Added (model-optimized)',
        appliedRecord: 'Added (rule suggested by the review model)',
        appliedFallback: 'Added (no usable model suggestion; fell back to this action\u2019s permission fingerprint)',
        appliedReplaced: labels => ' (updated the existing rule' + (labels === '' || labels === undefined ? '' : ': ' + labels) + ')',
        appliedCovered: ' (already covered by an existing rule; nothing added)',
        appliedAuto: by => ' (auto-added after the consecutive-approval threshold, no prompt'
          + (by === 'record' ? '; the condition came from the review model suggestion' : by === 'signature' ? '; the condition is this action\u2019s permission fingerprint' : '') + ')',
        appliedAutoCovered: ' (auto-add threshold reached, but an existing rule already covers this action; nothing added)',
        ruleAutoBadge: list => (list === 'deny' ? '+denylist' : '+allowlist'),
        ruleAutoCovered: list => (list === 'deny' ? 'denylist covered' : 'allowlist covered'),
        ruleAutoTitle: (by, detail) => 'auto-added to the allowlist at the consecutive-approval threshold, no prompt'
          + (by === 'record' ? '; the condition came from the review model suggestion' : by === 'signature' ? '; the condition is this action\u2019s permission fingerprint' : '')
          + ': ' + detail,
        ruleAutoCoveredTitle: detail => 'the auto-add threshold was reached, but an existing rule already covers this action; nothing was added: ' + detail,
        ruleSourceAutoRecord: 'auto \u00b7 review suggestion',
        ruleSourceAutoFingerprint: 'auto \u00b7 fingerprint',
        ruleSourceRecord: 'review suggestion',
        ruleSourceModel: 'model-optimized',
        ruleSourceManual: 'your own condition',
        blockRuleTitle: 'Add to a list',
        blockRuleHint: 'write a rule future calls match',
        blockDebugTitle: 'Debug info',
        blockDebugHint: 'for reconciliation, not for daily use',
        riskWord: level => ({ low: 'low', medium: 'medium', high: 'high', critical: 'critical' }[level]),
        calloutLead: (verdict, riskWord) => (riskWord === undefined ? verdict : verdict + ' \u00b7 ' + riskWord + ' risk'),
        groupBasis: 'Basis',
        chipHit: label => 'matched ' + label,
        formScope: 'Scope',
        debugGroupAction: 'This action',
        debugGroupReview: 'Review & usage',
        reviewModel: 'Review model',
        appliedMerged: (count, labels) => ' (merged ' + String(count) + ' narrower rule(s) it covers'
          + (labels === '' || labels === undefined ? '' : ': ' + labels) + ')',
        appliedManual: 'Added with the condition you wrote',
        undoRule: 'Undo this add',
        ruleUndoLabel: 'Rule added',
        ruleDropped: labels => 'Displaced: ' + labels,
        ruleUndone: 'Undone; the list was restored',
        // no separate form title: every row carries its own visible label
        ruleKind: 'Match kind',
        ruleValue: 'Match value',
        ruleLabelField: 'Rule label',
        ruleDraftFromModel: 'prefilled from this review model suggestion - edit it freely',
        ruleDraftFromSignature: 'prefilled with this action\u2019s permission fingerprint (same action, different output truncation or description, still the same); switch to a command prefix to also cover other arguments',
        ruleDraftEdited: 'the value was refreshed for the kind you picked - edit it freely (anything after a | only shapes the output)',
        ruleDraftRegenerating: 'asking the model to regenerate a rule for the kind you picked...',
        ruleDraftRegenerated: 'the model regenerated a rule for the kind you picked - still editable',
        ruleDraftRegenFailed: 'the model could not regenerate this time (kept the locally derived value - still editable)',
        ruleNeedLabel: 'rule label must not be empty',
        ruleNeedValue: 'match value must not be empty',
        ruleNeedLongerPrefix: 'a prefix condition needs at least 3 characters',
        rulePathGlobHint: 'a path prefix takes one single-segment wildcard: D:/work/x/src/*.js matches only .js files directly in that directory',
        ruleNoDoubleStar: '** is not supported for path rules (cross-directory is too broad)',
        ruleNoOtherGlob: 'only * is supported as a wildcard (no ? or [])',
        ruleStarLastSegment: '* may only appear in the last path segment (the file name)',
        ruleCommandStarHint: '* in a command prefix is literal and never expands: that rule only matches calls whose command text literally contains tests/*. Shorten the prefix instead, e.g. pnpm vitest run',
        ruleKindUnavailable: kind => kind + ' cannot match this action (it carries no command/paths) - disabled',
        edit: 'Edit',
        saveEdit: 'Save',
        cancelEdit: 'Cancel',
        sourceUser: 'manual',
        sourceModel: 'model',
        sourceMemory: 'memory',
        kindSignature: 'permission fingerprint',
        // no separate "tool" row: the fingerprint row already starts with the tool name
        fingerprintCommand: 'Command',
        fingerprintArgs: 'Arguments',
        fingerprintExtra: 'Extra arguments',
        fingerprintReadonly: 'computed by the plugin and is not editable; switch to "command prefix" to cover other arguments of the same command',
        fingerprintLocked: 'a permission fingerprint cannot be typed in (it can only be generated from a timeline record)',
        copyFingerprint: 'Copy fingerprint',
        copiedFingerprint: 'full fingerprint copied',
        copyFingerprintFailed: 'cannot copy (no clipboard access here)',
        kindCommandPrefix: 'command prefix',
        kindPathPrefix: 'path prefix',
        settingsTitle: 'Approval policy',
        settingsDesc: 'Once the consecutive-approval threshold is reached the plugin adds the match condition to the allowlist automatically (no prompt); after the consecutive-denial threshold it still has the DSH model turn the action into a match condition and asks whether to add it to the denylist.',
        thresholdLabel: 'Consecutive approval threshold',
        thresholdLabelDeny: 'Consecutive denial threshold',
        thresholdHintAllow: 'allowlisted automatically after this many (no prompt)',
        thresholdHintDeny: 'ask to denylist after this many',
        thresholdUnit: 'times',
        ruleAskNote: 'Auto-approved calls and your own approvals (that includes clicking "allow once" over a model denial) both count as approvals; only a request that ends up unapproved counts as a denial. Counting looks at the command itself, ignoring the output plumbing after a |. The allowlist side is written automatically at the threshold; on the denylist side, after you answer "do not add" once, that action is never asked about again.',
        save: 'Save',
        saved: 'Saved',
        globalScope: 'Global (all projects)',
        projectScope: 'Project',
        allowList: 'Allowlist · allowed directly',
        denyList: 'Denylist · handed to the user',
        emptyList: '(empty)',
        remove: 'Remove',
        projectUnknown: 'No approval recorded in this session yet, so the project directory is unknown; project rules become manageable after the first approval in this session.',
        cardName: 'Auto Approve panel',
        placementTitle: 'Panel placement',
        placementDesc: 'Approval policy lives in the conversation tab, the approval timeline in the right sidebar (auto prefers the sidebar and falls back to the conversation tab)',
        noticeTitle: 'Inject approval results into the context',
        noticeHint: 'When off, approval results are never written into the model conversation (the timeline is unaffected)',
        denyDirectTitle: 'Reject on denylist',
        denyDirectHint: 'A denylist hit fails the tool call outright instead of opening a human approval card',
        autoOpenTitle: 'Open the approval timeline automatically',
        autoOpenHint: 'Expand the approval timeline when an approval just happened (within a minute); switching into a session that piled up unread records (away for over a minute, or more than 5 unread) also expands it once. Records found after switching sessions or reloading never pop, and it stays put while the timeline is visible or the sidebar is on another tool with our tab still open (closing the timeline tab yourself means the next approval reopens it) — everything else shows as the unread badge, which is **per session and counts only the session you are in**. This is a **global switch**: turning it off once stops the auto-open in every session, including new ones',
        unreadTitle: 'Unread approval records (cleared once you open the timeline or touch the UI)',
        askReasonTitle: 'Ask for a rejection reason',
        askReasonHint: 'After you reject an approval, the plugin asks for a reason and injects it into the model context (the model review note is the default answer)',
        saveFailed: 'Save failed',
        switchOn: 'on',
        switchOff: 'off',
        turnStep: 'Turn / step',
        turnStepLabel: (turn, step) => 'turn ' + String(turn) + ' · step ' + String(step),
        rejectReason: 'Rejection reason (user)',
        savedTip: 'Saved',
        placementAuto: 'Auto',
        placementTab: 'Policy only',
        placementSidebar: 'Timeline only',
        placementAll: 'Both',
        panelCardDesc: 'Where the panels live, plus four behaviour switches: inject approval results into the context, reject on a denylist hit, expand the approval timeline automatically while the sidebar is collapsed (it stays put when the timeline shows or another tool is on screen), and ask for a rejection reason after you reject one.',
        modelTitle: 'Review model',
        modelDesc: 'Which model reviews approvals, and the call parameters. Leave both provider and model empty to follow the current session; candidates come from the host model directory and you can always type a value.',
        modelProvider: 'Provider',
        modelProviderHint: 'Empty follows the current session',
        modelName: 'Model',
        modelEffort: 'Reasoning effort',
        modelEffortHint: 'Empty uses the model default',
        modelTimeout: 'Review timeout (ms)',
        modelTimeoutHint: 'Total budget for one review call',
        modelMaxTokens: 'Output limit (tokens)',
        modelMaxTokensHint: 'Maximum length of the review reply',
        modelPlaceholder: 'Focus the input for candidates, or type a value',
        modelClear: 'Clear',
        modelClearHint: 'Empty route fields follow the current session; empty effort uses the model default',
        modelSave: 'Save model settings',
        modelSaved: 'Model settings saved',
        modelNumbersInvalid: 'The review timeout and output limit must be positive integers',
        catalogLoading: 'Reading the host model directory…',
        catalogEmpty: 'The host model directory has no candidates (you can still type a value)',
        catalogUnavailable: 'The host exposes no model directory; candidates are unavailable (you can still type a value)',
      },
    }
    const t = COPY[ZH ? 'zh' : 'en']

    // ── 权限档位图标（盾牌 + A）──
    // DSH 客户端把档位图标硬编码给 read-only / workspace-write / danger-full-access 三个 id
    // （dsh-client-ui-permission-presets 的 permissionGlyphs，注释原话 host-configured names outside
    // the design set get none），宿主 presets.<id> 的 schema 也只有 {sandbox, approval, name, description}，
    // 所以自建档位拿不到矢量图标。这里用「给档位名所在的 span 打标记 + ::before + mask」补上：
    // 不改 React 的 DOM 结构、不依赖 DSH 的哈希类名，颜色跟文字走（currentColor），与内置单色图标一致。
    // **只补「本来就有图标位」的那两处（2026-10-08 用户要求）**：输入框那个 PermissionSelect 给内置三个
    // 档位渲染了文字前的图标（span.itemIcon 里装 svg），设置页的 PermissionRow 四种档位却是纯文字 ——
    // 设置页补进去就成了「只有自动审批一行长着图标」，与同排不一致，所以那里一个都不补。
    const PRESET_ICON_LABEL = '自动审批'
    const PRESET_ICON_CLASS = 'ap-presetGlyph'
    // 两套几何，**都照当前宿主（2.0.17）的 CSS 量**（2026-10-08 用户反馈「图标比别的档位大」，逐个核对了
    // 宿主源码）：chip 对齐 PermissionSelect 的 .triggerIcon（svg 14px、gap 4px、色跟 .trigger 的
    // label-secondary → currentColor）；菜单项对齐 Menu 的 .itemIcon（svg **14px**、色
    // var(--dsw-alias-menu-icon)、与 label 的间距取 .item 的 **gap:6px**）。旧版记的
    // 「菜单项 16px / 间距 8px / 三级文字色」是升级前那份宿主的量，已经过时——菜单里的图标因此偏大。
    // 变体写成**内联自定义属性**（见 applyPresetIconVars），不走「两个 class 比层叠」的路子 ——
    // 上一版就是菜单态那条规则没生效，菜单里的图标一直是 chip 的 14px。
    const PRESET_ICON_VARIANTS = Object.freeze({
      chip: Object.freeze({ box: '14px', icon: '14px', gap: '4px', color: 'currentColor' }),
      menu: Object.freeze({ box: '14px', icon: '14px', gap: '6px', color: 'var(--dsw-alias-menu-icon,currentColor)' }),
    })
    // 内联自定义属性名：写入（applyPresetIconVars）与撤销（unmarkPresetIcon）共用这一份，免得漏清一个
    const PRESET_ICON_VARS = Object.freeze({
      box: '--ap-glyph-box',
      icon: '--ap-glyph-icon',
      gap: '--ap-glyph-gap',
      color: '--ap-glyph-color',
    })
    // 几何**照抄宿主内置的 FullAccessArtwork**（盾牌轮廓逐字相同、viewBox 16、描边 1）：内置三个档位的
    // 图标在 14px 框里墨迹只占 ~80%×86%，上一版自绘的盾牌却占了 ~91%×98%（描边还粗到 1.32），真机上
    // 看着就是「比别家图标大一圈」（2026-10-08 用户反馈「字号调小一点，和其他类型的一样大小」）。
    // 中间那个 A 跟着收进盾牌内圈（宽 2.9 / 高 4.1，描边 1.25），整枚图标因此与内置图标同尺寸同重量。
    const PRESET_ICON_SVG = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">'
      + '<path d="M6.59624 2.14853C7.50155 1.80917 8.49914 1.80919 9.40444 2.14859L13.9245 3.84317V7.11961C13.9245 11.6089 10.5565 13.5975 8.00035 14.5779C5.44423 13.5975 2.07544 11.6089 2.07544 7.11961V3.84317L6.59624 2.14853Z" stroke="#fff" stroke-width="1" stroke-linejoin="round"/>'
      + '<path d="M6.55 10.45 8 6.35 9.45 10.45" stroke="#fff" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>'
      + '<path d="M7.15 8.95h1.7" stroke="#fff" stroke-width="1.25" stroke-linecap="round"/>'
      + '</svg>'
    // mask 走 data URI：encodeURIComponent 会连 # 与引号一起编码，避免 CSS 解析歧义
    const PRESET_ICON_MASK = 'url("data:image/svg+xml;charset=utf-8,' + encodeURIComponent(PRESET_ICON_SVG) + '")'

    /**
     * 是否是承载档位名的元素：按文字精确匹配，不依赖 DSH 的哈希类名（客户端升级也不怕）。
     * **不看有没有打过标记**：标记与撤销是同一遍重扫里的两步（见 mark），靠「有标记就跳过」判定的话，
     * 切换档位后 React 复用的那个 span 永远撤不掉旧图标（2026-10-08 用户反馈的「图标带过去」）。
     * @param {*} node 待判定元素
     * @param {string} label 档位显示名
     * @returns {boolean} 命中则返回 true
     */
    function isPresetLabelNode(node, label) {
      if (node === null || typeof node !== 'object') { return false }
      if (node.tagName !== 'SPAN') { return false }
      if (typeof node.textContent !== 'string' || node.textContent.trim() !== label) { return false }
      // 只认「纯文字」span：里面有元素就不是档位名（例如我们自己面板里的文案）
      if (node.children !== undefined && node.children !== null && node.children.length > 0) { return false }
      // 拿不到 classList 的元素挂不上标记，直接不当候选
      return node.classList !== undefined && node.classList !== null && typeof node.classList.contains === 'function'
    }

    /**
     * 这个 span 属于哪一处宿主：chip 的按钮带 aria-label（访问模式，当前：<档位名>），菜单项是 role=menuitem。
     * @param {*} node 档位名所在的 span
     * @returns {'chip'|'menu'} 变体名
     */
    function presetIconVariant(node) {
      const owner = typeof node.closest === 'function' ? node.closest('button') : null
      if (owner !== null && owner !== undefined && typeof owner.getAttribute === 'function') {
        const label = owner.getAttribute('aria-label')
        if (typeof label === 'string' && label.includes(PRESET_ICON_LABEL)) { return 'chip' }
      }
      return 'menu'
    }

    /**
     * 把变体写成内联自定义属性：CSS 里只有一条规则读这些变量，谁也不会覆盖谁。
     * @param {*} node 档位名所在的 span
     * @param {'chip'|'menu'} variant 变体名
     * @returns {void} 无返回值；拿不到 style（测试替身）时跳过
     */
    function applyPresetIconVars(node, variant) {
      const spec = PRESET_ICON_VARIANTS[variant]
      if (node.style === undefined || node.style === null || typeof node.style.setProperty !== 'function') { return }
      for (const key of Object.keys(PRESET_ICON_VARS)) {
        node.style.setProperty(PRESET_ICON_VARS[key], spec[key])
      }
    }

    /**
     * 元素里是否含 svg（只看元素子节点，递归）：判断一个菜单里的行有没有设计图标用。
     * @param {*} node 待检查元素
     * @returns {boolean} 含 svg 则 true
     */
    function holdsSvg(node) {
      const kids = node === null || node === undefined ? undefined : node.children
      if (kids === undefined || kids === null) { return false }
      for (let index = 0; index < kids.length; index += 1) {
        const kid = kids[index]
        if (kid === null || kid === undefined) { continue }
        if (String(kid.tagName).toLowerCase() === 'svg') { return true }
        if (holdsSvg(kid) === true) { return true }
      }
      return false
    }

    /**
     * 这个档位名所在的菜单，行里是否自带设计图标（图标 span 在文字之前）。
     * 输入框那个 PermissionSelect 给内置三个档位各渲染一个装着 svg 的 span.itemIcon，设置页的
     * PermissionRow 四种档位只有纯文字 —— 只给前者补图标，设置页里才不会「一行有图标、三行没有」。
     * 选中态的对勾 svg 是按钮的直接子节点、不裹在 span 里，所以不会被当成设计图标。
     * @param {*} node 档位名所在的 span
     * @returns {boolean} 该菜单里有行自带图标则 true
     */
    function menuCarriesIcons(node) {
      const menu = typeof node.closest === 'function' ? node.closest('[role="menu"]') : null
      if (menu === null || menu === undefined || typeof menu.querySelectorAll !== 'function') { return false }
      for (const span of menu.querySelectorAll('button[role="menuitem"] > span')) {
        if (holdsSvg(span) === true) { return true }
      }
      return false
    }

    /**
     * 这个 span 现在该不该有图标：chip 一律补（内置图标位就是缺的），菜单项只在「同排本来就有图标」时补。
     * @param {*} node 档位名所在的 span
     * @returns {boolean} 该补则 true
     */
    function wantsPresetIcon(node) {
      if (isPresetLabelNode(node, PRESET_ICON_LABEL) === false) { return false }
      if (presetIconVariant(node) === 'chip') { return true }
      return menuCarriesIcons(node)
    }

    /**
     * 抹掉一次标记：去掉 class 与内联变量。切换档位时 React 复用同一个 span、只改写里面的文本，
     * 不撤销的话「自动审批」的图标会跟着新档位留在 chip 上（2026-10-08 用户反馈）。
     * @param {*} node 已打标记的 span
     * @returns {void} 无返回值
     */
    function unmarkPresetIcon(node) {
      if (node.classList !== undefined && node.classList !== null && typeof node.classList.remove === 'function') {
        node.classList.remove(PRESET_ICON_CLASS)
      }
      const style = node.style
      if (style === undefined || style === null || typeof style.removeProperty !== 'function') { return }
      for (const name of Object.values(PRESET_ICON_VARS)) { style.removeProperty(name) }
    }

    /**
     * 给权限档位名补图标：只在档位 chip 与「本来就有图标位」的下拉菜单里找，DOM 变动时重扫
     * （React 重建节点会丢标记）；同一遍里把不再该有的标记撤掉（切换档位时同一个 span 的文本被改写）。
     * @returns {void} 无返回值；浏览器环境缺失（测试/SSR）时直接退出
     */
    function installPresetIcon() {
      if (typeof document === 'undefined' || typeof MutationObserver === 'undefined') { return }
      if (document.body === undefined || document.body === null) { return }
      let scheduled = false
      // 覆盖两处宿主：输入框上方的档位 chip 与弹出的菜单项。composer 的 trigger 只带 aria-label
      // （菜单原语不会给 anchor 补 aria-haspopup），所以连 button span 一起匹配 —— 反正
      // isPresetLabelNode 按文字精确过滤，选择器放宽不会误伤。
      const selector = '[role="menu"] span,[role="menuitem"] span,[aria-haspopup="menu"] span,'
        + 'button span,[aria-label*="' + PRESET_ICON_LABEL + '"] span'
      // 每处宿主只回报一次：把浏览器算出来的几何写进宿主日志，便于「看着不对」时直接核对
      const reported = new Set()
      // 撤销也只在每种文本上回报一次：真机核对「切走档位后图标确实撤掉了」用
      const cleared = new Set()
      /**
       * 回报一次该 span 的 ::before 实际几何（宽 / 右间距 / 图标色）。
       * @param {*} node 档位名所在的 span
       * @param {string} variant 变体名
       * @returns {void} 无返回值
       */
      const report = (node, variant) => {
        if (reported.has(variant) || typeof getComputedStyle !== 'function') { return }
        reported.add(variant)
        try {
          const before = getComputedStyle(node, '::before')
          const own = getComputedStyle(node)
          // 对齐相关的量都给出来：图标宽高、行高、display、gap、图标色 —— 真机上「看着不对」时按这几个值核对
          beacon('preset-icon', variant + ' w=' + String(before.width) + ' h=' + String(before.height)
            + ' gap=' + String(own.gap) + ' disp=' + String(own.display) + ' lineH=' + String(own.lineHeight)
            + ' color=' + String(before.backgroundColor))
        } catch (error) {
          // 计算样式拿不到只影响回报，不影响图标本身
        }
      }
      /** 撤销时回报一次（不含几何：这里的重点是「切走档位后标记确实被撤了」）。 */
      const reportClear = (node) => {
        const text = String(node.textContent === undefined ? '' : node.textContent).slice(0, 32)
        if (cleared.has(text) === true) { return }
        cleared.add(text)
        beacon('preset-icon', 'clear text=' + text)
      }
      /**
       * 重扫一遍：该补的补、该撤的撤。撤销这一遍不能省 —— 切换档位不是换节点，
       * 而是把 chip 里那个 span 的文本改写成新档位名，旧的标记会原样留在上面。
       */
      const mark = () => {
        for (const node of document.querySelectorAll(selector)) {
          if (wantsPresetIcon(node) === false) { continue }
          const variant = presetIconVariant(node)
          // 先写变量再挂 class：class 一挂上规则就生效，不会出现「先按默认值渲染一帧」的闪烁
          applyPresetIconVars(node, variant)
          if (node.classList.contains(PRESET_ICON_CLASS) === false) { node.classList.add(PRESET_ICON_CLASS) }
          report(node, variant)
        }
        for (const node of document.querySelectorAll('.' + PRESET_ICON_CLASS)) {
          if (wantsPresetIcon(node) === true) { continue }
          unmarkPresetIcon(node)
          reportClear(node)
        }
      }
      /** 合并同一帧内的多次变动：会话流式渲染时 DOM 变动很密集，避免反复全量查询。 */
      const schedule = () => {
        if (scheduled === true) { return }
        scheduled = true
        const run = () => { scheduled = false; mark() }
        if (typeof requestAnimationFrame === 'function') { requestAnimationFrame(run) }
        else { Promise.resolve().then(run) }
      }
      mark()
      // childList 管节点增删，characterData 管「切换档位时 label 文本被改写」——那是同一个 span
      // 的文本节点变化，不观察它就永远补不上图标。加 class 不在观察范围内（未开 attributes），不会自激。
      new MutationObserver(schedule).observe(document.body, { childList: true, characterData: true, subtree: true })
    }

    // ── 幂等样式注入（带 id，卸载残留可重复注入）──
    if (typeof document !== 'undefined' && document.getElementById('dsh-auto-pass-style') === null) {
      const tag = document.createElement('style')
      tag.id = 'dsh-auto-pass-style'
      tag.textContent = [
        // box-sizing 只写在 .ap-root 上是不会被子元素继承的：面板里凡「width:100% + 内边距」的盒子
        // 在 content-box 下都会把内边距加到宽度之外（实测折叠行因此超出 100%）——面板内部统一 border-box
        '.ap-root,.ap-root *{box-sizing:border-box}',
        '.ap-root{flex:auto;min-height:0;height:100%;display:flex;flex-direction:column;color:var(--dsw-alias-label-primary);font-size:13px}',
        // 对话区面板：内容列与消息列同宽并居中（--dsh-chat-content-width 由会话根元素下发，取不到时回退 748px）
        // 右侧栏 chip 标题：图标 + 文案（标题席位 key 与 tab id 同名）
        '.ap-tabTitle{display:inline-flex;align-items:center;gap:6px;min-width:0}',
        '.ap-tabLabel{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
        // 未读角标：挂在标题席位上——侧栏停在别的工具上 / 审批发生在别的会话时的唯一提示
        '.ap-tabBadge{flex:none;min-width:16px;height:16px;padding:0 5px;border-radius:8px;background:var(--dsw-alias-state-business-primary);color:#fff;font-size:11px;line-height:16px;text-align:center;font-variant-numeric:tabular-nums}',
        '.ap-frame{flex:auto;min-height:0;overflow-y:auto;padding:16px calc(var(--dsh-composer-side-clearance,16px) + 16px) 24px;display:flex;flex-direction:column;align-items:center}',
        '.ap-col{width:100%;max-width:var(--dsh-chat-content-width,748px);display:flex;flex-direction:column;gap:12px}',
        // 卡片外观对齐设置页内置插件卡（.TKtcza_card）：.5px 描边 + 层三底色 + 16px 圆角
        '.ap-card{box-sizing:border-box;border:.5px solid var(--dsw-alias-border-l4);background:var(--dsw-alias-bg-layer-3);border-radius:16px;list-style:none}',
        '.ap-cardHead{padding:14px 16px 0}',
        '.ap-cardText{display:flex;flex-direction:column;gap:4px;min-width:0}',
        '.ap-cardName{color:var(--dsw-alias-label-primary);font-size:15px;font-weight:600;line-height:1.4}',
        '.ap-cardDesc{color:var(--dsw-alias-label-tertiary);font-size:13px;line-height:1.5}',
        '.ap-cardBody{border-top:.5px solid var(--dsw-alias-border-l2);margin:12px 16px 0;padding:12px 0 14px;display:flex;flex-direction:column;gap:10px;min-width:0}',
        '.ap-head{flex:none;display:flex;align-items:center;gap:8px;padding:10px 12px;border-bottom:1px solid var(--dsw-alias-border-l1)}',
        '.ap-title{font-size:13px;font-weight:600;line-height:20px}',
        '.ap-sub{color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px}',
        '.ap-grow{flex:auto;min-width:0}',
        '.ap-seg{display:flex;flex:none;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;overflow:hidden}',
        '.ap-seg button{appearance:none;border:0;background:0 0;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;line-height:18px;padding:2px 8px;cursor:pointer}',
        '.ap-seg button+button{border-left:1px solid var(--dsw-alias-border-l1)}',
        '.ap-seg button[data-on="1"]{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary)}',
        '.ap-btn{appearance:none;flex:none;border:1px solid var(--dsw-alias-border-l1);background:0 0;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;line-height:18px;border-radius:8px;padding:2px 8px;cursor:pointer}',
        '.ap-btn:hover{border-color:var(--dsw-alias-label-dimmed)}',
        '.ap-btn:disabled{opacity:.5;cursor:default}',
        '.ap-btnPrimary{color:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}',
        '.ap-btnDanger{color:var(--dsw-alias-state-warn-primary);border-color:var(--dsw-alias-state-warn-primary)}',
        // 快捷筛选条：多选 chip（命中名单两类 + 决策来源两类），每个 chip 后面跟当前范围内的条数
        '.ap-filters{flex:none;display:flex;flex-wrap:wrap;gap:6px;padding:8px 12px;border-bottom:1px solid var(--dsw-alias-border-l1)}',
        '.ap-chip{appearance:none;display:inline-flex;align-items:center;gap:4px;border:1px solid var(--dsw-alias-border-l1);background:0 0;color:var(--dsw-alias-label-secondary);font:inherit;font-size:11px;line-height:16px;border-radius:8px;padding:2px 8px;cursor:pointer}',
        '.ap-chip:hover{border-color:var(--dsw-alias-label-dimmed)}',
        '.ap-chip[data-on="1"]{border-color:var(--dsw-alias-state-business-primary);color:var(--dsw-alias-state-business-primary)}',
        '.ap-chipCount{color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}',
        '.ap-chip[data-on="1"] .ap-chipCount{color:inherit}',
        // 时间线列表（用户 2026-09-18 从预览页定稿）：左侧 18px 轨道列（竖线 + 按结论着色的圆点）
        // + 内容列；按天分组的标题占整行。记录之间用**内边距**留白——用外边距的话竖线会在缝隙处断开
        // 列表自身留出左右 12px 边距（与头部/筛选条对齐）：轨道、按天分组、展开的整块背景与分割线
        // 都以它为界，不再贴着面板边缘（用户 2026-09-18：两侧边距再大一点）
        '.ap-list{flex:auto;min-height:0;overflow-y:auto;margin:0;padding:2px 12px 12px;list-style:none}',
        // 每条记录都铺一个圆角块（::before，见下面展开那条的说明）：平时透明，
        // hover 时浮现（带过渡）、展开时常驻——所以 hover 的底色天然把轨道和圆点一起包进去
        '.ap-item{position:relative;isolation:isolate;display:grid;grid-template-columns:18px 1fr}',
        '.ap-item::before{content:"";position:absolute;left:0;right:0;top:0;bottom:8px;border-radius:8px;background:0 0;z-index:-1;transition:background-color .15s ease}',
        '.ap-item:not(.gap)::before{bottom:0}',
        '.ap-item:hover::before,.ap-item.open::before{background:var(--dsw-alias-bg-layer-2)}',
        '.ap-item.gap{padding-bottom:8px}',
        '.ap-rail{position:relative}',
        '.ap-railLine{position:absolute;left:8px;top:0;bottom:0;width:1px;background:var(--dsw-alias-border-l2)}',
        '.ap-item.isFirst .ap-railLine{top:14px}',
        '.ap-item.isLast .ap-railLine{bottom:auto;height:14px}',
        // 圆点的尺寸与光环都带过渡：展开时放大到 10px、hover 时光环跟着块的底色走
        '.ap-dot{position:absolute;left:5px;top:12px;width:7px;height:7px;border-radius:50%;background:var(--dsw-alias-label-tertiary);box-shadow:0 0 0 3px var(--dsw-alias-bg-layer-3);transition:width .15s ease,height .15s ease,left .15s ease,top .15s ease,background-color .15s ease,box-shadow .15s ease}',
        '.ap-dot[data-tone="ok"]{background:var(--dsw-alias-state-success-primary)}',
        '.ap-dot[data-tone="warn"]{background:var(--dsw-alias-state-warn-primary)}',
        '.ap-dot[data-tone="dim"]{background:var(--dsw-alias-border-l4)}',
        '.ap-item:hover .ap-dot,.ap-item.open .ap-dot{box-shadow:0 0 0 3px var(--dsw-alias-bg-layer-2)}',
        '.ap-dayGroup{padding:6px 0 4px;color:var(--dsw-alias-label-tertiary);font-size:10px;line-height:14px;letter-spacing:.04em;border-top:1px solid var(--dsw-alias-border-l1);margin-top:4px}',
        '.ap-body{min-width:0}',
        // 折叠行：时间紧贴圆点（行内左右边距由列表与详情的留白统一给，也不再放展开箭头——整行就是按钮）
        // width:100% 必须保留：.ap-rowHead 是 <button>，button 的宽度默认按内容收缩（不像块级元素那样撑满），
        // 删掉它会让行尾徽标组全部失去右对齐（margin-left:auto 没有空间可用）；
        // 面板已统一 border-box，100% + 内边距不会再溢出
        '.ap-rowHead{width:100%;appearance:none;border:0;background:0 0;font:inherit;text-align:left;color:inherit;display:flex;align-items:flex-start;padding:7px 10px 7px 0;cursor:pointer}',
        '.ap-time{flex:none;color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums;font-size:11px;line-height:16px}',
        '.ap-tool{flex:none;font-family:var(--dsw-font-family-mono,ui-monospace,monospace);font-size:12px}',
        '.ap-badge{flex:none;border-radius:8px;padding:0 6px;font-size:11px;line-height:16px}',
        '.ap-badgeOk{color:var(--dsw-alias-state-success-primary);background:var(--dsw-alias-state-success-tertiary)}',
        '.ap-badgeWarn{color:var(--dsw-alias-state-warn-primary);background:var(--dsw-alias-state-warn-tertiary)}',
        '.ap-badgeMuted{color:var(--dsw-alias-label-tertiary);background:var(--dsw-alias-bg-base)}',
        // 「自动」标签用业务色，「人工」标签用中性色：与命中名单的绿/黄区分开
        '.ap-badgeInfo{color:var(--dsw-alias-state-business-primary);background:var(--dsw-alias-state-business-tertiary)}',
        // 展开的那条记录（用户 2026-09-18 定）：背景块常驻（hover 规则已统一到上面），行头保持透明；
        // 行头与详情之间只留一条分割线，且这条线整条跨过去（详情用负 margin 顶到列表内容区的左边缘，
        // 再用 padding 推回内容列）。背景画在 ::before 上而不是给 li 染色：li 的高度含下面 8px 记录间隔，
        // 直接染会和下一条糊在一起。
        '.ap-item.open .ap-rowHead{background:0 0}',
        // 圆点展开时放大（尺寸/光环的过渡见 .ap-dot）
        '.ap-item.open .ap-dot{left:3.5px;top:10.5px;width:10px;height:10px}',
        // 详情：内容与右边缘之间留 10px（用户 2026-09-18：结论条、两张卡都顶着最右边了）；
        // 展开时淡入 + 轻微下滑（只作用于插入那一刻，轮询重渲染不会重播）
        '.ap-detailBox{display:flex;flex-direction:column;gap:4px;border-top:1px solid var(--dsw-alias-border-l1);padding:8px 10px 10px 18px;margin:0 0 0 -18px;min-width:0;animation:ap-detail-in .18s ease}',
        '@keyframes ap-detail-in{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}',
        '.ap-field{display:flex;gap:6px;align-items:baseline}',
        '.ap-fieldKey{flex:none;min-width:5.5em;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px}',
        '.ap-fieldVal{min-width:0;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;overflow-wrap:anywhere;white-space:pre-wrap}',
        '.ap-mono{font-family:var(--dsw-font-family-mono,ui-monospace,monospace);font-size:11px}',
        '.ap-empty{color:var(--dsw-alias-label-tertiary);padding:16px 12px}',
        '.ap-error{color:var(--dsw-alias-state-warn-primary);padding:6px 12px;font-size:11px}',
        // 记录详情的操作区：竖着一行一行来（规则编辑器一行、两个操作各一行、状态提示一行），
        // 之前是一整排 flex-wrap，控件一多就横七竖八（用户反馈「按钮排版好乱」）
        '.ap-actions{display:flex;flex-direction:column;gap:6px;align-items:flex-start;padding-top:4px;min-width:0}',
        // 表单提示（指纹只读 / 草稿来源 / 通配符口径 / 校验错误）：挤成一小块，行距比控件之间更紧
        '.ap-hints{display:flex;flex-direction:column;gap:2px;min-width:0}',
        '.ap-actionRow{display:flex;flex-wrap:wrap;align-items:center;gap:6px;width:100%;min-width:0}',
        '.ap-actionsLabel{flex:none;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px;min-width:5.5em}',
        '.ap-note{color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px}',
        '.ap-warn{color:var(--dsw-alias-state-warn-primary)}',
        // 「这次写没写规则」卡：一件事一个落点（用户 2026-09-18），撤销按钮贴着它撤销的那条规则
        '.ap-ruleCard{display:flex;flex-direction:column;gap:4px;border:.5px solid var(--dsw-alias-border-l2);border-radius:8px;padding:6px 8px;margin-top:2px;min-width:0}',
        '.ap-ruleCardMuted{color:var(--dsw-alias-label-tertiary)}',
        // 「标签优先」（用户 2026-09-18 选定）：规则标签独占一行且加粗，badge 让到下一行
        '.ap-ruleCardLabel{min-width:0;color:var(--dsw-alias-label-primary);font-size:12px;font-weight:600;line-height:18px;overflow-wrap:anywhere}',
        // 结论条（用户 2026-09-18 从预览页选定「融合版」）：结论 + 风险/授权/命中/连续计数一眼可见
        '.ap-callout{display:flex;flex-direction:column;gap:4px;padding:7px 9px;border-radius:8px;margin-top:2px}',
        '.ap-callout[data-tone="ok"]{background:var(--dsw-alias-state-success-tertiary)}',
        '.ap-callout[data-tone="warn"]{background:var(--dsw-alias-state-warn-tertiary)}',
        '.ap-calloutTop{display:flex;align-items:center;gap:6px;flex-wrap:wrap;min-width:0}',
        '.ap-calloutLead{font-size:12px;font-weight:600;line-height:18px}',
        '.ap-callout[data-tone="ok"] .ap-calloutLead{color:var(--dsw-alias-state-success-primary)}',
        '.ap-callout[data-tone="warn"] .ap-calloutLead{color:var(--dsw-alias-state-warn-primary)}',
        // chip 的值可能很长（命中名单带标签），单行截断 + title 挂全文
        '.ap-kvChip{flex:none;max-width:100%;font-size:11px;line-height:16px;padding:0 6px;border-radius:8px;background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
        // 「依据」分组：小标题 + 1px 分隔线，与上面的结论条分开（别再糊成一坨）
        '.ap-group{display:flex;flex-direction:column;gap:4px;padding-top:6px;border-top:1px solid var(--dsw-alias-border-l1);margin-top:2px;min-width:0}',
        '.ap-groupCaption{color:var(--dsw-alias-label-tertiary);font-size:10px;line-height:14px;letter-spacing:.04em}',
        // 「加入名单」/「排查信息」两块（用户 2026-09-18 最终定「卡头即入口」）：卡头行本身就是开关，
        // 行尾一个 ▸/▾，内容展开时才渲染——底部不再有第二处文字入口
        '.ap-blockCard{display:flex;flex-direction:column;gap:5px;width:100%;border:.5px solid var(--dsw-alias-border-l2);border-radius:8px;padding:7px 8px;margin-top:6px;min-width:0}',
        '.ap-blockHead{appearance:none;border:0;background:0 0;color:inherit;font:inherit;width:100%;display:flex;align-items:baseline;gap:6px;padding:0;cursor:pointer;text-align:left;min-width:0}',
        '.ap-blockHead:hover .ap-blockTitle{color:var(--dsw-alias-label-primary)}',
        '.ap-blockTitle{flex:none;color:var(--dsw-alias-label-secondary);font-size:11px;font-weight:600;line-height:16px}',
        '.ap-blockHint{min-width:0;color:var(--dsw-alias-label-tertiary);font-size:10px;line-height:16px;overflow-wrap:anywhere}',
        // 行尾箭头（内联 SVG）：展开时旋转 90°（transition 让开合有动画），颜色跟随卡头的 hover 变化
        '.ap-blockChevron{flex:none;align-self:center;margin-left:auto;color:var(--dsw-alias-label-tertiary);transition:transform .15s ease}',
        '.ap-blockHead[aria-expanded="true"] .ap-blockChevron{transform:rotate(90deg)}',
        // 「排查信息」展开后的字段区：缩进一层 + 左侧细线，不与上面的决定依据抢视觉
        '.ap-debugBody{display:flex;flex-direction:column;gap:6px;padding-left:10px;border-left:2px solid var(--dsw-alias-border-l1);min-width:0}',
        // 两个分组（用户 2026-09-18 从预览页选定）：这次动作 / 审查与用量——把 13 行平铺改成两组
        '.ap-debugGroup{display:flex;flex-direction:column;gap:3px;min-width:0}',
        '.ap-debugGroupCaption{color:var(--dsw-alias-label-tertiary);font-size:10px;line-height:14px;letter-spacing:.04em}',
        // 指纹值 + 「复制指纹」按钮（排查区也能一键复制整串；长串单行截断，整串仍挂在 title 上）
        '.ap-fingerprintValue{display:inline-flex;align-items:center;gap:6px;min-width:0;max-width:100%}',
        '.ap-fingerprintShort{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
        // 表单里的指纹值走「折行全显示」（用户 2026-09-18 从预览页选定，候选A）：.ap-field 是 fit-content
        // 的 flex 行，里面那句 max-width:100% 在这种容器里不生效——真机上长指纹会溢出卡片右缘，把
        // 「复制指纹」整个挤出卡外（截图复现）。所以值那一行必须是**宽度确定**的行（ap-fieldFill），
        // 值自己占满一行再折行（ap-fingerprintText），按钮因此永远留在卡内。
        '.ap-fieldFill{width:100%;min-width:0;align-items:flex-start}',
        '.ap-fieldFill>.ap-fieldKey{padding-top:2px}',
        '.ap-fingerprintWrap{display:flex;flex-wrap:wrap;align-items:center;gap:6px;min-width:0;max-width:100%}',
        '.ap-fingerprintText{flex:1 1 100%;min-width:0;white-space:normal;overflow-wrap:anywhere}',
        '.ap-rowMain{flex:auto;min-width:0;display:flex;flex-direction:column;gap:1px}',
        '.ap-rowTop{display:flex;align-items:center;gap:6px;min-width:0}',
        // 行尾徽标组（自动写入标识 + 结论 + 结果）：margin-left:auto 顶到最右——
        // 不用空的 grow span 撑开，那个空元素在真机上被宿主样式影响过（结论徽标不贴右）
        '.ap-rowBadges{flex:none;display:inline-flex;align-items:center;gap:6px;margin-left:auto;min-width:0}',
        '.ap-opinion{min-width:0;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;text-align:left;overflow:hidden;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical}',
        // 规则卡里的 chip 行（作用域 + 条件来源）；折叠行的来源 chip 已经并进行头第一行
        '.ap-hitRow{display:flex;align-items:center;flex-wrap:wrap;gap:6px;min-width:0}',
        '.ap-sectionTitle{font-size:12px;font-weight:600;line-height:18px}',
        '.ap-subTitle{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;margin-top:4px}',
        '.ap-ruleList{list-style:none;margin:4px 0 0;padding:0;display:flex;flex-direction:column;gap:4px}',
        '.ap-rule{display:flex;align-items:baseline;gap:6px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:4px 6px}',
        '.ap-ruleLabel{min-width:0;flex:auto;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;overflow-wrap:anywhere}',
        '.ap-input{appearance:none;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:0 0;color:inherit;font:inherit;font-size:12px;line-height:18px;padding:2px 8px;width:5em}',
        // 规则编辑器（时间线的「加入名单的规则」与设置面板的编辑行）：条件分段按钮 + 值 + 标签一行，
        // 说明与校验提示另起一行（挤在同一行会盖住按钮）。条件不用原生 <select>：它的弹层在深色主题下白底黑字
        '.ap-ruleEditor{display:flex;flex-wrap:wrap;align-items:center;gap:6px;width:100%;min-width:0}',
        '.ap-ruleEditorRow{flex:1}',
        '.ap-inputWide{width:auto;flex:1;min-width:10em}',
        // 数字输入（审查超时 / 输出上限）：比通用 ap-input 宽，六位数也看得全
        '.ap-inputNum{width:8em;flex:none}',
        // 候选输入（审查模型的提供方 / 模型 / 思考强度）：可搜候选 + 可手填，候选列在输入框下方
        '.ap-combo{display:flex;flex:1;min-width:0;gap:6px;align-items:center}',
        '.ap-comboMenu{border:1px solid var(--dsw-alias-border-l1);border-radius:8px;background:var(--dsw-alias-bg-layer-3);max-height:180px;overflow:auto;display:flex;flex-direction:column;min-width:0}',
        '.ap-comboMenu button{appearance:none;border:0;background:0 0;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;line-height:18px;padding:4px 8px;text-align:left;cursor:pointer;overflow-wrap:anywhere}',
        '.ap-comboMenu button:hover{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary)}',
        '.ap-row2{display:flex;align-items:center;gap:8px;flex-wrap:wrap}',
        // 开关：轨道 + 滑块。状态由原生 checkbox 承载（无障碍与键盘可用），轨道随 :checked 变色。
        // 选择器用「input + track」的兄弟关系，不依赖 label 包裹。
        '.ap-switch{flex:none;display:inline-flex;align-items:center;gap:8px;cursor:pointer}',
        '.ap-switchInput{position:absolute;opacity:0;width:0;height:0;margin:0}',
        '.ap-switchTrack{flex:none;position:relative;width:32px;height:18px;border-radius:9px;background:var(--dsw-alias-bg-layer-2);border:.5px solid var(--dsw-alias-border-l3)}',
        '.ap-switchTrack::after{content:"";position:absolute;top:2px;left:2px;width:12px;height:12px;border-radius:50%;background:var(--dsw-alias-label-tertiary)}',
        '.ap-switchInput:checked+.ap-switchTrack{background:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}',
        '.ap-switchInput:checked+.ap-switchTrack::after{transform:translateX(14px);background:var(--dsw-alias-bg-layer-3)}',
        '.ap-switchInput:focus-visible+.ap-switchTrack{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:2px}',
        '.ap-switchInput:disabled+.ap-switchTrack{opacity:.5}',
        '.ap-switchText{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;min-width:1.5em}',
        // 档位名字前面的「盾牌 + A」：只挂在「本来就有图标位」的地方（输入框 chip 与它的下拉菜单；设置页的
        // 权限菜单是纯文字，一个都不挂），几何全部走 --ap-glyph-* 变量（chip 14/4/currentColor，菜单项 16/8/三级色），
        // 变量由 applyPresetIconVars 内联写在 span 上、unmarkPresetIcon 负责清掉；mask 用 longhand，避免简写与变量混在一起出歧义
        `.${PRESET_ICON_CLASS}{display:inline-flex;align-items:center;gap:var(--ap-glyph-gap,4px)}`,
        // 图标本体：尺寸全走 --ap-glyph-* 变量；用 flex 的 align-items:center 对齐，和内置 itemIcon / triggerIcon 同一套机制（之前用 vertical-align 手调，真机上差了 2px）
        `.${PRESET_ICON_CLASS}::before{content:"";flex:none;width:var(--ap-glyph-box,14px);height:var(--ap-glyph-box,14px);background-color:var(--ap-glyph-color,currentColor);-webkit-mask-image:${PRESET_ICON_MASK};mask-image:${PRESET_ICON_MASK};-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;-webkit-mask-size:var(--ap-glyph-icon,14px) var(--ap-glyph-icon,14px);mask-size:var(--ap-glyph-icon,14px) var(--ap-glyph-icon,14px)}`,
        // 审批卡首行：DSH 把 pending.reason 放进一个纯文本 div，默认 white-space 会把我
        // 们写入的换行折叠成空格；这里打开换行，让「原有信息 / 空行 / 模型审批意见」分行。
        // 选择器只认官方卡片的 data-approval-key 属性（稳定），不依赖它的哈希类名。
        '[data-approval-key] *{white-space:pre-wrap}',
      ].join('\n')
      ;(document.head || document.documentElement).appendChild(tag)
    }
    /** 记录图标：一个带勾的时间轴时钟，用于引导页胶囊。 */
    function LogGlyph({ size }) {
      const edge = typeof size === 'number' && size > 0 ? size : 16
      return react.createElement('svg', {
        width: edge, height: edge, viewBox: '0 0 16 16', fill: 'none',
        stroke: 'currentColor', strokeWidth: '1.3', strokeLinecap: 'round', strokeLinejoin: 'round',
        'aria-hidden': 'true',
      },
        react.createElement('circle', { cx: '6.6', cy: '6.6', r: '4.6' }),
        react.createElement('path', { d: 'M6.6 4.3v2.4l1.7 1' }),
        react.createElement('path', { d: 'M11.4 12.4l1.5 1.5 2.4-2.9' }))
    }

    /**
     * 界面偏好状态：唯一真值在宿主（config 默认值 + 设置命名空间覆盖）。
     * placement 决定面板挂在哪里（变更会广播出去重新挂载），notice / denyDirect 是两个行为开关
     * （关掉通知注入、开启黑名单直接拒绝）。设置页卡片与审批设置面板共用这一份状态。
     * **「自动打开审批时间线」是一个全局开关**（2026-10-09 用户要求，此前按会话 / 按工作区）：
     * 它就在这份 store 的 `autoOpenTimeline` 里，面板与设置页卡片写的是同一个值（插件行 config），
     * 所有会话（含以后新建的）跟随它——不再有「本会话单独设过」的隐藏状态。
     */
    const runtimeStore = {
      placement: 'all',
      notice: true,
      denyDirect: false,
      // 自动打开审批时间线（全局，默认开）
      autoOpenTimeline: true,
      // 人工拒绝后追问一句拒绝理由（默认开）
      askRejectReason: true,
      // 审查模型配置（面板可写）：路由空串 = 跟随当前会话，思考强度空串 = 用模型默认。
      // 默认值与服务端 DEFAULTS 对齐（拿不到宿主回执时就是这个）
      model: {
        reviewerProvider: '',
        reviewerModel: '',
        reviewerReasoningEffort: '',
        timeoutMs: 90_000,
        maxOutputTokens: 2_048,
      },
      writable: false,
      listeners: new Set(),
      subscribe(listener) {
        this.listeners.add(listener)
        return () => { this.listeners.delete(listener) }
      },
      /** 广播变更；placement 变化时把新值一并交给监听者（挂载逻辑要用它）。 */
      emit() {
        for (const listener of [...this.listeners]) listener(this.placement)
      },
      /** 把宿主回执（`settings` 全局）套用到本地状态；认不出的值保持原样。 */
      apply(payload) {
        if (payload === null || typeof payload !== 'object') return
        // 兼容只给 settings 的老形状（宿主两处出口现在都给整个回执）
        const settings = payload.settings !== null && typeof payload.settings === 'object' ? payload.settings : payload
        if (typeof settings.placement === 'string' && PLACEMENTS.includes(settings.placement)) {
          this.placement = settings.placement
        }
        if (typeof settings.notice === 'boolean') this.notice = settings.notice
        if (typeof settings.denyDirect === 'boolean') this.denyDirect = settings.denyDirect
        if (typeof settings.autoOpenTimeline === 'boolean') this.autoOpenTimeline = settings.autoOpenTimeline
        if (typeof settings.askRejectReason === 'boolean') this.askRejectReason = settings.askRejectReason
        // 审查模型配置：老宿主回执没有 model 段，缺失的键保持原值
        const model = payload.model !== null && typeof payload.model === 'object' ? payload.model : undefined
        if (model !== undefined) {
          this.model = {
            reviewerProvider: typeof model.reviewerProvider === 'string' ? model.reviewerProvider : this.model.reviewerProvider,
            reviewerModel: typeof model.reviewerModel === 'string' ? model.reviewerModel : this.model.reviewerModel,
            reviewerReasoningEffort: typeof model.reviewerReasoningEffort === 'string'
              ? model.reviewerReasoningEffort
              : this.model.reviewerReasoningEffort,
            timeoutMs: Number.isSafeInteger(model.timeoutMs) && model.timeoutMs > 0 ? model.timeoutMs : this.model.timeoutMs,
            maxOutputTokens: Number.isSafeInteger(model.maxOutputTokens) && model.maxOutputTokens > 0
              ? model.maxOutputTokens
              : this.model.maxOutputTokens,
          }
        }
      },
      /** 读界面偏好（一份全局值；带 cwd 时宿主仍会照给 workspace 段，但客户端不再据此判定）。 */
      async load() {
        try {
          const response = await fetch(API_CONFIG, { headers: { accept: 'application/json' } })
          const data = await response.json()
          this.apply(data)
          this.writable = data?.writable === true
        } catch (error) {
          console.warn(LOG, '读取宿主界面偏好失败，沿用本地默认值', error)
        }
        this.emit()
        return this.placement
      },
      /** 写一个偏好并套用宿主回执；失败抛出由调用方回滚。四个行为开关写的是同一份全局值。 */
      async save(patch) {
        const response = await fetch(API_CONFIG, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(patch),
        })
        const data = await response.json()
        if (data?.ok !== true) throw new Error(String(data?.error ?? 'save failed'))
        this.apply(data)
        this.emit()
      },
    }
    /** placement 的读写入口：面板挂载逻辑只关心它，行为开关的变更不会触发重新挂载。 */
    const placementStore = {
      get value() { return runtimeStore.placement },
      set(value) {
        if (runtimeStore.placement === value) return
        runtimeStore.placement = value
        runtimeStore.emit()
      },
      subscribe(listener) {
        return runtimeStore.subscribe(listener)
      },
    }

    /**
     * 归一化目录分组：插件路由（`{id,name,models:[{id,name,efforts}]}`）与客户端 remote
     * （`{id,name,models:[{id,name,reasoning:{efforts}}]}`）两条路共用一个口径。
     * @param {Array} groups 原始分组
     * @returns {Array} 过滤掉空 id 的候选
     */
    function catalogGroups(groups) {
      return (Array.isArray(groups) ? groups : []).map(group => ({
        id: String(group?.id ?? ''),
        name: String(group?.name ?? group?.id ?? ''),
        models: (Array.isArray(group?.models) ? group.models : [])
          .map(model => {
            // 两条路的思考强度位置不同：host 路由给 model.efforts，remote 给 model.reasoning.efforts
            const rawEfforts = model?.reasoning?.efforts ?? model?.efforts
            return {
              id: String(model?.id ?? ''),
              name: String(model?.name ?? model?.id ?? ''),
              efforts: (Array.isArray(rawEfforts) ? rawEfforts : [])
                .map(effort => ({ id: String(effort?.id ?? ''), name: String(effort?.name ?? effort?.id ?? '') }))
                .filter(effort => effort.id !== ''),
            }
          })
          .filter(model => model.id !== ''),
      })).filter(group => group.id !== '')
    }

    /**
     * 宿主模型目录（provider → models）：面板候选的来源。走客户端 remote 面
     * （`ctx.remote.session.modelCatalog()`，与宿主 composer 的模型选择器同一份数据）。
     * 拿不到目录只是没有候选——面板仍可手填；失败如实提示，不影响审批主链路。
     */
    const modelCatalogStore = {
      status: 'idle',
      error: '',
      groups: [],
      listeners: new Set(),
      subscribe(listener) {
        this.listeners.add(listener)
        return () => { this.listeners.delete(listener) }
      },
      emit() {
        for (const listener of [...this.listeners]) listener()
      },
      /**
       * 宿主客户端 remote 的 session 命名空间（模型目录在它上面）。服务没注入或取不到时
       * 返回 undefined —— 候选不可用而已，不影响手填与审批主链路。
       * @returns {object|undefined} remote.session 命名空间
       */
      namespace() {
        try {
          const viaService = typeof clientCtx?.get === 'function' ? clientCtx.get('remote') : undefined
          return (viaService ?? clientCtx?.remote)?.session
        } catch (error) {
          return undefined
        }
      },
      /** provider 候选（{id, name}）。 */
      providers() {
        return this.groups.map(group => ({ id: group.id, name: group.name }))
      },
      /** 某个 provider 下的模型候选。 */
      modelsOf(provider) {
        return this.groups.find(group => group.id === provider)?.models ?? []
      },
      /** 某个 provider+model 的思考强度候选：目录里没有就是空数组（只能手填）。 */
      effortsOf(provider, model) {
        return this.modelsOf(provider).find(entry => entry.id === model)?.efforts ?? []
      },
      /**
       * 读一次宿主模型目录并归一化成候选。**只在卡片挂载时读一次**（目录不常变）。
       * 首选插件自己的路由（宿主 `sessionController.modelCatalog()`，与 composer 的模型选择器
       * 同一份数据）——它不依赖客户端 remote 面是否注入；那条路拿不到再用 remote 面兜底，
       * 两条都不行就退回纯手填并如实提示。
       */
      async load() {
        if (this.status === 'loading') return
        this.status = 'loading'
        this.emit()
        const problems = []
        try {
          const response = await fetch(API_MODELS, { headers: { accept: 'application/json' } })
          const data = await response.json()
          if (data?.ok === true) {
            this.groups = catalogGroups(data.groups)
            this.status = 'ready'
            this.error = ''
            this.emit()
            return
          }
          problems.push(String(data?.error ?? 'model catalog unavailable'))
        } catch (cause) {
          problems.push(String(cause?.message ?? cause))
        }
        const namespace = this.namespace()
        if (namespace !== undefined && typeof namespace.modelCatalog === 'function') {
          try {
            const response = await namespace.modelCatalog()
            if (response?.ok === true) {
              this.groups = catalogGroups(response.value?.groups)
              this.status = 'ready'
              this.error = ''
              this.emit()
              return
            }
            problems.push(String(response?.error?.message ?? 'model catalog unavailable'))
          } catch (cause) {
            problems.push(String(cause?.message ?? cause))
          }
        }
        this.groups = []
        this.status = 'failed'
        this.error = problems.length === 0 ? t.catalogUnavailable : t.catalogUnavailable + '（' + problems[0] + '）'
        this.emit()
      },
    }

    /** 客户端上下文：applyInner 时捕获，供组件里访问宿主客户端服务（sessions / sidebarRight）。 */
    let clientCtx

    /**
     * 当前挂载状态（applyInner 与时间线面板写入）：
     * - sidebar：右侧栏 tab 的注入 handle，非空表示 tab 类型已注册（placement=tab 时不注册，
     *   那种放置方式下也没有可自动打开的时间线）；
     * - timelineShown：审批时间线是否**正显示在眼前**——面板挂载且 tab 可见（收起侧栏、
     *   切到别的 tab 都算「没打开」，用户选定的判定规则就靠它）。
     */
    const mountState = { tab: undefined, sidebar: undefined, timelineShown: false }

    /**
     * 审批观察器：seen 记每个会话上一次看到的最新记录 id（判断有没有出现新审批），timer 是轮询句柄；
     * sessionId / workspace 记上一次观测的会话与工作区——变了就重读一次界面偏好（自动打开时间线按
     * 工作区区分，用户 2026-09-18）。
     */
    const approvalWatch = { seen: new Map(), timer: undefined, sessionId: undefined, sessionSource: '' }

    /** 记录的身份：id 优先、退回时间戳（宿主写的 id 是 uuid）。 */
    function recordKey(record) {
      return String(record?.id ?? record?.time ?? '')
    }

    /**
     * 未读角标：**按会话隔离**（用户 2026-09-20 要求）——每个会话各自一份「已经落盘、但你还没看过」
     * 的记录集合，tab 上的角标只显示**当前会话**那个数字；别的会话的审批不在当前会话处理，只在自己的
     * 会话里计数（切过去时才看得到）。
     * 首次观测只记基线（刷新页面后堆在那里的历史记录不算未读）；时间线显示在眼前、或（已经打开时）
     * 任意操作即清零；另有 seenAt 记「上次看过这个会话」的时刻，供切换会话时的自动展开判定使用。
     * **它是「自动展开」之外的兜底提示**：右侧栏展开着停在别的工具上时自动展开不动，角标照旧提示。
     */
    const unreadStore = {
      /** 全局已知记录 id：避免同一批记录反复计数（整页会话生命周期内有效）。 */
      known: new Set(),
      /** sessionId → 未读记录 id 集合（按会话隔离）。 */
      buckets: new Map(),
      /** sessionId → 上次「看过这个会话的时间线」的时刻（毫秒）；没看过就没有这个键。 */
      seenAt: new Map(),
      baselined: false,
      /** 当前会话：角标只显示它自己的未读数（'':拿不到会话时的空桶）。 */
      current: '',
      listeners: new Set(),
      subscribe(listener) {
        this.listeners.add(listener)
        return () => { this.listeners.delete(listener) }
      },
      /** 广播当前会话的未读数。 */
      emit() {
        const count = this.countFor(this.current)
        for (const listener of [...this.listeners]) listener(count)
      },
      /** 某个会话的未读数（角标与切换判定都只认它）。 */
      countFor(sessionId) {
        const bucket = this.buckets.get(sessionId === undefined ? '' : String(sessionId))
        return bucket === undefined ? 0 : bucket.size
      },
      /** 切到某个会话：角标跟着换到它的数字（没变就不广播）。 */
      setCurrent(sessionId) {
        const next = sessionId === undefined ? '' : String(sessionId)
        if (next === this.current) return
        this.current = next
        this.emit()
      },
      /** 记下「你看过这个会话了」（面板可见、任意操作、以及自动展开成功时）。 */
      markSeen(sessionId) {
        if (sessionId === undefined || sessionId === '') return
        this.seenAt.set(String(sessionId), Date.now())
      },
      /** 距上次看过这个会话有多久（毫秒）；从没看过 = Infinity（切过去就该弹一次）。 */
      awayMs(sessionId) {
        const at = this.seenAt.get(sessionId === undefined ? '' : String(sessionId))
        return at === undefined ? Number.POSITIVE_INFINITY : Date.now() - at
      },
      /** 记一批记录（最新在前）：首次调用只建基线；之后按 sessionId 分桶，只对当前会话广播。 */
      note(records) {
        let changed = false
        for (const record of records) {
          const key = recordKey(record)
          if (key === '' || this.known.has(key)) continue
          this.known.add(key)
          if (this.baselined === true) {
            const sessionId = String(record?.sessionId ?? '')
            const bucket = this.buckets.get(sessionId) ?? new Set()
            bucket.add(key)
            this.buckets.set(sessionId, bucket)
            if (sessionId === this.current) changed = true
          }
        }
        if (this.baselined !== true) {
          this.baselined = true
          return
        }
        if (changed) this.emit()
      },
      /** 某个会话的未读清零（时间线显示在眼前 / 任意操作）。 */
      clear(sessionId) {
        const key = sessionId === undefined ? '' : String(sessionId)
        const bucket = this.buckets.get(key)
        if (bucket === undefined || bucket.size === 0) return
        bucket.clear()
        this.buckets.delete(key)
        if (key === this.current) this.emit()
      },
      /** 测试与调试用：把这块状态恢复成刚加载页面时的样子。 */
      reset() {
        this.known.clear()
        this.buckets.clear()
        this.seenAt.clear()
        this.baselined = false
        this.current = ''
      },
    }

    /**
     * 右侧栏此刻是不是整栏展开着。
     *
     * 用来把两种「时间线没显示在眼前」分开：整栏收起（用户没在用侧栏）与「展开着但停在其他
     * 侧边工具上」。用户 2026-09-18 选定的口径只允许前者自动打开，后者绝不切走他的视图。
     *
     * 为什么必须问宿主、不能从面板自己推：切到别的 tab 时时间线面板会卸载，它的
     * useTabInfo 也就停了，插件手上只剩「上次肯定是可见的」这种过期信息。
     * @returns {boolean|undefined} 展开/收起；宿主没提供这个方法（老版本）时返回 undefined = 状态未知
     */
    function sidebarExpanded() {
      try {
        const service = typeof clientCtx?.get === 'function' ? clientCtx.get('sidebarRight') : undefined
        if (service === null || typeof service !== 'object' || typeof service.isExpanded !== 'function') return undefined
        return service.isExpanded() === true
      } catch (error) {
        console.warn(LOG, '读取右侧栏展开状态失败', error)
        return undefined
      }
    }

    /** 上一次 currentSessionId() 是从哪一级拿到会话的（none = 四级都读不到）；信标据此取证。 */
    let sessionSource = 'none'

    /** 只认非空字符串的会话 id：宿主各级服务给的可能是 undefined / 空串 / 别的类型。 */
    function sessionIdOf(value) {
      return typeof value === 'string' && value !== '' ? value : undefined
    }

    /**
     * 「当前会话」的四级来源（顺序即优先级），见 {@link currentSessionId}。
     * 每项返回原始值，归一化（只认非空字符串）由调用方统一做；抛错由调用方兜住并继续往下一级。
     */
    const SESSION_ID_SOURCES = [
      // ① 宿主 2.0.17+：uiSession 的主视图绑定（binding source：getSnapshot() 与 .value 都给 {key}）
      ['uiSession', () => {
        const current = clientCtx?.get?.('uiSession')?.current
        if (current === undefined || current === null) return undefined
        const binding = typeof current.getSnapshot === 'function' ? current.getSnapshot() : current.value
        return binding?.key
      }],
      // ② 宿主 2.0.17+：sidebarRight.mounted 是快照 store（老宿主是函数，返回布局、没有会话 id 那一层）
      ['sidebarRight', () => {
        const mounted = clientCtx?.get?.('sidebarRight')?.mounted
        if (mounted === undefined || mounted === null) return undefined
        if (typeof mounted.getSnapshot === 'function') return mounted.getSnapshot()
        return typeof mounted === 'function' ? mounted()?.sessionId : undefined
      }],
      // ③ 老宿主：会话列表快照上的 current（新宿主那份快照只有 ids/byId/phase/projectionsBySession）
      ['sessions.current', () => clientCtx?.get?.('sessions')?.list?.getSnapshot?.()?.current],
      // ④ 兜底：byId 里 retainedBy.mainView > 0 的那条（与宿主 publishMain() 同一个判据）
      ['sessions.mainView', () => {
        const rows = clientCtx?.get?.('sessions')?.list?.getSnapshot?.()?.byId
        if (rows === null || typeof rows !== 'object') return undefined
        for (const row of Object.values(rows)) {
          if ((row?.retainedBy?.mainView ?? 0) > 0) return row.id
        }
        return undefined
      }],
    ]

    /**
     * 当前会话 id（自动展开与未读角标按它挑记录），**按宿主版本逐级回退**，见 SESSION_ID_SOURCES。
     *
     * 为什么必须回退：宿主 2.0.17（2026-09-29 升级）换了客户端服务的形状，**老写法
     * `sessions.list.getSnapshot().current` 在新宿主上恒为 undefined**——那份快照现在只有
     * `{ids,byId,phase,projectionsBySession}`（dsh-api-session-controller 的 projectList() 写死这几个键），
     * 「主列里那个会话」搬到了 dsh-client-ui-session 的 `uiSession.current` 绑定上（publishMain()
     * 按 `byId[].retainedBy.mainView` 挑，读宿主源码确认）。拿不到会话的后果不是「少个提示」：
     * watchApprovals() 会在第一行 return，**自动展开与未读角标一起失效**（2026-10-08 用户报
     * 「更新后不自动打开审批列表了」的根因）。
     * 全读不到时返回 undefined——观察器宁可空转，也不许把会话猜成别人（那会让角标与自动展开张冠李戴）。
     * @returns {string|undefined} 当前会话 id
     */
    function currentSessionId() {
      for (const [name, read] of SESSION_ID_SOURCES) {
        let value
        try {
          value = read()
        } catch (error) {
          console.warn(LOG, '读取当前会话失败（' + name + '）', error)
          continue
        }
        const id = sessionIdOf(value)
        if (id !== undefined) {
          sessionSource = name
          return id
        }
      }
      sessionSource = 'none'
      return undefined
    }

    /**
     * 「从哪一级认出的当前会话」只在**变化时**上报一次：宿主日志里
     * `client beacon stage=session-source detail=uiSession=session-xxxx` 就是「自动展开认到了哪个会话、
     * 靠哪一级认出来的」的直接证据；`detail=none` = 四级来源全读不到（2026-10-08 那次坏掉时的病征，
     * **失败也要上报**：安静地什么都不做是最难查的形态）。轮询 3 秒一次，必须节流。
     * @param {string|undefined} sessionId 这一轮认到的会话（undefined = 没认出来）
     * @returns {void}
     */
    function beaconSessionSource(sessionId) {
      const detail = sessionId === undefined ? sessionSource : sessionSource + '=' + sessionId
      if (approvalWatch.sessionSource === detail) return
      approvalWatch.sessionSource = detail
      beacon('session-source', detail)
    }

    /**
     * 看一次「当前会话有没有刚触发的审批」。
     *
     * 判定规则全部交给 maybeAutoOpenTimeline / maybeAutoOpenOnSwitch（用户 2026-09-20 修订）：
     * ① 当前会话里出现「刚发生」的审批；② 切换进一个攒了未读的会话（离开超过 1 分钟，或未读 > 5 条）。
     * approvalWatch.seen 只用来发现「这个会话最新一条记录的 id 变了」，变了就说明刚发生了审批。
     * **首次观测只记基线**——页面刷新后会话里往往已经堆着历史记录，那不是「刚触发的审批」，不该弹开。
     * 观察器与面板无关：用户停在「轨迹」标签页、或 placement 只挂右侧栏时同样会触发
     * （旧实现把探针写在「拿不到项目目录」的分支里，正常情况根本不执行，等于没生效）。
     * @returns {Promise<void>} 无返回值；任何失败只记日志，绝不影响面板自身
     */
    async function watchApprovals() {
      if (mountState.sidebar === undefined) return
      const sessionId = currentSessionId()
      beaconSessionSource(sessionId)
      if (sessionId === undefined) return
      // previousSession 用来识别「刚切进来」——切换判定只在那一刻做一次
      const previousSession = approvalWatch.sessionId
      const switched = previousSession !== undefined && previousSession !== sessionId
      if (approvalWatch.sessionId !== sessionId) {
        approvalWatch.sessionId = sessionId
        // 换了会话就重读一次界面偏好（开关是全局的，但宿主那边可能被别的窗口改过）
        await runtimeStore.load()
      }
      // 一次请求同时喂两件事：全部会话的最新若干条里挑出「当前会话的最新记录」（决定要不要自动展开）
      // 与「本轮页面还没看过的记录」（未读角标）。**开关关着也要轮询**——角标是自动展开之外的兜底提示。
      let records = []
      try {
        const response = await fetch(API_LOG + '?limit=' + UNREAD_FETCH_LIMIT, {
          headers: { accept: 'application/json' },
        })
        const data = await response.json()
        records = Array.isArray(data?.records) ? data.records : []
      } catch (error) {
        console.warn(LOG, '读取审批记录以判断是否自动打开时间线失败', error)
        return
      }
      unreadStore.note(records)
      unreadStore.setCurrent(sessionId)
      // 切换进某会话的判定与「本会话里出现新记录」相互独立，各判各的（开关与焦点门槛都还在
      // maybeAutoOpenTimeline 里再判一遍）
      if (switched) maybeAutoOpenOnSwitch(sessionId)
      if (runtimeStore.autoOpenTimeline !== true) return
      // 记录按时间倒序、合并了所有工作区：当前会话那条不一定是第一条，往前找
      const mine = records.find(record => record?.sessionId === sessionId)
      const newest = mine === undefined ? '' : recordKey(mine)
      const seen = approvalWatch.seen.get(sessionId)
      if (seen === newest) return
      approvalWatch.seen.set(sessionId, newest)
      // 只认「刚发生」的审批：切会话 / 刷新页面翻到的历史记录只记基线，不弹面板（2026-09-20 用户口径）
      if (newest === '' || !isFreshRecord(mine?.time)) return
      maybeAutoOpenTimeline(sessionId)
    }

    /**
     * 切换进某个会话时要不要自动展开一次（用户 2026-09-20 口径）。
     *
     * 两个条件满足其一就打开：① 该会话攒的未读超过 UNREAD_AUTO_OPEN_MAX 条（太多了，必须让你看见）；
     * ② 距你上次看过这个会话的时间线超过 AUTO_OPEN_AFTER_AWAY_MS（从没看过也算）而期间产生过审批。
     * 没有未读就什么都不做——「没产生过审批事件」不该打扰你。只在切换那一刻判一次，因此每次进入
     * 最多弹一次；真正的开关与焦点门槛仍在 maybeAutoOpenTimeline 里。
     * @param {string} sessionId 刚切进来的会话
     * @returns {void}
     */
    function maybeAutoOpenOnSwitch(sessionId) {
      const unread = unreadStore.countFor(sessionId)
      if (unread === 0) return
      const piled = unread > UNREAD_AUTO_OPEN_MAX
      const away = unreadStore.awayMs(sessionId) > AUTO_OPEN_AFTER_AWAY_MS
      if (!piled && !away) return
      maybeAutoOpenTimeline(sessionId)
    }

    /** 记录时间戳是否落在「刚发生」窗口内；缺失 / 非法 / 偏差过大的时间戳一律按不新鲜处理。 */
    function isFreshRecord(time) {
      if (typeof time !== 'string' || time === '') return false
      const at = Date.parse(time)
      if (!Number.isFinite(at)) return false
      return Math.abs(Date.now() - at) <= AUTO_OPEN_FRESH_MS
    }

    /**
     * 我们的审批时间线 tab 是否**还在侧栏里**（开过、没被关掉）。
     *
     * 只用来区分两种「侧栏展开着」：停在别的侧边工具上（我们的 tab 还在，只是没显示）与**用户手动
     * 把时间线 tab 关掉了**（侧栏里已经没有它）。官方 closeTab 只在「它是唯一 docked tab」时才顺便
     * 把整栏收起来，所以关掉 ours 之后侧栏往往仍然展开着（常见：还留着引导页 tab）——那种状态必须
     * 允许重新打开，否则一旦手动关过一次就再也见不到时间线了（2026-09-20 用户报的场景）。
     *
     * 两个宿主版本两种读法：① 新宿主用 `sidebarRight.tabsIn(sessionId)`（公开面，给该会话已提交的 tab
     * 记录）；② 老宿主用 `mounted()` 返回的 `{layout}`——**新宿主的 `mounted` 是快照 store、不是函数**
     * （2026-09-29 宿主升级踩到），会被①挡在前面、不会走错。都读不到时返回 undefined = 状态未知。
     * @param {string} sessionId 当前会话（tabsIn 按会话取布局）
     * @returns {boolean|undefined} 布局里有没有我们这种 tab；读不到布局时 undefined
     */
    function timelineTabOpen(sessionId) {
      try {
        const service = typeof clientCtx?.get === 'function' ? clientCtx.get('sidebarRight') : undefined
        if (service === undefined || service === null) return undefined
        if (typeof service.tabsIn === 'function' && typeof sessionId === 'string' && sessionId !== '') {
          const tabs = service.tabsIn(sessionId)
          if (Array.isArray(tabs)) return tabs.some(tab => tab?.kind === SIDEBAR_KIND)
        }
        if (typeof service.mounted !== 'function') return undefined
        const layout = service.mounted()?.layout
        if (layout === undefined || layout.tabs === undefined) return undefined
        return Object.values(layout.tabs).some(tab => tab?.kind === SIDEBAR_KIND)
      } catch (error) {
        console.warn(LOG, '读取右侧栏 tab 布局失败', error)
        return undefined
      }
    }

    /**
     * 触发审批后自动展开右侧栏的「审批时间线」。
     *
     * 判定规则（用户 2026-09-18 修订）：时间线已经显示在眼前时什么都不做；**侧栏展开着却停在
     * 别的侧边工具上时也不动它**——只有右侧栏整栏收起才自动展开（用户选定的口径是「收起侧栏才
     * 自动展开，停在其他工具上绝不把他切走」）。
     * 真正展开靠官方 sidebarRight 服务的 openTab（dsh-client-ui-sidebar-right 的 openContent 内部会
     * planSetExpanded(true)，右侧栏因此自动展开），不需要自己拼 layout 调用；也正因为宿主这个入口
     * **没有「只展开不聚焦」的参数**——我们的 tab 已在面板里时它必然补一个 focusTab——「不该抢」
     * 就只能靠插件自己不调用它（读宿主源码确认，2026-09-18）。
     * @param {string} sessionId 触发这次展开的会话（只用于信标与日志）
     * @returns {void} 无返回值；任何失败只影响这次自动展开
     */
    function maybeAutoOpenTimeline(sessionId) {
      if (runtimeStore.autoOpenTimeline !== true) return
      if (mountState.sidebar === undefined) return
      if (mountState.timelineShown === true) return
      // 侧栏展开着 = 用户正在用侧栏里的别的东西（时间线没显示已经由上一行保证了）：
      // 这时宿主 openTab 会把他的 tab 切回时间线，正是 2026-09-18 要修掉的「主动聚焦」。
      // **但「我们的 tab 已经被手动关掉」不算这种情况**：侧栏里已经没有时间线了，用户 2026-09-20
      // 要求照旧重新打开（官方 closeTab 只在它是唯一 docked tab 时才顺手收起整栏——读源码确认——
      // 所以关掉之后侧栏常常还是展开的，老口径会就此永久不再打开）。
      // 状态未知（老宿主没有 isExpanded / mounted）时保持旧行为，尽力打开。
      if (sidebarExpanded() === true && timelineTabOpen(sessionId) !== false) return
      /** 开一次时间线；服务不可用或抛错时返回 false（调用方只重试一次）。 */
      const attempt = () => {
        try {
          const service = typeof clientCtx?.get === 'function' ? clientCtx.get('sidebarRight') : undefined
          if (service === undefined || typeof service.openTab !== 'function') return false
          service.openTab(SIDEBAR_KIND)
          return true
        } catch (error) {
          console.warn(LOG, '自动打开审批时间线失败', error)
          return false
        }
      }
      if (attempt()) {
        // 打开了 = 你这就看到了：记一笔「看过这个会话」，切会话判定据此不再重复弹
        unreadStore.markSeen(sessionId)
        beacon('auto-open-timeline', sessionId)
        return
      }
      // 只重试一次：首个审批出现时，官方 sidebar-right 服务可能还没把座位绑定到当前会话
      setTimeout(() => {
        if (attempt()) {
          unreadStore.markSeen(sessionId)
          beacon('auto-open-timeline', sessionId + '(retry)')
        }
      }, AUTO_OPEN_RETRY_MS)
    }

    /**
     * 取当前会话的工作目录（项目作用域规则要用）。真值来自宿主 sessions 服务的
     * 会话列表快照；服务缺失或字段不对时返回 undefined，任何异常都吞掉——
     * 拿不到项目目录只影响项目规则的展示，不该让面板白屏。
     */
    function workspaceOf(sessionId) {
      if (typeof sessionId !== 'string' || sessionId === '') return undefined
      try {
        const sessions = typeof clientCtx?.get === 'function' ? clientCtx.get('sessions') : undefined
        const snapshot = typeof sessions?.list?.getSnapshot === 'function' ? sessions.list.getSnapshot() : undefined
        const row = snapshot !== null && typeof snapshot === 'object' && snapshot.byId !== undefined
          ? snapshot.byId[sessionId]
          : undefined
        const cwd = row !== null && typeof row === 'object' ? row.cwd : undefined
        return typeof cwd === 'string' && cwd !== '' ? cwd : undefined
      } catch (error) {
        console.warn(LOG, '读取会话工作目录失败', error)
        return undefined
      }
    }

    /** 策略快照的客户端缓存：设置面板与时间线共用，任何变更广播给订阅者。 */
    const policyStore = {
      value: undefined,
      error: '',
      cwd: undefined,
      listeners: new Set(),
      subscribe(listener) {
        this.listeners.add(listener)
        return () => { this.listeners.delete(listener) }
      },
      emit() {
        for (const listener of [...this.listeners]) listener()
      },
      /** 拉一次策略快照；cwd 给定时一并更新项目作用域。 */
      async load(cwd) {
        if (cwd !== undefined) this.cwd = cwd
        const query = this.cwd === undefined ? '' : '?cwd=' + encodeURIComponent(this.cwd)
        try {
          const response = await fetch(API_POLICY + query, { headers: { accept: 'application/json' } })
          const data = await response.json()
          if (data === null || typeof data !== 'object' || data.ok !== true) {
            throw new Error(String(data?.error ?? 'bad response'))
          }
          this.value = data
          this.error = ''
        } catch (error) {
          this.error = String(error?.message ?? error)
        }
        this.emit()
      },
      /** 写策略（改阈值 / 删规则）；成功后自动重拉快照。 */
      async post(body) {
        const response = await fetch(API_POLICY, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(body),
        })
        const data = await response.json()
        if (data === null || typeof data !== 'object' || data.ok !== true) {
          throw new Error(String(data?.error ?? 'policy write failed'))
        }
        await this.load()
        return data
      },
    }

    /**
     * 把一条审批记录升级/降级成规则。`rule` 给定时以它为准（用户在时间线上手填/微调过的条件，
     * 宿主校验后原样写入）；不给时由宿主依据记录里的模型建议产出，没有建议就精确回落到该次签名。
     */
    async function promoteRecord(recordId, scope, list, sessionId, rule) {
      const response = await fetch(API_RULE, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          recordId,
          scope,
          list,
          // 会话 id 让宿主把「现场模型优化」挂在对应会话的 Agent 下
          ...(typeof sessionId === 'string' && sessionId !== '' ? { sessionId } : {}),
          ...(rule === undefined ? {} : { rule }),
        }),
      })
      const data = await response.json()
      if (data === null || typeof data !== 'object' || data.ok !== true) {
        throw new Error(String(data?.error ?? 'rule write failed'))
      }
      await policyStore.load()
      return data
    }

    /**
     * 请宿主**按指定匹配条件**重新生成一条规则（不写名单，只回给界面填草稿）。
     * 提示词里会带上用户选的条件与当前草稿，所以模型知道要产出哪种条件。
     * @param recordId 审批记录 id
     * @param list 'allow' / 'deny'（只影响提示词里名单的说法）
     * @param kind 用户选的匹配条件
     * @param draft 当前草稿（给模型参考）
     * @param sessionId 会话 id（宿主按它记 llm session）
     * @returns {Promise<object>} 宿主回执（rule.match.kind / rule.match.value / rule.label）
     */
    async function draftRule(recordId, list, kind, draft, sessionId) {
      const response = await fetch(API_RULE_DRAFT, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          recordId,
          list,
          kind,
          draft,
          ...(typeof sessionId === 'string' && sessionId !== '' ? { sessionId } : {}),
        }),
      })
      const data = await response.json()
      if (data === null || typeof data !== 'object' || data.ok !== true) {
        throw new Error(String(data?.error ?? 'rule draft failed'))
      }
      return data
    }

    /**
     * 撤销一次「加入名单」：宿主按记录里的凭据删掉那次写入的规则、把它顶掉的旧规则放回去。
     * 客户端只报 recordId——**不让浏览器指定要恢复什么**，凭据只认记录里那一份。
     * @param recordId 审批记录 id
     * @returns {Promise<object>} 宿主回执（restored：被放回去的规则标签）
     */
    async function revertRecord(recordId) {
      const response = await fetch(API_RULE_REVERT, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ recordId }),
      })
      const data = await response.json()
      if (data === null || typeof data !== 'object' || data.ok !== true) {
        throw new Error(String(data?.error ?? 'revert failed'))
      }
      await policyStore.load()
      return data
    }

    /** 规则来源文案。 */
    function sourceLabel(source) {
      if (source === 'model') return t.sourceModel
      if (source === 'memory') return t.sourceMemory
      return t.sourceUser
    }

    /** 匹配条件下拉的顺序（与宿主 policy.js 的 MATCH_KINDS 同一套闭集）。 */
    const MATCH_KIND_ORDER = ['command_prefix', 'signature', 'path_prefix']

    /**
     * 模型建议能不能当表单默认值：**`signature`（权限指纹）类的建议必须逐字等于本次签名**——
     * 与宿主 `suggestionUsable` 里「signature 必须等于本次签名 key」那道闸同口径。
     * 前缀类建议这里不拦（对不对一眼能看出来，宿主提交时还会再验一次）。
     * 真机实测（~/.dsh/dsh-auto-pass/records/*.json）：模型把「签名」写成了
     * `danger-full-access` / `escalation=danger-full-access` 这类一句描述，当默认值填进表单后
     * 既与详情里的权限指纹对不上，点按钮还会被宿主用 400 `not-covering` 拒掉。
     * @param record 审批记录
     * @param suggested 记录里的模型建议规则
     * @returns {boolean} 能当默认值返回 true
     */
    function suggestedRuleFits(record, suggested) {
      if (suggested?.match?.kind !== 'signature') return true
      const key = record?.signature?.key
      return typeof key === 'string' && key !== '' && String(suggested.match.value ?? '') === key
    }

    /**
     * 规则草稿：默认用这次审查的模型建议（能覆盖本次动作的才行，见 suggestedRuleFits），
     * 没有可用建议就用本次动作的权限指纹——它是最窄、最安全又耐用的默认值，
     * 也正是详情里那一行「权限指纹」。
     * fromModel 只影响界面上的那句说明，用户改不改都行。
     */
    function ruleDraftOf(record) {
      const suggested = record?.suggestedRule
      if (suggested !== null && typeof suggested === 'object' && suggested.match !== undefined
        && suggested.match !== null && suggestedRuleFits(record, suggested)) {
        return {
          kind: suggested.match.kind,
          value: String(suggested.match.value ?? ''),
          label: String(suggested.label ?? ''),
          fromModel: true,
          edited: false,
          source: 'suggestion',
          pending: false,
          error: '',
        }
      }
      return {
        kind: 'signature',
        value: String(record?.signature?.key ?? ''),
        label: String(record?.signature?.text ?? record?.toolName ?? ''),
        fromModel: false,
        edited: false,
        source: 'signature',
        pending: false,
        error: '',
      }
    }

    /**
     * 把一条已有规则的匹配值翻译成另一种条件的值（设置面板里改条件时用）：
     * 权限指纹 → 命令前缀，就从签名 key 的 `cmd:` 段里把命令取出来（同样砍掉管道之后）。
     * 翻译不出来就保留原值，绝不猜。
     */
    /**
     * 命令前缀用的文本：砍掉第一个管道之后（只决定怎么显示输出）与结尾的纯输出重定向
     * （`2>&1` / `>nul`）——与宿主 countingCommand 同口径，界面草稿才不会和宿主默认值长得不一样。
     * @param command 原始命令文本
     * @returns {string} 归一化后的命令
     */
    function plainCommand(command) {
      const text = String(command ?? '').replace(/\s+/g, ' ').trim()
      // 与宿主 firstPipeOutsideQuotes 同口径：引号里的竖线（正则里的 |）不算管道
      let quote = ''
      let cut = -1
      for (let index = 0; index < text.length; index += 1) {
        const char = text[index]
        if (quote !== '') {
          if (char === quote) quote = ''
          continue
        }
        if (char === '"' || char === "'") quote = char
        else if (char === '|') {
          cut = index
          break
        }
      }
      const head = (cut === -1 ? text : text.slice(0, cut)).trim()
      return head
        .replace(/(?:\s|^)(?:\d?>{1,2}\s*(?:&1|&2|nul|\/dev\/null)|&>{1,2}\s*(?:nul|\/dev\/null))$/i, '')
        .trim()
    }

    function ruleValueForKind(kind, value) {
      if (kind !== 'command_prefix') return value
      const head = String(value).split('\u0000')[1]
      if (typeof head !== 'string' || !head.startsWith('cmd:')) return value
      return plainCommand(head.slice('cmd:'.length))
    }

    /** 命令前缀的默认值：命令砍掉管道之后与结尾重定向（与宿主 defaultRuleOf 同源）。 */
    function commandPrefixOf(signature) {
      const plain = plainCommand(typeof signature?.command === 'string' ? signature.command : '')
      return plain === '' ? undefined : plain
    }

    /**
     * 换匹配条件时草稿值该填什么：签名 → 本次签名 key；命令前缀 → 本次命令（砍掉管道之后）；
     * 路径前缀 → 本次动作的第一个路径。推导不出来就保留用户原来的值（别把人手填的内容冲掉）。
     * @param record 审批记录
     * @param kind 新选的匹配条件
     * @param fallback 保留值（推导不出来时用它）
     * @returns {string} 新的匹配值
     */
    function ruleDraftValueOf(record, kind, fallback) {
      const signature = record?.signature
      if (kind === 'signature') {
        return typeof signature?.key === 'string' && signature.key !== '' ? signature.key : fallback
      }
      if (kind === 'command_prefix') return commandPrefixOf(signature) ?? fallback
      if (kind === 'path_prefix') {
        const paths = Array.isArray(signature?.paths) ? signature.paths : []
        return paths.length > 0 ? String(paths[0]) : fallback
      }
      return fallback
    }

    /**
     * 这次动作能不能用某种匹配条件（与宿主 kindApplicable 同口径）：新记录一定带 `paths` 字段
     * （可能是空数组），所以「有没有命令 / 文件路径」是可知的——可知却对不上就禁用那个按钮，
     * 免得生成一条永远命不中的规则（真机踩过：pwsh 命令记录被切到路径前缀，模型给了个目录）。
     * 老记录判不了，按可用处理。
     * @param record 审批记录
     * @param kind 匹配条件
     * @returns {boolean} 可用返回 true
     */
    function kindApplicable(record, kind) {
      const signature = record?.signature
      if (signature === undefined || signature === null) return true
      const known = Array.isArray(signature.paths)
      if (kind === 'command_prefix') return known !== true || typeof signature.command === 'string'
      if (kind === 'path_prefix') {
        return known !== true || (Array.isArray(signature.paths) && signature.paths.length > 0)
      }
      return true
    }

    /**
     * 草稿那一行的说明文字：正在让模型按条件重新生成 / 模型已生成 / 本地按条件推导 / 初始来源。
     * @param draft 规则草稿
     * @returns {string} 说明文本
     */
    function draftHintText(draft) {
      if (draft.pending === true) return t.ruleDraftRegenerating
      if (typeof draft.error === 'string' && draft.error !== '') return t.ruleDraftRegenFailed
      if (draft.source === 'model') return t.ruleDraftRegenerated
      if (draft.source === 'local' || draft.edited === true) return t.ruleDraftEdited
      return draft.fromModel === true ? t.ruleDraftFromModel : t.ruleDraftFromSignature
    }

    /**
     * 草稿的本地校验（与宿主 validateRuleInput 同口径）：值与标签非空，前缀类条件至少 3 个字符。
     * @param draft 规则草稿
     * @returns {string|undefined} 有问题的说明文本；没问题返回 undefined
     */
    function ruleDraftProblem(draft) {
      if (draft.label.trim() === '') return t.ruleNeedLabel
      if (draft.value.trim() === '') return t.ruleNeedValue
      if (draft.kind !== 'signature' && draft.value.trim().length < 3) return t.ruleNeedLongerPrefix
      // 路径前缀的通配符口径与宿主 validatePathPattern 一致，先把关省得白跑一趟
      if (draft.kind === 'path_prefix') {
        const value = draft.value.trim()
        if (value.includes('**')) return t.ruleNoDoubleStar
        if (/[?[\]]/.test(value)) return t.ruleNoOtherGlob
        const star = value.indexOf('*')
        if (star !== -1 && value.slice(star + 1).includes('/')) return t.ruleStarLastSegment
      }
      return undefined
    }

    /**
     * 权限指纹的可视化：把机器串 `工具\u0000cmd:命令\u0000x:{额外参数}` 拆开。
     * 指纹是给机器用的（规则匹配、连续计数），管理名单的人得看得懂它在授权什么——
     * 界面上只读，并按这个结构摊开显示（用户 2026-09-16 要求）。
     * **不在规则里另存一份渲染文本**：指纹本身就是唯一事实来源，渲染每次都从它现算。
     * 解析不出来（老记录、手搓的值）返回 undefined，调用方退回显示原始值。
     * @param value 指纹串（规则的 match.value 或记录里的 signature.key）
     * @returns {{tool: string, command?: string, args?: string, extras: {key: string, value: string}[], short: string}|undefined}
     */
    function fingerprintOf(value) {
      const parts = String(value ?? '').split('\u0000')
      if (parts.length < 3) return undefined
      const extraText = parts.slice(2).join('\u0000')
      if (!extraText.startsWith('x:')) return undefined
      let extra
      try {
        extra = JSON.parse(extraText.slice(2))
      } catch (error) {
        return undefined
      }
      if (extra === null || typeof extra !== 'object' || Array.isArray(extra)) return undefined
      const base = parts[1]
      let head
      if (base.startsWith('cmd:')) head = { command: base.slice('cmd:'.length) }
      else if (base.startsWith('args:')) head = { args: clipText(base.slice('args:'.length), 80) }
      else return undefined
      const extras = Object.keys(extra).sort().map(key => ({ key, value: clipText(fingerprintValue(extra[key]), 60) }))
      const bits = [parts[0], head.command ?? head.args]
      for (const item of extras) bits.push(item.key + '=' + item.value)
      return { tool: parts[0], ...head, extras, short: bits.join(' · ') }
    }

    /** 指纹里某个参数值的显示文本：字符串直接给，其余压成 JSON。 */
    function fingerprintValue(value) {
      if (typeof value === 'string') return value
      try {
        return JSON.stringify(value)
      } catch (error) {
        return String(value)
      }
    }

    /** 截断长文本（指纹里的命令与参数都可能很长，界面上只给一眼能看完的一段）。 */
    function clipText(text, max) {
      const value = String(text ?? '')
      return value.length > max ? value.slice(0, max) + '…' : value
    }

    /** 一行紧凑的指纹文案（列表与表单里用）；解析不出来就退回原始值。 */
    function fingerprintShort(value) {
      const parsed = fingerprintOf(value)
      return parsed === undefined ? clipText(value, 60) : parsed.short
    }

    /**
     * 指纹的分行明细（详情里用）：命令（或参数）/ 额外参数。
     * 解析不出来就返回空数组，只留详情里那一行原始 key。
     * @param value 指纹串
     * @returns {Array} Field 元素数组
     */
    function fingerprintFields(value) {
      const parsed = fingerprintOf(value)
      if (parsed === undefined) return []
      // 不再单独列「工具」：上一行的指纹本身就是以 `工具 · 命令 · 额外参数` 开头（用户 2026-09-18 去重）
      return [
        react.createElement(Field, {
          key: 'fingerprint-head',
          label: parsed.command === undefined ? t.fingerprintArgs : t.fingerprintCommand,
          value: parsed.command ?? parsed.args,
          mono: true,
        }),
        ...(parsed.extras.length === 0 ? [] : [react.createElement(Field, {
          key: 'fingerprint-extra',
          label: t.fingerprintExtra,
          value: parsed.extras.map(item => item.key + '=' + item.value).join(' / '),
          mono: true,
        })]),
      ]
    }

    /**
     * 把文本写进剪贴板。**原始指纹含 NUL 分隔符**，只有走剪贴板 API 才能整串复制：
     * 在界面上选中那段文字再复制，NUL 会被吃掉，粘出来是 `pwshcmd:pnpm testx:{…}` 这种废串
     * （真机反馈过），所以显示走渲染、复制走 API。拿不到 clipboard 时返回 false，调用方提示一句。
     */
    async function copyText(text) {
      const clipboard = typeof navigator === 'object' && navigator !== null ? navigator.clipboard : undefined
      if (clipboard === undefined || clipboard === null || typeof clipboard.writeText !== 'function') return false
      try {
        await clipboard.writeText(String(text ?? ''))
        return true
      } catch (error) {
        return false
      }
    }

    /**
     * 权限指纹的只读展示：一行可视化 + 「复制指纹」按钮，原始串只挂 title。
     * **不把原始串塞进输入框**：那串里全是 NUL 分隔符，浏览器把每个 NUL 画成一个方框（真机反馈
     * 「像乱码」），而且选中复制会丢分隔符——所以显示走渲染，整串复制走剪贴板 API。
     * `wrap: true` = 表单里那种**折行全显示**形态（用户 2026-09-18 从预览页选定）：指纹可能上百字符，
     * 单行截断在 300–340px 的侧栏里读不到它到底在授权什么，而它又不能手改、只能看。
     * 不传 `wrap` 就是原来的单行截断（「排查信息」里那一行仍用它：那儿只要一眼核对）。
     * @param value 指纹串
     * @param wrap 是否折行显示（表单里用；默认单行截断）
     */
    function FingerprintValue({ value, wrap }) {
      const raw = String(value ?? '')
      const wrapped = wrap === true
      const [note, setNote] = react.useState('')
      const copy = () => {
        void copyText(raw).then(ok => setNote(ok ? t.copiedFingerprint : t.copyFingerprintFailed))
      }
      return react.createElement('span', {
        className: wrapped ? 'ap-fingerprintValue ap-fingerprintWrap' : 'ap-fingerprintValue',
        title: raw,
      },
        react.createElement('span', {
          className: wrapped ? 'ap-mono ap-fingerprintText' : 'ap-mono ap-fingerprintShort',
        }, fingerprintShort(raw)),
        react.createElement('button', { type: 'button', className: 'ap-btn', onClick: copy }, t.copyFingerprint),
        note !== '' && react.createElement('span', { className: 'ap-note' }, note))
    }

    /** 匹配条件文案。 */
    function kindLabel(kind) {
      if (kind === 'command_prefix') return t.kindCommandPrefix
      if (kind === 'path_prefix') return t.kindPathPrefix
      return t.kindSignature
    }

    /** 作用域文案。 */
    function scopeLabel(scope) {
      return scope === 'project' ? t.scopeProject : t.scopeGlobal
    }

    /** 把一组字段渲染成详情行。title 用来挂那些**不适合直接显示**的原始值（比如含 NUL 的指纹）。 */
    function Field({ label, value, mono, title }) {
      if (value === undefined || value === null || value === '') return null
      return react.createElement('div', { className: 'ap-field' },
        react.createElement('span', { className: 'ap-fieldKey' }, label),
        react.createElement('span', {
          className: 'ap-fieldVal' + (mono === true ? ' ap-mono' : ''),
          ...(title === undefined ? {} : { title: String(title) }),
        }, String(value)))
    }

    /**
     * 命中规则的来源：记录里存了就用记录里的；老记录没有这个字段时，按 ruleId 去当前策略快照反查——
     * 规则本身带 source，所以历史记录也能显示「自动 / 手动」。
     */
    function ruleSourceOf(record) {
      if (record.policy === undefined) return undefined
      if (record.policy.source !== undefined) return record.policy.source
      const snapshot = policyStore.value
      if (snapshot === null || typeof snapshot !== 'object') return undefined
      const view = record.policy.scope === 'project' ? snapshot.project : snapshot.global
      if (view === undefined || view === null) return undefined
      for (const list of ['allow', 'deny']) {
        const rule = (view[list] ?? []).find(candidate => candidate.id === record.policy.ruleId)
        if (rule !== undefined && rule.source !== undefined) return rule.source
      }
      return undefined
    }

    /** 记录里的决策来源；老记录没有这个字段时按 verdict / outcome 兜底推断。 */
    function decidedByOf(record) {
      if (record.decidedBy === 'auto' || record.decidedBy === 'human') return record.decidedBy
      // 与宿主 decisionSource 同一套口径：黑名单直接拒绝是插件自己判的，没有人参与
      if (record.verdict === 'blacklist-reject') return 'auto'
      const pluginDecided = record.verdict === 'allow' || record.policy?.list === 'allow'
      return pluginDecided && record.outcome === 'allowed-once' ? 'auto' : 'human'
    }

    /**
     * 快捷筛选的键：命中名单两类（allow / deny）+ 决策来源两类（auto / human），
     * 数组顺序就是按钮顺序；四个键互不重叠（见 matchesFilter）。
     * 「全部」不在表里，它是清空筛选的入口。
     */
    const FILTER_KEYS = ['allow', 'deny', 'auto', 'human']

    /**
     * 一条记录是否命中某个快捷筛选键。四个键**互不重叠**，四个 chip 的条数相加正好是总数。
     * allow / deny 看这次审批有没有命中名单（record.policy.list）；auto / human 看决策来源，
     * 但**命中名单的记录一律不算**——命中白名单那次 decidedBy 是 auto、命中黑名单那次是 human，
     * 不排除就会让同一批记录同时出现在两类里。
     * 于是 auto = 模型自动放行的记录，human = 你最终拍板的记录，两者都不含被名单拦下的那些。
     * @param {object} record 审批记录
     * @param {string} key 筛选键
     * @returns {boolean} 命中返回 true
     */
    function matchesFilter(record, key) {
      const list = record.policy?.list
      if (key === 'allow' || key === 'deny') {
        return list === key
      }
      if (list !== undefined) {
        return false
      }
      return decidedByOf(record) === key
    }

    /**
     * 快捷筛选按钮的文案：白/黑名单复用命中名单的措辞，自动/人工复用决策来源的措辞。
     * @param {string} key 筛选键
     * @returns {string} 按钮文字
     */
    function filterLabel(key) {
      const map = { allow: t.hitAllow, deny: t.hitDeny, auto: t.filterAuto, human: t.filterHuman }
      return map[key] ?? key
    }

    /**
     * 结论徽标：allow=模型自动批准；blacklist-reject=插件按黑名单直接拒绝（设置开启时）；
     * deny=模型拒绝（转人工）；其余按「审查未完成」显示。后两种都会转交人工，所以是警告色。
     */
    function VerdictBadge({ record }) {
      const allow = record.verdict === 'allow'
      return react.createElement('span', {
        className: 'ap-badge ' + (allow ? 'ap-badgeOk' : 'ap-badgeWarn'),
        title: record.rationale ?? '',
      }, verdictLabelOf(record))
    }

    /** 人工侧结论的文案与徽标样式；没有人工结论时返回 undefined。 */
    function outcomeOf(record) {
      const map = {
        'allowed-once': [t.outcomeAllowed, 'ap-badgeOk'],
        rejected: [t.outcomeRejected, 'ap-badgeWarn'],
        unavailable: [t.outcomeUnavailable, 'ap-badgeMuted'],
        cancelled: [t.outcomeCancelled, 'ap-badgeMuted'],
      }
      return map[record.outcome]
    }

    /** 最终结果徽标：转人工的记录才需要展示人工侧结果。 */
    function OutcomeBadge({ record }) {
      if (record.verdict === 'allow') return null
      const hit = outcomeOf(record)
      if (hit === undefined) return null
      return react.createElement('span', { className: 'ap-badge ' + hit[1] }, hit[0])
    }

    /**
     * 折叠行的「规则自动写入」标识（用户 2026-09-18 要求）：达阈值自动写进白名单的那条记录，
     * **不展开也能看到**这次顺手往名单里写了规则，并标出条件来源（模型建议 / 权限指纹）。
     * 只认记录里的 `ruleApplied.auto === true`（宿主 `enrollRule` 只在自动写入时置它）；
     * `covered === true`（已有规则覆盖这次动作、其实没写任何条目）时文案如实说明没新增，
     * 用中性色——别让标识看起来像刚加了那条规则。
     * 来源字段（`optimizedBy`）是 2026-09-18 才写进记录的：老记录没有时只显示「已自动加入白名单」。
     */
    function RuleAutoBadge({ record }) {
      const applied = record?.ruleApplied
      if (applied === null || applied === undefined || applied.auto !== true) return null
      const by = applied.optimizedBy
      const covered = applied.covered === true
      const list = applied.list === 'deny' ? 'deny' : 'allow'
      const detail = scopeLabel(applied.scope) + ' · ' + String(applied.label ?? '')
      return react.createElement('span', {
        className: 'ap-badge ' + (covered ? 'ap-badgeMuted' : 'ap-badgeInfo'),
        // 覆盖命中那次照抄「已写入」的说明会撒谎：tooltip 也分开写
        title: covered ? t.ruleAutoCoveredTitle(detail) : t.ruleAutoTitle(by, detail),
      }, covered ? t.ruleAutoCovered(list) : t.ruleAutoBadge(list))
    }

    /**
     * 折叠行第一行里的「来源 / 命中」chip：命中名单时是「白名单·自动」这类，没命中时是「自动 / 人工」。
     * 说明文字（命中规则「本项目 · 运行 vitest 测试」/ 决策含义）挂 tooltip——用户 2026-09-18 定的两行行头里，
     * 第二行留给审批意见，两者只能留一个（见预览页取舍表）。
     */
    function HitChip({ record }) {
      const auto = decidedByOf(record) === 'auto'
      const policy = record.policy
      const listLabel = policy === undefined ? '' : (policy.list === 'allow' ? t.hitAllow : t.hitDeny)
      const sourceLabel = auto ? t.decidedAuto : t.decidedHuman
      const text = policy === undefined
        ? (auto ? t.decidedAutoText : t.decidedHumanText + ' · ' + (outcomeOf(record)?.[0] ?? t.decidedUnknown))
        : scopeLabel(policy.scope) + ' · ' + String(policy.label ?? '')
      const badgeClass = policy === undefined
        ? (auto ? 'ap-badgeInfo' : 'ap-badgeMuted')
        : (policy.list === 'allow' ? 'ap-badgeOk' : 'ap-badgeWarn')
      return react.createElement('span', {
        className: 'ap-badge ' + badgeClass,
        title: (auto ? t.decidedAutoTitle : t.decidedHumanTitle) + '：' + text,
      }, listLabel === '' ? sourceLabel : listLabel + '·' + sourceLabel)
    }

    /** 两位补零。 */
    function pad2(n) {
      return String(n).padStart(2, '0')
    }

    /**
     * 日期分组标题（用户 2026-09-18 定「按天分组」）：今天 / 昨天 / 更早的用 `MM-DD`。
     * 认不出时间的记录返回空串，调用方据此退化成不分组。
     */
    function dayLabelOf(value) {
      const date = new Date(value)
      if (Number.isNaN(date.getTime())) return ''
      const midnight = d => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime()
      const today = midnight(new Date())
      const target = midnight(date)
      const DAY_MS = 24 * 60 * 60 * 1000
      if (target === today) return t.dayToday
      if (target === today - DAY_MS) return t.dayYesterday
      return pad2(date.getMonth() + 1) + '-' + pad2(date.getDate())
    }

    /** 折叠行里的时间：按天分组之后不再重复日期，只留时分秒（完整时间戳挂 title 与「排查信息」）。 */
    function clockLabel(value) {
      const date = new Date(value)
      if (Number.isNaN(date.getTime())) return String(value ?? '')
      return pad2(date.getHours()) + ':' + pad2(date.getMinutes()) + ':' + pad2(date.getSeconds())
    }

    /**
     * 轨道圆点的颜色（用户 2026-09-18 预览选定）：绿 = 自动批准；黄 = 转人工（还没人管）或黑名单直接拒；
     * 灰 = 已经有人定夺过（人工批准 / 人工拒绝）。
     */
    function dotToneOf(record) {
      if (record.verdict === 'allow') return 'ok'
      if (record.verdict === 'deny') return 'warn'
      return decidedByOf(record) === 'auto' ? 'warn' : 'dim'
    }

    /** 升级/降级按钮组：两种名单 × 两种作用域，作用域真值由宿主按记录里的 cwd 决定。 */
    function RuleActions({ record, onDone }) {
      const [busy, setBusy] = react.useState(false)
      const [error, setError] = react.useState('')
      const [done, setDone] = react.useState(undefined)
      // 可调草稿：默认模型建议 / 本次动作的权限指纹，用户不满意就直接改（用户 2026-09-15 要求）
      const [draft, setDraft] = react.useState(() => ruleDraftOf(record))
      // 作用域（用户 2026-09-18 选定）：两个动作按钮共用它
      const [scope, setScope] = react.useState('project')
      const draftProblem = ruleDraftProblem(draft)
      const patch = next => setDraft(previous => ({ ...previous, ...next }))
      /** 这次动作用不上的条件（没有命令 / 没有路径）：按钮已禁用，这里给一行说明。 */
      const unavailableNote = MATCH_KIND_ORDER.filter(kind => kindApplicable(record, kind) !== true)
        .map(kind => t.ruleKindUnavailable(kindLabel(kind))).join('；')
      /**
       * 换匹配条件：**值立刻按新条件刷新**（用户要求），不会留下「条件 = 命令前缀、值却是签名 key」
       * 这种自相矛盾的组合；换过之后就不再是「模型建议」，提示语也跟着换。
       */
      const chooseKind = kind => {
        // 这次动作根本用不上这个条件（没有命令 / 没有路径）：按钮已禁用，这里再兜一层
        if (kindApplicable(record, kind) !== true) return
        // ① 本地先按新条件推导一个值：不用等模型，界面立刻不空转
        const derived = ruleDraftValueOf(record, kind, draft.value)
        setDraft(previous => ({
          ...previous,
          kind,
          value: derived,
          fromModel: false,
          edited: true,
          source: 'local',
          pending: true,
          error: '',
        }))
        // ② 同时请模型**按这个条件**重新生成（提示词带上条件与当前草稿）；回来时若还停在这个
        //    条件上就覆盖草稿（用户随时可以接着改），换了条件或失败就保留本地推导值
        if (typeof record.id !== 'string' || record.id === '') return
        draftRule(record.id, 'allow', kind, { kind, value: derived, label: draft.label }, record.sessionId)
          .then(data => setDraft(previous => previous.kind === kind
            ? {
              ...previous,
              source: 'model',
              pending: false,
              error: '',
              value: String(data.rule?.match?.value ?? previous.value),
              label: String(data.rule?.label ?? previous.label),
            }
            : previous))
          .catch(cause => setDraft(previous => previous.kind === kind
            ? { ...previous, pending: false, error: String(cause?.message ?? cause) }
            : previous))
      }
      const run = (list, scope) => {
        setBusy(true)
        setError('')
        setDone(undefined)
        promoteRecord(record.id, scope, list, record.sessionId, {
          tool: record.toolName,
          match: { kind: draft.kind, value: draft.value },
          label: draft.label,
        })
          .then(data => {
            setDone(data)
            if (typeof onDone === 'function') onDone()
          })
          .catch(cause => setError(String(cause?.message ?? cause)))
          .finally(() => setBusy(false))
      }
      // 规则文本可能来自「审查时的建议」「现场模型优化」或「权限指纹兜底」，如实写出来；
      // 查重结果也如实写出来（三选一）：已有规则覆盖了这次动作（没写新条目）/ 更新了同一条规则 /
      // 顺带合并掉了几条被新规则覆盖的窄规则——用户一眼能看出「为什么名单没变或变少了」
      // 被这次写入顶掉的旧规则（同名更新掉的那条 + 被覆盖掉的窄规则）**点名列出来**：
      // 「我的规则明明不一样，为什么被覆盖/合并了」必须一眼看明白（用户 2026-09-16）
      const dropped = Array.isArray(done?.dropped) ? done.dropped.map(label => String(label)) : []
      const droppedText = dropped.filter(label => label !== '').join(' / ')
      const dedupeNote = done === undefined
        ? ''
        : done.covered === true
          ? t.appliedCovered
          : (done.replaced === true ? t.appliedReplaced(droppedText) : '')
            + (typeof done.merged === 'number' && done.merged > 0 ? t.appliedMerged(done.merged, droppedText) : '')
      const doneText = done === undefined
        ? undefined
        : (done.optimizedBy === 'signature'
          ? t.appliedFallback
          : done.optimizedBy === 'record' ? t.appliedRecord
            : done.optimizedBy === 'manual' ? t.appliedManual : t.appliedModel)
          + dedupeNote
          + '：' + String(done.rule?.label ?? '')
      /**
       * 作用域选择（用户 2026-09-18 从预览页选定）：原先 4 个按钮（2 个动作 × 2 个作用域）收成
       * 「先选作用域、再点动作」——按钮少一半，点哪个会发生什么也更直白。
       * 没有工作区的记录选「本项目」时由宿主按既有规则降级成全局，回执里的 scope 会如实回报。
       */
      const scopeSeg = react.createElement('span', { className: 'ap-seg', role: 'group', 'aria-label': t.formScope },
        ...['project', 'global'].map(name => react.createElement('button', {
          key: name,
          type: 'button',
          'data-scope': name,
          'data-on': scope === name ? '1' : '0',
          'aria-pressed': scope === name,
          onClick: () => setScope(name),
        }, name === 'project' ? t.scopeProject : t.scopeGlobal)))
      /** 写入按钮：两个动作共用上面选中的作用域。 */
      const actionButton = (list, className, label) => react.createElement('button', {
        type: 'button',
        className: 'ap-btn ' + className,
        disabled: busy || draftProblem !== undefined || typeof record.id !== 'string',
        onClick: () => run(list, scope),
      }, label)
      return react.createElement('div', { className: 'ap-actions' },
        // 三行编辑：匹配条件 / 匹配值 / 规则标签，每行左侧给**可见标签**（用户 2026-09-18 选定）——
        // 原先两个输入框只有 aria-label，界面上看不出哪栏是值、哪栏是标签。
        // 匹配条件用自带的分段按钮，不用原生 <select>：原生下拉的弹层在深色主题下是白底黑字（用户反馈）
        react.createElement('div', { className: 'ap-field' },
          react.createElement('span', { className: 'ap-fieldKey' }, t.ruleKind),
          react.createElement('div', { className: 'ap-seg', role: 'group', 'aria-label': t.ruleKind },
            ...MATCH_KIND_ORDER.map(kind => react.createElement('button', {
              key: kind,
              type: 'button',
              'data-kind': kind,
              'data-on': draft.kind === kind ? '1' : '0',
              'aria-pressed': draft.kind === kind,
              // 这次动作没有命令 / 路径时对应条件禁用：那种规则永远命不中
              disabled: kindApplicable(record, kind) !== true,
              title: kindApplicable(record, kind) === true ? undefined : t.ruleKindUnavailable(kindLabel(kind)),
              onClick: () => chooseKind(kind),
            }, kindLabel(kind))))),
        // 指纹那一行的宽度必须是确定的（ap-fieldFill）：fit-content 的行里长指纹会溢出卡片、
        // 把「复制指纹」挤出卡外（真机截图复现），折行形态要靠确定宽度才折得对
        react.createElement('div', { className: draft.kind === 'signature' ? 'ap-field ap-fieldFill' : 'ap-field' },
          react.createElement('span', { className: 'ap-fieldKey' }, t.ruleValue),
          // 权限指纹：显示渲染后的可视化 + 一键复制（原始串含 NUL，塞进输入框会显示成方框）；
          // 别的条件才是可编辑的输入框。指纹不能手改、又常常上百字符，表单里折行全显示
          draft.kind === 'signature'
            ? react.createElement(FingerprintValue, { value: draft.value, wrap: true })
            : react.createElement('input', {
              className: 'ap-input ap-inputWide',
              'aria-label': t.ruleValue,
              title: draft.value,
              value: draft.value,
              onChange: event => patch({ value: event.target.value }),
            })),
        react.createElement('div', { className: 'ap-field' },
          react.createElement('span', { className: 'ap-fieldKey' }, t.ruleLabelField),
          react.createElement('input', {
            className: 'ap-input ap-inputWide',
            'aria-label': t.ruleLabelField,
            title: draft.label,
            value: draft.label,
            onChange: event => patch({ label: event.target.value }),
          })),
        // 提示按需要出现，且挤成一小块（不与上面的三行编辑抢视觉）
        react.createElement('div', { className: 'ap-hints' },
          draft.kind === 'signature'
            && react.createElement('span', { className: 'ap-note' }, t.fingerprintReadonly),
          react.createElement('span', { className: 'ap-note', title: draft.error === '' ? undefined : draft.error },
            draftHintText(draft)),
          // 选了路径前缀就说明一下通配符口径：只支持单层 *（** 会被宿主拒绝）
          draft.kind === 'path_prefix'
            && react.createElement('span', { className: 'ap-note' }, t.rulePathGlobHint),
          // 命令前缀里的 * 是**字面量**（用户问过「pnpm vitest run tests/* 支持吗」）：提示一句，
          // 别指望它会像 shell 那样展开——想覆盖一类命令就把前缀写短
          draft.kind === 'command_prefix' && draft.value.includes('*')
            && react.createElement('span', { className: 'ap-note' }, t.ruleCommandStarHint),
          // 这次动作用不上的条件（没有命令 / 没有路径）明说一句，别让按钮无声地灰着
          unavailableNote !== ''
            && react.createElement('span', { className: 'ap-note' }, unavailableNote),
          draftProblem !== undefined && react.createElement('span', { className: 'ap-note ap-warn' }, draftProblem)),
        // 作用域一行 + 动作一行：4 个按钮收成「先选作用域、再点动作」
        react.createElement('div', { className: 'ap-actionRow' },
          react.createElement('span', { className: 'ap-fieldKey' }, t.formScope),
          scopeSeg),
        react.createElement('div', { className: 'ap-actionRow' },
          actionButton('allow', 'ap-btnPrimary', t.actionAllow),
          actionButton('deny', 'ap-btnDanger', t.actionDeny)),
        (busy || error !== '' || doneText !== undefined) && react.createElement('div', { className: 'ap-actionRow' },
          busy && react.createElement('span', { className: 'ap-note' }, t.working),
          error !== '' && react.createElement('span', { className: 'ap-note ap-warn' }, error),
          doneText !== undefined && react.createElement('span', {
            className: done.optimizedBy === 'signature' ? 'ap-note ap-warn' : 'ap-note',
          }, doneText)))
    }

    /**
     * 规则条件的来源标（规则卡上的 chip）：先分清「没问过你、达阈值自动写的」与「你确认后写的」，
     * 再说条件从哪来（审查模型的建议 / 现场模型优化 / 本次动作的权限指纹 / 你手填的）。
     * 老记录没有 `optimizedBy` 字段时只说「自动」「手动」，不瞎标来源。
     */
    function ruleSourceLabel(applied) {
      const auto = applied.auto === true
      if (applied.optimizedBy === 'record') return auto ? t.ruleSourceAutoRecord : t.ruleSourceRecord
      if (applied.optimizedBy === 'signature') return auto ? t.ruleSourceAutoFingerprint : t.kindSignature
      if (auto === true) return t.ruleAuto
      if (applied.optimizedBy === 'model') return t.ruleSourceModel
      if (applied.optimizedBy === 'manual') return t.ruleSourceManual
      return t.ruleManual
    }

    /**
     * 「这次写没写规则」的唯一落点（用户 2026-09-18 要求）：原先散在三处——详情里「已应用」那一行、
     * 「本次加入的规则」撤销行、以及「已询问，未加入」，现在合成一张卡：名单/作用域 + 条件来源 + 规则标签
     * + 覆盖/合并/被顶掉的说明 + 撤销按钮。撤销按钮**贴着它撤销的那条规则**，凭据取自记录里的
     * `ruleApplied`（所以刷新页面后照样能撤）；撤销过（`ruleReverted`）就只显示已撤销文案。
     * 「已有规则覆盖这次动作」（covered）一条都没写进去，**不给撤销**（那种 ruleId 指的是别人的规则），
     * 也不声称「已加入」。两件事都没发生时整张卡不渲染。
     */
    function RuleCard({ record, onDone }) {
      const applied = record?.ruleApplied
      const declined = record?.ruleDeclined
      const [busy, setBusy] = react.useState(false)
      const [error, setError] = react.useState('')
      const [undone, setUndone] = react.useState(record?.ruleReverted !== undefined)
      // 「已询问，未加入」（黑名单确认卡上选了「不加入」）：同一张卡的变体
      if (applied === undefined || applied === null) {
        if (declined === undefined || declined === null) return null
        return react.createElement('div', { className: 'ap-ruleCard ap-ruleCardMuted' },
          react.createElement('span', { className: 'ap-note' }, t.ruleAsk),
          // 标签独占一行（用户 2026-09-18 选定「标签优先」）：与 badge 挤在同一行时，
          // 窄栏里标签必被挤成折行、卡里出现孤字
          react.createElement('span', { className: 'ap-ruleCardLabel' }, String(declined.label ?? '')),
          react.createElement('div', { className: 'ap-hitRow' },
            react.createElement('span', { className: 'ap-badge ap-badgeMuted' },
              declined.list === 'deny' ? t.hitDeny : t.hitAllow)),
          react.createElement('span', { className: 'ap-note' }, t.ruleDeclined))
      }
      const covered = applied.covered === true
      const note = appliedNote(applied)
      // 覆盖命中那次 ruleId 指的是**别人的**规则；没有凭据的老记录也不给按钮
      const revertable = covered !== true && typeof applied.ruleId === 'string' && applied.ruleId !== ''
      const dropped = []
      if (applied.previousRule !== undefined && applied.previousRule !== null) {
        dropped.push(String(applied.previousRule.label ?? applied.previousRule.id ?? ''))
      }
      for (const rule of Array.isArray(applied.mergedRules) ? applied.mergedRules : []) {
        dropped.push(String(rule?.label ?? rule?.id ?? ''))
      }
      const droppedText = dropped.filter(label => label !== '').join(' / ')
      /** 撤销这次加入：成功本地置「已撤销」，并让面板重拉记录与策略快照。 */
      const run = () => {
        setBusy(true)
        setError('')
        revertRecord(record.id)
          .then(() => {
            setUndone(true)
            if (typeof onDone === 'function') onDone()
          })
          .catch(cause => setError(String(cause?.message ?? cause)))
          .finally(() => setBusy(false))
      }
      return react.createElement('div', {
        className: 'ap-ruleCard' + (covered ? ' ap-ruleCardMuted' : ''),
      },
        react.createElement('span', { className: 'ap-note' }, t.ruleUndoLabel),
        // 「写了哪条规则」是第一行（用户 2026-09-18 选定「标签优先」）：badge 让到下一行，
        // 否则标签会被挤成折行
        react.createElement('span', { className: 'ap-ruleCardLabel' }, String(applied.label ?? '')),
        react.createElement('div', { className: 'ap-hitRow' },
          react.createElement('span', {
            className: 'ap-badge ' + (covered ? 'ap-badgeMuted' : (applied.list === 'allow' ? 'ap-badgeOk' : 'ap-badgeWarn')),
          }, scopeLabel(applied.scope) + ' · ' + (applied.list === 'allow' ? t.allowList : t.denyList)),
          react.createElement('span', {
            className: 'ap-badge ' + (covered ? 'ap-badgeMuted' : 'ap-badgeInfo'),
          }, ruleSourceLabel(applied))),
        note !== '' && react.createElement('span', { className: 'ap-note' }, note),
        droppedText !== '' && react.createElement('span', { className: 'ap-note ap-warn' }, t.ruleDropped(droppedText)),
        revertable && (undone
          ? react.createElement('span', { className: 'ap-note' }, t.ruleUndone)
          : react.createElement('button', {
            type: 'button',
            className: 'ap-btn',
            disabled: busy || typeof record.id !== 'string',
            onClick: run,
          }, busy ? t.working : t.undoRule)),
        error !== '' && react.createElement('span', { className: 'ap-note ap-warn' }, error))
    }

    /**
     * 结论条上的小 chip（用户 2026-09-18 从预览页选定「融合版」）：风险 / 授权 / 命中名单 / 连续计数。
     * 值可能很长（命中名单带规则标签），所以 CSS 单行截断 + `title` 挂全文。
     */
    function kvChip(text) {
      return react.createElement('span', { className: 'ap-kvChip', title: String(text) }, String(text))
    }

    /**
     * 结论徽标的文案（折叠行的徽标与结论条共用同一套口径，别两处各写一遍）。
     * **命中黑名单转人工**那条记录的 `verdict` 也是 `'defer'`，但它跟「审查未完成」是两回事——
     * 只说成「转人工」，命中细节由结论条的 chip 给出（原先一律显示「审查未完成」，是错的）。
     */
    function verdictLabelOf(record) {
      if (record.verdict === 'allow') return t.autoApproved
      if (record.verdict === 'blacklist-reject') return t.denyRejected
      const deferred = record.verdict === 'deny' || record.policy?.list === 'deny'
      return deferred ? t.referred : t.reviewFailed
    }

    /** 结论条的色调：只有「模型自动放行 + 非高/极高风险」是成功色，其余一律警告色。 */
    function calloutTone(record) {
      const risky = record.riskLevel === 'high' || record.riskLevel === 'critical'
      return record.verdict === 'allow' && risky !== true ? 'ok' : 'warn'
    }

    /**
     * 把记录里的 token 用量格式化成详情里一行的值文本。
     * 只显示记录里确实存在的数字字段：审查失败或提供方不给用量时整行不显示。
     * @param {object|undefined} usage 宿主写入的用量
     * @param {object} t 当前语言的字典
     * @returns {string|undefined} 形如「输入 1200 · 输出 40 · 合计 1240」的文本
     */
    function formatUsage(usage, t) {
      if (usage === null || typeof usage !== 'object') return undefined
      const parts = []
      if (typeof usage.inputTokens === 'number') parts.push(t.usageIn + ' ' + String(usage.inputTokens))
      if (typeof usage.outputTokens === 'number') parts.push(t.usageOut + ' ' + String(usage.outputTokens))
      if (typeof usage.totalTokens === 'number') parts.push(t.usageTotal + ' ' + String(usage.totalTokens))
      return parts.length === 0 ? undefined : parts.join(' · ')
    }

    /**
     * 详情「已应用」那一行的后缀说明：覆盖命中 / 达阈值自动写入各自的措辞。
     * 两者同时成立（达阈值触发自动写入，但已有规则已覆盖这次动作、一条都没写）时只说一句，
     * 免得出现「未重复添加」紧接着「自动加入」这种自相矛盾的读法。
     * @param {object} applied 记录里的 ruleApplied
     * @returns {string} 后缀（无话可说时是空串）
     */
    function appliedNote(applied) {
      if (applied.covered === true) {
        return applied.auto === true ? t.appliedAutoCovered : t.appliedCovered
      }
      return applied.auto === true ? t.appliedAuto(applied.optimizedBy) : ''
    }

    /** 折叠卡行尾的箭头：内联 SVG（文字箭头 ▸ 在窄屏字体下又细又不齐，用户 2026-09-18 反馈不好看）；展开时旋转 90°。 */
    function BlockChevron({ open }) {
      return react.createElement('svg', {
        className: 'ap-blockChevron',
        viewBox: '0 0 16 16',
        width: 12,
        height: 12,
        'aria-hidden': 'true',
      }, react.createElement('path', {
        d: 'M6 3.5 10.5 8 6 12.5',
        fill: 'none',
        stroke: 'currentColor',
        'stroke-width': '1.6',
        'stroke-linecap': 'round',
        'stroke-linejoin': 'round',
      }))
    }

    /**
     * 「加入名单」/「排查信息」的折叠卡（用户 2026-09-18 最终选定「卡头即入口」）：
     * 卡头那一行本身就是开关（行尾 ▸/▾）。底部不再有另一行文字入口——那和卡头标题是同一句话的两处
     * （旧的 `.ap-detailFoot` 已删）。**正文用函数传入**（`render`）而不是 children：收起时连元素都不构造，
     * 「收起」在元素树里就是真的不存在（技术字段不会被顺手渲染出来）。
     * @param {object} props title / hint / open / onToggle / dataUi（稳定的测试锚点）/ render（返回正文元素）
     */
    function FoldCard({ title, hint, open, onToggle, dataUi, render }) {
      return react.createElement('div', { className: 'ap-blockCard' },
        react.createElement('button', {
          type: 'button',
          className: 'ap-blockHead',
          'data-ui': dataUi,
          'aria-expanded': open,
          onClick: onToggle,
        },
          react.createElement('span', { className: 'ap-blockTitle' }, title),
          react.createElement('span', { className: 'ap-blockHint' }, hint),
          react.createElement(BlockChevron, { open })),
        open === true && render())
    }

    /**
     * 单条记录（用户 2026-09-18 从预览页逐项定下的形态）。
     * 折叠态**两行**：第一行「时间 · 工具 · 来源 chip ·（+白名单）· 结论/结果徽标」，第二行审批意见——
     * 命中规则说明与审批意见只能留一个，说明进 chip 的 tooltip（取舍见预览页）。时间**紧贴轨道圆点**：
     * 行头里不再有展开箭头（整行就是按钮 + hover 底色），也不再显示「第几轮第几步」（排查信息里有）。
     * 展开态：背景块把轨道与圆点一起包进来、行头与详情之间一条分割线（整条跨过去）、圆点放大到 10px；
     * 详情依次是结论条、依据、规则卡、两块（「加入名单」与「排查信息」，卡头即入口）。
     * @param {object} props record / open / onToggle / onChanged / first / last（轨道竖线的首尾修剪）
     */
    function RecordRow({ record, open, onToggle, onChanged, first, last }) {
      // 两块（加入名单 / 排查信息）的开合状态**放在行上**：
      // 状态写在子组件里也写得出来，但那样子组件会各自多一个 hook，而「前面那个组件按条件增减 hook」
      // 会挤掉后面组件的 hook 槽位（测试替身按求值顺序分槽，真机 React 里则是条件渲染导致的同类问题），
      // 于是「打开加入名单」会顺手把排查信息关上。放在行上最稳，且开合状态天然按记录隔离。
      const [debugOpen, setDebugOpen] = react.useState(false)
      const [entryOpen, setEntryOpen] = react.useState(false)
      const route = record.route === undefined ? undefined : record.route.provider + '/' + record.route.model
      const suggested = record.suggestedRule === undefined
        ? undefined
        : record.suggestedRule.label + '（' + kindLabel(record.suggestedRule.match?.kind) + '：' + String(record.suggestedRule.match?.value ?? '') + '）'
      // 命中规则信息（只在展开详情里用；折叠态由 HitChip 的 tooltip 承载）
      const hitText = record.policy === undefined
        ? undefined
        : scopeLabel(record.policy.scope) + ' · ' + String(record.policy.label ?? '')
      const approvals = typeof record.approvals === 'number' && record.approvals > 0
        ? String(record.approvals)
        : undefined
      // 审批意见：折叠态也要看得见，展开后是完整文本（CSS 限两行）
      const opinion = typeof record.rationale === 'string' && record.rationale.trim() !== ''
        ? record.rationale
        : undefined
      // 这次审查烧掉的 token（详情里展示，折叠态留给结论与标签）
      const usageText = formatUsage(record.usage, t)
      // 这次动作发生在第几轮第几步（工作流定位用；老记录没有这两个字段时整行不显示）
      const turn = typeof record.turn === 'number' ? record.turn : undefined
      const step = typeof record.step === 'number' ? record.step : undefined
      const turnStep = turn === undefined && step === undefined ? undefined : t.turnStepLabel(turn ?? '?', step ?? '?')
      // 结论条上的 chip：人工侧结论（只对转人工的记录有意义）、风险、授权、命中名单、连续计数
      const calloutChips = [
        record.verdict === 'allow' ? undefined : (outcomeOf(record)?.[0] ?? t.decidedUnknown),
        record.riskLevel === undefined ? undefined : t.risk + ' ' + String(record.riskLevel),
        record.userAuthorization === undefined ? undefined : t.authorization + ' ' + String(record.userAuthorization),
        hitText === undefined ? undefined : t.chipHit(hitText),
        approvals === undefined ? undefined : t.approvals + ' ' + approvals,
        record.denials === undefined || record.denials === 0 ? undefined : t.denials + ' ' + String(record.denials),
      ].filter(text => text !== undefined).map(text => kvChip(text))
      /**
       * 「排查信息」的两组字段（默认收起、不记忆展开状态），用户 2026-09-18 从预览页选定「分组 + 去重」：
       * 去掉 4 行重复或恒空项——「工具」并进指纹行（指纹本身就以工具名开头）、「签名摘要」（与工具 + 命令同义）、
       * 「已自动升级」（`promotedRule` 新记录恒空）、Reviewer 的「0 steps」（单轮审查恒为 0，会话字段也没人写）；
       * 13 行 → 11 行。指纹行带「复制指纹」按钮：排查时最常做的就是拿整串去核对。
       */
      const debugActionFields = [
        // 权限指纹：机器口径的授权范围（可视化 + 复制按钮，整串挂 title 供悬停核对）
        ...(record.signature === undefined
          ? []
          : [react.createElement('div', { key: 'debug-fingerprint', className: 'ap-field' },
            react.createElement('span', { className: 'ap-fieldKey' }, t.signature),
            react.createElement('span', { className: 'ap-fieldVal' },
              react.createElement(FingerprintValue, { value: record.signature.key })))]),
        // 指纹是机器串：紧跟着按它的结构摊开（命令或参数 / 额外参数）
        ...fingerprintFields(record.signature === undefined ? undefined : record.signature.key),
        react.createElement(Field, { key: 'debug-action', label: t.action, value: record.action, mono: true }),
        react.createElement(Field, { key: 'debug-turnStep', label: t.turnStep, value: turnStep }),
      ]
      const debugReviewFields = [
        react.createElement(Field, { key: 'debug-suggestedRule', label: t.suggestedRule, value: suggested }),
        react.createElement(Field, { key: 'debug-decidedBy', label: t.decidedBy, value: decidedByOf(record) === 'auto' ? t.decidedAuto : t.decidedHuman }),
        // 审查用的模型路由（老字段 route，原先只被一个没人看的 Reviewer 行用着）
        react.createElement(Field, { key: 'debug-model', label: t.reviewModel, value: route }),
        react.createElement(Field, { key: 'debug-latency', label: t.latency, value: record.latencyMs === undefined ? undefined : String(record.latencyMs) + ' ms' }),
        react.createElement(Field, { key: 'debug-tokens', label: t.tokens, value: usageText }),
        react.createElement(Field, { key: 'debug-time', label: t.time, value: record.time }),
      ]
      // 轨道竖线要修剪首尾（第一行的线从圆点开始、最后一行到圆点结束），行与行之间用留白分隔——
      // 留白用内边距而不是外边距，隐藏的竖线才会连着穿过去（见预览页踩坑记录）
      const itemClass = ['ap-item']
        .concat(first === true ? ['isFirst'] : [])
        .concat(last === true ? ['isLast'] : [])
        .concat(open === true ? ['open'] : [])
        .concat(last === true ? [] : ['gap'])
        .join(' ')
      const canAddRule = record.signature !== undefined || record.suggestedRule !== undefined
      return react.createElement('li', { className: itemClass },
        react.createElement('span', { className: 'ap-rail', 'aria-hidden': 'true' },
          react.createElement('span', { className: 'ap-railLine' }),
          react.createElement('span', { className: 'ap-dot', 'data-tone': dotToneOf(record) })),
        react.createElement('span', { className: 'ap-body' },
          react.createElement('button', {
            type: 'button', className: 'ap-rowHead', 'aria-expanded': open,
            onClick: onToggle,
          },
            react.createElement('span', { className: 'ap-rowMain' },
              react.createElement('span', { className: 'ap-rowTop' },
                react.createElement('span', { className: 'ap-time', title: String(record.time ?? '') }, clockLabel(record.time)),
                react.createElement('span', { className: 'ap-tool' }, String(record.toolName ?? '?')),
                react.createElement(HitChip, { record }),
                // 右侧徽标独立成组，用 margin-left:auto 顶到行尾：原先靠一个**空的** .ap-grow 撑开，
                // 真机上它被宿主样式影响过，结论徽标不贴右边（用户 2026-09-18 截图反馈）
                react.createElement('span', { className: 'ap-rowBadges' },
                  react.createElement(RuleAutoBadge, { record }),
                  react.createElement(VerdictBadge, { record }),
                  react.createElement(OutcomeBadge, { record }))),
              opinion !== undefined && react.createElement('span', { className: 'ap-opinion', title: opinion }, opinion))),
          open === true && react.createElement('div', { className: 'ap-detailBox' },
            // —— 结论条（用户 2026-09-18 从预览页选定「融合版」）：一眼看到结论与「凭什么」——
            react.createElement('div', { className: 'ap-callout', 'data-tone': calloutTone(record) },
              react.createElement('div', { className: 'ap-calloutTop' },
                react.createElement('span', { className: 'ap-calloutLead' },
                  t.calloutLead(verdictLabelOf(record), t.riskWord(record.riskLevel))),
                ...calloutChips)),
            // —— 依据：审查者结论（second-hand）与申请方原话（first-hand）＋人工拒绝理由 ——
            react.createElement('div', { className: 'ap-group' },
              react.createElement('span', { className: 'ap-groupCaption' }, t.groupBasis),
              react.createElement(Field, { label: t.rationale, value: record.rationale }),
              react.createElement(Field, { label: t.reason, value: record.reason }),
              // 人工补的拒绝理由（追问卡的回答）：与插件/模型意见分开显示
              react.createElement(Field, { label: t.rejectReason, value: record.rejectReason })),
            // 这次写没写规则：唯一落点（原先的「已应用」字段、撤销行与「已询问，未加入」都并进这张卡）
            react.createElement(RuleCard, { record, onDone: onChanged }),
            // —— 两块（用户 2026-09-18 定「卡头即入口」）：卡头那一行就是开关，
            //    展开时内容才渲染；底部不再有第二处文字入口（同一件事的两处文字） ——
            canAddRule && react.createElement(FoldCard, {
              title: t.blockRuleTitle,
              hint: t.blockRuleHint,
              dataUi: 'rule-entry',
              open: entryOpen,
              onToggle: () => setEntryOpen(previous => previous !== true),
              render: () => react.createElement(RuleActions, { record, onDone: onChanged }),
            }),
            react.createElement(FoldCard, {
              title: t.blockDebugTitle,
              hint: t.blockDebugHint,
              dataUi: 'debug-info',
              open: debugOpen,
              onToggle: () => setDebugOpen(previous => previous !== true),
              render: () => react.createElement('div', { className: 'ap-debugBody' },
                react.createElement('div', { className: 'ap-debugGroup' },
                  react.createElement('span', { className: 'ap-debugGroupCaption' }, t.debugGroupAction),
                  ...debugActionFields),
                react.createElement('div', { className: 'ap-debugGroup' },
                  react.createElement('span', { className: 'ap-debugGroupCaption' }, t.debugGroupReview),
                  ...debugReviewFields)),
            }))))
    }

    /**
     * 一组规则的列表：显示标签、来源、匹配条件，并可**编辑**或删除。
     * 编辑走「原地更新」（同一 id）：改完标签或匹配条件就立刻生效，不需要删掉再加一条。
     */
    function RuleList({ scope, list, title, rules, onRemove, onEdit }) {
      const [editing, setEditing] = react.useState(undefined)
      const [draft, setDraft] = react.useState(undefined)
      const [error, setError] = react.useState('')
      /** 进入编辑态：把这条规则摊成草稿。 */
      const begin = rule => {
        setError('')
        setEditing(String(rule.id))
        setDraft({
          id: rule.id,
          tool: rule.tool,
          kind: rule.match?.kind ?? 'signature',
          value: String(rule.match?.value ?? ''),
          label: String(rule.label ?? ''),
          // 这条规则原本是不是权限指纹：决定「值只读」与「能不能切成指纹」（见下面两个判断）
          originalKind: rule.match?.kind ?? 'signature',
        })
      }
      /** 保存：本地先按宿主同口径校验，再把草稿交给面板写回。 */
      const save = () => {
        const problem = ruleDraftProblem(draft)
        if (problem !== undefined) {
          setError(problem)
          return
        }
        setEditing(undefined)
        setError('')
        onEdit(scope, list, draft.id, {
          tool: draft.tool,
          match: { kind: draft.kind, value: draft.value },
          label: draft.label,
        })
      }
      /** 一条规则的展示行（不在编辑态时）。 */
      const rowOf = rule => [
        react.createElement('span', { className: 'ap-ruleLabel', key: 'label' }, String(rule.label ?? '')),
        react.createElement('span', { className: 'ap-badge ap-badgeMuted', key: 'source' }, sourceLabel(rule.source)),
        react.createElement('span', { className: 'ap-badge ap-badgeMuted', key: 'kind' }, kindLabel(rule.match?.kind)),
        // 指纹是机器串（含 NUL 与参数 JSON），列表里给人看的是它摊开后的紧凑文案；原始值挂 title
        react.createElement('span', {
          className: 'ap-mono',
          key: 'value',
          title: String(rule.match?.value ?? ''),
        }, rule.match?.kind === 'signature'
          ? fingerprintShort(rule.match?.value)
          : String(rule.match?.value ?? '').slice(0, 48)),
        react.createElement('button', {
          type: 'button', className: 'ap-btn', key: 'edit', onClick: () => begin(rule),
        }, t.edit),
        react.createElement('button', {
          type: 'button', className: 'ap-btn', key: 'remove', onClick: () => onRemove(scope, list, rule.id),
        }, t.remove),
      ]
      /**
       * 换匹配条件：值也按新条件刷新一下（从权限指纹切到命令前缀时，把签名 key 里的命令取出来当前缀），
       * 免得留下「条件 = 命令前缀、值却是一串签名 key」这种组合。
       */
      /**
       * 设置面板里的两条指纹规则（用户 2026-09-16 要求「指纹不许手改」）：
       * - 本来就是指纹的规则：值只读，只能改标签；
       * - 不是指纹的规则：不能切成指纹——指纹只能由插件从时间线某条记录算出来，没有值可填。
       * 判断依据是**草稿里记下的原始 kind**，不是当前选中的 kind（否则切走再切回来就绕过了）。
       */
      const isFingerprint = draft => (draft?.originalKind ?? 'signature') === 'signature'
      const cannotSwitchToFingerprint = draft => isFingerprint(draft) !== true
      const chooseKind = kind => setDraft(previous => (
        kind === 'signature' && cannotSwitchToFingerprint(previous)
          ? previous
          : {
            ...previous,
            kind,
            value: ruleValueForKind(kind, previous.value),
          }))
      /** 一条规则的编辑行：匹配条件 / 值 / 标签，与时间线那块表单同一套控件（同样不用原生下拉）。 */
      const editorOf = rule => react.createElement('span', { className: 'ap-ruleEditor ap-ruleEditorRow' },
        react.createElement('span', { className: 'ap-seg', role: 'group', 'aria-label': t.ruleKind },
          ...MATCH_KIND_ORDER.map(kind => react.createElement('button', {
            key: kind,
            type: 'button',
            'data-kind': kind,
            'data-on': draft.kind === kind ? '1' : '0',
            'aria-pressed': draft.kind === kind,
            // 权限指纹不能手填：非指纹规则切成指纹没有值可填，按钮直接禁用（用户 2026-09-16 要求）
            disabled: kind === 'signature' && cannotSwitchToFingerprint(draft),
            title: kind === 'signature' && cannotSwitchToFingerprint(draft) ? t.fingerprintLocked : undefined,
            onClick: () => chooseKind(kind),
          }, kindLabel(kind)))),
        draft.kind === 'signature'
          ? react.createElement(FingerprintValue, { value: draft.value, wrap: true })
          : react.createElement('input', {
            className: 'ap-input ap-inputWide',
            'aria-label': t.ruleValue,
            title: draft.value,
            value: draft.value,
            onChange: event => setDraft(previous => ({ ...previous, value: event.target.value })),
          }),
        isFingerprint(draft) && react.createElement('span', { className: 'ap-note' }, t.fingerprintReadonly),
        react.createElement('input', {
          className: 'ap-input ap-inputWide',
          'aria-label': t.ruleLabelField,
          value: draft.label,
          onChange: event => setDraft(previous => ({ ...previous, label: event.target.value })),
        }),
        react.createElement('button', {
          type: 'button', className: 'ap-btn ap-btnPrimary', onClick: save,
        }, t.saveEdit),
        react.createElement('button', {
          type: 'button', className: 'ap-btn', onClick: () => setEditing(undefined),
        }, t.cancelEdit))
      return react.createElement('div', null,
        react.createElement('div', { className: 'ap-subTitle' }, title),
        rules.length === 0
          ? react.createElement('div', { className: 'ap-note' }, t.emptyList)
          : react.createElement('ul', { className: 'ap-ruleList' },
            rules.map(rule => react.createElement('li', { className: 'ap-rule', key: String(rule.id) },
              ...(editing === String(rule.id) && draft !== undefined ? [editorOf(rule)] : rowOf(rule))))),
        error !== '' && react.createElement('div', { className: 'ap-note ap-warn' }, error))
    }

    /** 设置页卡片 / 审批设置面板共用的放置位置选择器（写宿主设置命名空间，即时重挂）。 */
    function PlacementControl() {
      const [value, setValue] = react.useState(() => placementStore.value)
      const [error, setError] = react.useState('')
      react.useEffect(() => runtimeStore.subscribe(setValue), [])
      const choose = (next) => {
        setError('')
        const previous = placementStore.value
        setValue(next)
        runtimeStore.save({ placement: next }).catch(cause => {
          console.warn(LOG, '保存 placement 失败', cause)
          setValue(previous)
          setError(String(cause?.message ?? cause))
        })
      }
      const options = [
        ['auto', t.placementAuto],
        ['tab', t.placementTab],
        ['sidebar', t.placementSidebar],
        ['all', t.placementAll],
      ]
      return react.createElement('div', { className: 'ap-row2' },
        react.createElement('span', { className: 'ap-fieldKey' }, t.placementTitle),
        react.createElement('div', { className: 'ap-seg' },
          options.map(([id, label]) => react.createElement('button', {
            key: id, type: 'button', 'data-on': value === id ? '1' : '0', onClick: () => choose(id),
          }, label))),
        error !== '' && react.createElement('span', { className: 'ap-note' }, error))
    }

    /**
     * 一行设置：标题 + switch（轨道 + 滑块）+ 说明。状态由原生 checkbox 承载（可键盘操作、
     * 读屏可识别），宿主每次审批时读设置，所以拨动即生效。保存失败由调用方回滚并提示。
     * @param props.label 标题、props.hint 说明、props.value 当前值、props.onChange 写值
     */
    function SwitchRow({ label, hint, value, onChange }) {
      return react.createElement('div', { className: 'ap-row2' },
        react.createElement('span', { className: 'ap-fieldKey' }, label),
        react.createElement('label', { className: 'ap-switch' },
          react.createElement('input', {
            type: 'checkbox',
            className: 'ap-switchInput',
            checked: value === true,
            onChange: event => onChange(event.target.checked === true),
          }),
          react.createElement('span', { className: 'ap-switchTrack', 'aria-hidden': 'true' }),
          react.createElement('span', { className: 'ap-switchText' }, value === true ? t.switchOn : t.switchOff)),
        react.createElement('span', { className: 'ap-note' }, hint))
    }

    /**
     * 四个行为开关的键 + 文案（设置页卡片与「审批设置」面板共用同一份顺序）。
     * 2026-10-09 起「自动打开审批时间线」也是全局值，两处用同一句说明。
     */
    function behaviorSwitchSpecs() {
      return [
        { key: 'notice', label: t.noticeTitle, hint: t.noticeHint },
        { key: 'denyDirect', label: t.denyDirectTitle, hint: t.denyDirectHint },
        { key: 'autoOpenTimeline', label: t.autoOpenTitle, hint: t.autoOpenHint },
        { key: 'askRejectReason', label: t.askReasonTitle, hint: t.askReasonHint },
      ]
    }

    /**
     * 行为开关组：注入审批结果到上下文 / 黑名单直接拒绝 / 自动打开审批时间线 / 拒绝后追问理由。
     * 四个值都来自宿主 /config；写回是**先乐观置本地值**，失败回滚并提示，
     * 绝不让界面显示一个没写进宿主的状态。设置页卡片与「审批设置」面板都渲染这一个组件。
     * **「自动打开审批时间线」2026-10-09 起也是全局开关**（此前按会话 / 按工作区）：面板与设置页卡片
     * 显示、写入的都是同一个值（本插件行的 config），所有会话跟随它。
     */
    function BehaviorSettings() {
      const [, bump] = react.useState(0)
      const [saved, setSaved] = react.useState(false)
      const [error, setError] = react.useState('')
      react.useEffect(() => runtimeStore.subscribe(() => bump(value => value + 1)), [])
      /** 写一个开关：乐观置值 → 写宿主 → 成功提示 / 失败回滚。 */
      const save = (key, next) => {
        setError('')
        setSaved(false)
        const previous = runtimeStore[key]
        runtimeStore[key] = next
        runtimeStore.emit()
        runtimeStore.save({ [key]: next })
          .then(() => { setSaved(true); bump(value => value + 1) })
          .catch(cause => {
            console.warn(LOG, '保存界面偏好失败', cause)
            runtimeStore[key] = previous
            runtimeStore.emit()
            setError(t.saveFailed + '：' + String(cause?.message ?? cause))
          })
      }
      return react.createElement('div', { className: 'ap-col' },
        ...behaviorSwitchSpecs().map(spec => react.createElement(SwitchRow, {
          key: spec.key,
          label: spec.label,
          hint: spec.hint,
          value: runtimeStore[spec.key],
          onChange: next => save(spec.key, next),
        })),
        saved && react.createElement('div', { className: 'ap-note' }, t.savedTip),
        error !== '' && react.createElement('div', { className: 'ap-note ap-warn' }, error))
    }

    /**
     * 渲染一张卡片：设置页插件卡与对话区面板共用同一套外观。
     * 设置页的容器是 ul，所以那里必须传 'li'——传 div 会拿不到任何卡片样式，
     * 表现就是「设置里只有一段裸文字」。
     */
    function card(tag, title, desc, children) {
      const body = children === undefined || children === null
        ? []
        : Array.isArray(children) ? children : [children]
      return react.createElement(tag, { className: 'ap-card' },
        react.createElement('div', { className: 'ap-cardHead' },
          react.createElement('div', { className: 'ap-cardText' },
            react.createElement('div', { className: 'ap-cardName' }, title),
            desc === undefined || desc === '' ? null : react.createElement('div', { className: 'ap-cardDesc' }, desc))),
        react.createElement.apply(null, ['div', { className: 'ap-cardBody' }].concat(body)))
    }

    /**
     * 一行「可搜候选 + 可手填 + 可清空」的输入：焦点在输入框上时在下面列出候选（点一下填进去），
     * 也可以直接输入目录里没有的值。清空由调用方处理——路由两列必须一起清（半套会被宿主拒绝）。
     * @param props.label 行标签 / props.value 当前值 / props.options 候选 [{id,name}]
     * @param props.hint 说明 / props.placeholder 占位 / props.onChange 值变化 / props.onClear 清空
     */
    function ComboField({ label, value, options, hint, placeholder, onChange, onClear }) {
      const [open, setOpen] = react.useState(false)
      const keyword = String(value ?? '').trim().toLowerCase()
      const list = options ?? []
      // 空关键字 = 列出全部候选（方便「不知道有哪些」时直接挑），最多 12 条
      const shown = list.filter(option => keyword === ''
        || option.id.toLowerCase().includes(keyword)
        || String(option.name ?? '').toLowerCase().includes(keyword)).slice(0, 12)
      return react.createElement('div', { className: 'ap-col' },
        react.createElement('div', { className: 'ap-row2' },
          react.createElement('span', { className: 'ap-fieldKey' }, label),
          react.createElement('div', { className: 'ap-combo' },
            react.createElement('input', {
              className: 'ap-input ap-inputWide',
              value: value ?? '',
              placeholder,
              'aria-label': label,
              onFocus: () => setOpen(true),
              onBlur: () => setOpen(false),
              onChange: event => { setOpen(true); onChange(event.target.value) },
            }),
            react.createElement('button', { type: 'button', className: 'ap-btn', onClick: onClear }, t.modelClear)),
          hint === undefined ? null : react.createElement('span', { className: 'ap-note' }, hint)),
        open && shown.length > 0 && react.createElement('div', { className: 'ap-comboMenu' },
          shown.map(option => react.createElement('button', {
            key: option.id,
            type: 'button',
            // 按下时不让输入框失焦：否则点击还没到 onClick，候选列表就先被 onBlur 收起来了
            onMouseDown: event => event.preventDefault(),
            onClick: () => { onChange(option.id); setOpen(false) },
          }, option.name === undefined || option.name === '' || option.name === option.id
            ? option.id
            : option.id + ' · ' + option.name))),
        open && list.length > 0 && shown.length === 0 && react.createElement('div', { className: 'ap-note' }, t.catalogEmpty))
    }

    /**
     * 「审查模型」卡片：提供方 / 模型 / 思考强度 / 审查超时 / 输出上限。
     * 写回走 /config（宿主落进本插件行的 config，所有会话生效）；路由两列要么都给、要么都空
     * （都空 = 跟随当前会话），所以「清空」一次清两列，提交时也总是成对提交。
     * @param props.tag 宿主标签（对话区面板传 'section'）
     */
    function ReviewModelCard({ tag }) {
      const [, bump] = react.useState(0)
      const [draft, setDraft] = react.useState(undefined)
      const [saved, setSaved] = react.useState(false)
      const [error, setError] = react.useState('')
      react.useEffect(() => runtimeStore.subscribe(() => bump(value => value + 1)), [])
      react.useEffect(() => {
        void modelCatalogStore.load()
        return modelCatalogStore.subscribe(() => bump(value => value + 1))
      }, [])

      const stored = runtimeStore.model
      const valueOf = key => draft?.[key] ?? String(stored[key] ?? '')
      const set = (key, value) => {
        setSaved(false)
        setError('')
        setDraft(previous => ({ ...(previous ?? {}), [key]: value }))
      }
      /** 清空路由两列 = 跟随当前会话（只清一列会写成半套，宿主会 400）。 */
      const clearRoute = () => {
        setSaved(false)
        setError('')
        setDraft(previous => ({ ...(previous ?? {}), reviewerProvider: '', reviewerModel: '' }))
      }
      const save = () => {
        setError('')
        setSaved(false)
        const timeoutMs = Number.parseInt(valueOf('timeoutMs'), 10)
        const maxOutputTokens = Number.parseInt(valueOf('maxOutputTokens'), 10)
        if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0
          || !Number.isSafeInteger(maxOutputTokens) || maxOutputTokens <= 0) {
          setError(t.modelNumbersInvalid)
          return
        }
        const patch = {
          reviewerProvider: valueOf('reviewerProvider').trim(),
          reviewerModel: valueOf('reviewerModel').trim(),
          reviewerReasoningEffort: valueOf('reviewerReasoningEffort').trim(),
          timeoutMs,
          maxOutputTokens,
        }
        runtimeStore.save(patch).then(() => {
          setSaved(true)
          setDraft(undefined)
        }).catch(cause => {
          console.warn(LOG, '保存审查模型配置失败', cause)
          setError(t.saveFailed + '：' + String(cause?.message ?? cause))
        })
      }

      const provider = valueOf('reviewerProvider').trim()
      const model = valueOf('reviewerModel').trim()
      const catalogNote = modelCatalogStore.status === 'failed'
        ? modelCatalogStore.error
        : modelCatalogStore.status === 'loading'
          ? t.catalogLoading
          : modelCatalogStore.status === 'ready' && modelCatalogStore.groups.length === 0
            ? t.catalogEmpty
            : t.modelClearHint
      return card(tag ?? 'section', t.modelTitle, t.modelDesc, react.createElement('div', { className: 'ap-col' },
        react.createElement(ComboField, {
          label: t.modelProvider,
          value: valueOf('reviewerProvider'),
          options: modelCatalogStore.providers(),
          hint: t.modelProviderHint,
          placeholder: t.modelPlaceholder,
          onChange: value => set('reviewerProvider', value),
          onClear: clearRoute,
        }),
        react.createElement(ComboField, {
          label: t.modelName,
          value: valueOf('reviewerModel'),
          options: modelCatalogStore.modelsOf(provider),
          hint: t.modelProviderHint,
          placeholder: t.modelPlaceholder,
          onChange: value => set('reviewerModel', value),
          onClear: clearRoute,
        }),
        react.createElement(ComboField, {
          label: t.modelEffort,
          value: valueOf('reviewerReasoningEffort'),
          options: modelCatalogStore.effortsOf(provider, model),
          hint: t.modelEffortHint,
          placeholder: t.modelPlaceholder,
          onChange: value => set('reviewerReasoningEffort', value),
          onClear: () => set('reviewerReasoningEffort', ''),
        }),
        react.createElement('div', { className: 'ap-row2' },
          react.createElement('span', { className: 'ap-fieldKey' }, t.modelTimeout),
          react.createElement('input', {
            className: 'ap-input ap-inputNum',
            type: 'number',
            min: '1',
            value: valueOf('timeoutMs'),
            'aria-label': t.modelTimeout,
            onChange: event => set('timeoutMs', event.target.value),
          }),
          react.createElement('span', { className: 'ap-note' }, t.modelTimeoutHint)),
        react.createElement('div', { className: 'ap-row2' },
          react.createElement('span', { className: 'ap-fieldKey' }, t.modelMaxTokens),
          react.createElement('input', {
            className: 'ap-input ap-inputNum',
            type: 'number',
            min: '1',
            value: valueOf('maxOutputTokens'),
            'aria-label': t.modelMaxTokens,
            onChange: event => set('maxOutputTokens', event.target.value),
          }),
          react.createElement('span', { className: 'ap-note' }, t.modelMaxTokensHint)),
        react.createElement('div', { className: 'ap-row2' },
          react.createElement('button', { type: 'button', className: 'ap-btn ap-btnPrimary', onClick: save }, t.modelSave),
          saved && react.createElement('span', { className: 'ap-note' }, t.modelSaved)),
        react.createElement('div', { className: 'ap-note' }, catalogNote),
        error !== '' && react.createElement('div', { className: 'ap-note ap-warn' }, error)))
    }

    /**
     * 设置卡片：面板显示在哪里（写宿主设置命名空间、即时重挂）+ 三个行为开关
     * （注入审批结果到上下文 / 黑名单直接拒绝 / 自动打开审批时间线）。
     * 设置页（容器是 ul，所以必须是 li）与「审批设置」面板共用同一套内容。
     * @param props.tag 宿主标签（设置页传 'li'，对话区面板传 'section'）
     * @param props.desc 卡片说明（设置页多一句：这里还能开关通知与黑名单行为）
     */
    function SettingsCard({ tag, desc }) {
      return card(tag ?? 'section', t.cardName, desc ?? t.placementDesc, react.createElement('div', { className: 'ap-col' },
        react.createElement(PlacementControl, null),
        react.createElement(BehaviorSettings, null)))
    }

    /**
     * 对话标签页「审批设置」：连续放行阈值 + 项目/全局两级的白名单与黑名单。
     * 时间线不在这里——它只在右侧栏，两者刻意分开，避免对话区被审批噪声占满。
     */
    function ApprovalSettingsPanel(props) {
      const sessionId = typeof props.sessionId === 'string' ? props.sessionId : ''
      const [cwd, setCwd] = react.useState(() => workspaceOf(sessionId))
      const [error, setError] = react.useState('')
      // 编辑规则的结果（合并掉了哪些窄规则）：只影响这一行的提示，不影响列表本身
      const [editNote, setEditNote] = react.useState('')
      const [saved, setSaved] = react.useState(false)
      const [thresholdDraft, setThresholdDraft] = react.useState({})
      const [revision, setRevision] = react.useState(0)

      react.useEffect(() => policyStore.subscribe(() => setRevision(value => value + 1)), [])

      react.useEffect(() => {
        let alive = true
        /** 项目目录：先问宿主 sessions 服务；拿不到就退回本会话最新一条记录里的 cwd。 */
        const resolve = async () => {
          let next = workspaceOf(sessionId)
          if (next === undefined && sessionId !== '') {
            try {
              const response = await fetch(API_LOG + '?session=' + encodeURIComponent(sessionId) + '&limit=1', {
                headers: { accept: 'application/json' },
              })
              const data = await response.json()
              const first = Array.isArray(data?.records) ? data.records[0] : undefined
              if (first !== undefined && typeof first.cwd === 'string' && first.cwd !== '') next = first.cwd
            } catch (cause) {
              console.warn(LOG, '读取审批记录以推断项目目录失败', cause)
            }
          }
          if (!alive) return
          setCwd(next)
          await policyStore.load(next)
        }
        void resolve()
        const timer = setInterval(() => { void resolve() }, POLL_MS)
        return () => { alive = false; clearInterval(timer) }
      }, [sessionId])

      const snapshot = policyStore.value
      const globalRules = snapshot?.global ?? { allow: [], deny: [] }
      const projectRules = snapshot?.project
      // 阈值分两侧：allow=连续放行后询问是否加入白名单，deny=连续被拒后询问是否加入黑名单。
      const thresholds = snapshot?.thresholds ?? { allow: snapshot?.threshold }
      const shownThreshold = list => thresholdDraft[list] === undefined
        ? String(thresholds[list] ?? '')
        : thresholdDraft[list]
      const editThreshold = (list, value) => {
        setThresholdDraft(previous => ({ ...previous, [list]: value }))
        setSaved(false)
      }

      const save = () => {
        setError('')
        setSaved(false)
        // 只提交合法值：数字框里留空或写脏值时，那一侧保持原样
        const writes = ['allow', 'deny']
          .map(list => ({ list, value: Number.parseInt(shownThreshold(list), 10) }))
          .filter(entry => Number.isSafeInteger(entry.value) && entry.value >= 1)
        Promise.all(writes.map(entry => policyStore.post({ op: 'threshold', list: entry.list, threshold: entry.value })))
          .then(() => { setSaved(true); setThresholdDraft({}) })
          .catch(cause => setError(String(cause?.message ?? cause)))
      }
      const remove = (scope, list, id) => {
        setError('')
        setEditNote('')
        policyStore.post({ op: 'remove', scope, list, id, cwd })
          .catch(cause => setError(String(cause?.message ?? cause)))
      }
      /**
       * 编辑一条已有规则（按 id 原地更新）：改完立刻写宿主并回读快照。
       * 改宽之后可能把别的窄规则盖住（宿主按同一套口径合并掉）——那样名单会少条目，
       * 所以把被顶掉的规则标签如实显示出来（用户 2026-09-16 要求「说清楚」）。
       */
      const editRule = (scope, list, id, rule) => {
        setError('')
        setEditNote('')
        policyStore.post({ op: 'update', scope, list, id, rule, cwd })
          .then(data => {
            const dropped = Array.isArray(data.dropped)
              ? data.dropped.map(label => String(label)).filter(label => label !== '')
              : []
            const merged = Number.isSafeInteger(data.merged) ? data.merged : 0
            const note = (data.replaced === true ? t.appliedReplaced('') : '')
              + (merged > 0 ? t.appliedMerged(merged, dropped.join(' / ')) : '')
            setEditNote(note)
          })
          .catch(cause => setError(String(cause?.message ?? cause)))
      }
      void revision
      // 内容列与消息列同宽并居中：一屏一卡，卡片外观与设置页保持一致
      return react.createElement('div', { className: 'ap-root' },
        react.createElement('div', { className: 'ap-frame' },
          react.createElement('div', { className: 'ap-col' },
            card('section', t.settingsTitle, t.settingsDesc, [
              [['allow', t.thresholdLabel, t.thresholdHintAllow], ['deny', t.thresholdLabelDeny, t.thresholdHintDeny]]
                .map(([list, label, hint]) => react.createElement('div', { className: 'ap-row2', key: list },
                  react.createElement('span', { className: 'ap-fieldKey' }, label),
                  react.createElement('input', {
                    className: 'ap-input',
                    type: 'number',
                    min: '1',
                    value: shownThreshold(list),
                    onChange: event => editThreshold(list, event.target.value),
                  }),
                  react.createElement('span', { className: 'ap-note' }, t.thresholdUnit),
                  react.createElement('span', { className: 'ap-note' }, hint))),
              react.createElement('div', { className: 'ap-row2' },
                react.createElement('button', { type: 'button', className: 'ap-btn', onClick: save }, t.save),
                saved && react.createElement('span', { className: 'ap-note' }, t.saved)),
              react.createElement('div', { className: 'ap-note' }, t.ruleAskNote),
            ]),
            card('section', t.globalScope, undefined, [
              react.createElement(RuleList, { scope: 'global', list: 'allow', title: t.allowList, rules: globalRules.allow, onRemove: remove, onEdit: editRule }),
              react.createElement(RuleList, { scope: 'global', list: 'deny', title: t.denyList, rules: globalRules.deny, onRemove: remove, onEdit: editRule }),
            ]),
            cwd === undefined
              ? card('section', t.projectScope, t.projectUnknown, null)
              : card('section', t.projectScope + ' · ' + cwd, undefined, [
                react.createElement(RuleList, { scope: 'project', list: 'allow', title: t.allowList, rules: projectRules?.allow ?? [], onRemove: remove, onEdit: editRule }),
                react.createElement(RuleList, { scope: 'project', list: 'deny', title: t.denyList, rules: projectRules?.deny ?? [], onRemove: remove, onEdit: editRule }),
              ]),
            // 行为开关与设置页卡片是同一份全局值（自动打开时间线不再按会话区分）
            react.createElement(SettingsCard, { tag: 'section' }),
            // 审查模型（全局配置：写回插件行的 config，所有会话生效）
            react.createElement(ReviewModelCard, { tag: 'section' }),
            editNote !== '' && react.createElement('div', { className: 'ap-note' }, editNote),
            (error !== '' || policyStore.error !== '')
              && react.createElement('div', { className: 'ap-note' }, error !== '' ? error : policyStore.error))))
    }

    /**
     * 右侧栏「审批时间线」的 chip：图标 + 标题 + 未读角标。
     *
     * 官方只允许在**标题席位**里做「会变的标题」（tab 类型的 title(address) 在 tab 打开时就被记进
     * 布局，之后不再变——读 dsh-client-ui-sidebar-right 的 README 确认），所以角标只能挂在这里。
     * 它正是「自动展开不动」的两种情况的提示：审批发生在别的会话、右侧栏展开着停在别的工具上。
     */
    function TimelineTabTitle() {
      const [, bump] = react.useState(0)
      react.useEffect(() => unreadStore.subscribe(() => bump(value => value + 1)), [])
      return react.createElement('span', { className: 'ap-tabTitle' },
        // 角标放在**最前面**（用户 2026-09-20）：chip 里第一眼就要看到「有几条没看」，
        // 图标与标题跟在它后面
        unreadStore.countFor(unreadStore.current) > 0
          ? react.createElement('span', {
            className: 'ap-tabBadge',
            title: t.unreadTitle,
          }, String(unreadStore.countFor(unreadStore.current)))
          : null,
        react.createElement(LogGlyph, { size: 16 }),
        react.createElement('span', { className: 'ap-tabLabel' }, t.timelineTab))
    }

    /** 右侧栏「审批时间线」：倒序记录，展开即可把某条记录升级/降级成规则。 */
    function ApprovalTimelinePanel(props) {
      const sessionId = typeof props.sessionId === 'string' ? props.sessionId : ''
      const info = typeof props.useTabInfo === 'function' ? props.useTabInfo() : undefined
      // 右侧栏 tab 隐藏时暂停轮询；对话标签页没有这个信号，保持轮询。
      const visible = info === undefined || info?.tab?.visible !== false
      // 自动打开的判定要读「时间线是不是正显示在眼前」（面板挂载 + tab 可见）：收起侧栏、
      // 切到别的 tab 都算没打开。useTabInfo 缺失（单测里没有宿主 hook）时按「打开」处理——
      // 面板都在渲染了，它就确实显示着。
      react.useEffect(() => {
        mountState.timelineShown = visible
        // 显示在眼前 = **这个会话**的这些记录你已经看到了：该会话的角标清零，并记下「看过的时刻」
        // （切会话判定据此知道你是不是刚看过它）。别的会话的未读不在这里动——角标按会话隔离。
        if (visible && sessionId !== '') {
          unreadStore.setCurrent(sessionId)
          unreadStore.clear(sessionId)
          unreadStore.markSeen(sessionId)
        }
        return () => { mountState.timelineShown = false }
      }, [visible, sessionId])
      /**
       * 时间线**已经打开**时，任意操作（点一下、聚焦、滚动、滚轮、敲键盘）都算「你看过了」→ 清角标
       * （用户 2026-09-20 要求）。只在可见时装监听：tab 没显示在眼前时角标必须留着，那才是它的用处。
       * 必须用捕获阶段——scroll 不冒泡，只有捕获才能收到内层滚动容器（.ap-list）的滚动事件；
       * 单测环境没有 document，跳过这一段（组件自身的 onScroll 等入口照样能触发）。
       */
      react.useEffect(() => {
        if (!visible) return undefined
        if (typeof document === 'undefined' || typeof document.addEventListener !== 'function') return undefined
        const clear = () => {
          unreadStore.clear(sessionId)
          unreadStore.markSeen(sessionId)
        }
        const events = ['scroll', 'pointerdown', 'focusin', 'keydown', 'wheel', 'touchstart']
        for (const name of events) document.addEventListener(name, clear, true)
        return () => {
          for (const name of events) document.removeEventListener(name, clear, true)
        }
      }, [visible, sessionId])
      const [state, setState] = react.useState({ records: [], error: '', loaded: false })
      const [openId, setOpenId] = react.useState('')
      // 快捷筛选：多选叠加（空数组 = 不筛选，显示全部）
      const [filters, setFilters] = react.useState([])

      // 只看本次会话（用户 2026-09-18：面板上的「本次会话 / 全部会话」切换不要了）。
      // 记录里的 sessionId 等字段一律保留，宿主的 /log 接口也照旧支持不带 session 查全部，
      // 只是界面不再提供那个入口。
      const key = sessionId
      const load = react.useCallback(async () => {
        const query = sessionId !== '' ? '?session=' + encodeURIComponent(sessionId) : ''
        try {
          const response = await fetch(API_LOG + query, { headers: { accept: 'application/json' } })
          const data = await response.json()
          if (data !== null && typeof data === 'object' && data.ok === true && Array.isArray(data.records)) {
            setState({ records: data.records, error: '', loaded: true })
            return
          }
          setState(previous => ({ records: previous.records, error: String(data?.error ?? 'bad response'), loaded: true }))
        } catch (error) {
          setState(previous => ({ records: previous.records, error: String(error?.message ?? error), loaded: true }))
        }
      }, [sessionId])

      react.useEffect(() => {
        let alive = true
        // 时间线也要有一份策略快照：命中 chip 的「自动 / 手动」靠它反查规则来源
        void policyStore.load()
        const tick = () => {
          if (alive && (visible || state.loaded === false)) void load()
        }
        tick()
        const timer = setInterval(tick, POLL_MS)
        return () => { alive = false; clearInterval(timer) }
      }, [key, visible, load, state.loaded])

      const records = state.records
      const auto = records.filter(record => record.verdict === 'allow').length
      // 各筛选键在当前会话范围下的条数：为 0 也显示，用户据此判断点下去会不会空
      const filterCounts = {}
      for (const key of FILTER_KEYS) {
        filterCounts[key] = records.filter(record => matchesFilter(record, key)).length
      }
      // 多选叠加：点亮多个时显示满足任一条件的记录（并集）；一个都没点亮就是全部
      const shown = filters.length === 0
        ? records
        : records.filter(record => filters.some(key => matchesFilter(record, key)))
      /** 切换一个筛选键：已点亮就取消，未点亮就叠加。 */
      const toggleFilter = key => {
        setFilters(previous => previous.includes(key)
          ? previous.filter(item => item !== key)
          : [...previous, key])
      }
      // 按天分组（用户 2026-09-18 定）：日期交给组标题，行头里只留时分秒。时间认不出来的记录
      // 落到空标题那一组，行为上等价于不分组。
      const groups = []
      for (const record of shown) {
        const label = dayLabelOf(record.time)
        const lastGroup = groups[groups.length - 1]
        if (lastGroup === undefined || lastGroup.label !== label) groups.push({ label, records: [record] })
        else lastGroup.records.push(record)
      }
      /** 记录的身份 key：展开状态与 React key 都用它。 */
      const keyOf = record => String(record.id ?? record.time)
      // 升级/降级成功后同时刷新记录与策略快照：记录上会回写「已应用」，设置面板同步见到新规则
      const refresh = () => { void load(); void policyStore.load() }
      /** 面板内的任意交互 = 你看过了（与上面 document 级监听同一个目的，单测从这里驱动）。 */
      const seen = () => {
        unreadStore.clear(sessionId)
        unreadStore.markSeen(sessionId)
      }
      return react.createElement('div', {
        className: 'ap-root',
        onScroll: seen,
        onPointerDown: seen,
        onFocus: seen,
        onKeyDown: seen,
        onWheel: seen,
      },
        react.createElement('div', { className: 'ap-head' },
          react.createElement('div', { className: 'ap-grow' },
            react.createElement('div', { className: 'ap-title' }, t.title),
            react.createElement('div', { className: 'ap-sub' }, t.subtitle + ' · ' + auto + '/' + records.length)),
          react.createElement('button', { type: 'button', className: 'ap-btn', onClick: refresh }, t.reload)),
        state.error !== '' && react.createElement('div', { className: 'ap-error' }, state.error),
        react.createElement('div', { className: 'ap-filters' },
          react.createElement('button', {
            type: 'button',
            className: 'ap-chip',
            'data-filter': 'all',
            'data-on': filters.length === 0 ? '1' : '0',
            onClick: () => setFilters([]),
          }, t.filterAll, react.createElement('span', { className: 'ap-chipCount' }, String(records.length))),
          ...FILTER_KEYS.map(key => react.createElement('button', {
            key,
            type: 'button',
            className: 'ap-chip',
            'data-filter': key,
            'data-on': filters.includes(key) ? '1' : '0',
            onClick: () => toggleFilter(key),
          }, filterLabel(key), react.createElement('span', { className: 'ap-chipCount' }, String(filterCounts[key]))))),
        shown.length === 0
          ? react.createElement('div', { className: 'ap-empty' },
            state.loaded === false ? t.loading : (records.length === 0 ? t.empty : t.filterEmpty))
          : react.createElement('ul', { className: 'ap-list' },
            ...groups.flatMap(group => [
              // 组标题不是轨道上的一行：两条记录之间隔着一天的标题，所以每组的首尾都要修剪竖线
              ...(group.label === ''
                ? []
                : [react.createElement('li', { key: 'day-' + group.label, className: 'ap-dayGroup' }, group.label)]),
              ...group.records.map((record, index) => react.createElement(RecordRow, {
                key: keyOf(record),
                record,
                open: openId === keyOf(record),
                onToggle: () => setOpenId(previous => previous === keyOf(record) ? '' : keyOf(record)),
                onChanged: refresh,
                first: index === 0,
                last: index === group.records.length - 1,
              })),
            ])))
    }

    /** 客户端插件入口：按 placement 决定挂载审批设置标签页、时间线 tab 或两者。 */
    function apply(ctx) {
      try {
        applyInner(ctx)
      } catch (error) {
        beacon('error', String(error?.message ?? error))
        console.warn(LOG, '客户端半 apply 失败', error)
        throw error
      }
    }

    /** 真正的挂载逻辑；外层包一层 try/catch 只为把失败上报成信标。 */
    function applyInner(ctx) {
      beacon('apply')
      // 档位图标与 slots 无关，放在 slots 判空之前，没有面板时也照样补图标
      installPresetIcon()
      clientCtx = ctx
      const slots = ctx.get('slots')
      if (slots === undefined) {
        beacon('no-slots')
        console.warn(LOG, '没有 slots 服务，审批面板未注册')
        return
      }
      // 复用模块级挂载状态：自动打开时间线要能看到「右侧栏 tab 是否已注册」
      const mounted = mountState
      mounted.tab = undefined
      mounted.sidebar = undefined
      let lastKey = ''

      /** 对话区标签页：只放「审批设置」，时间线不再出现在这里。 */
      const mountTab = () => {
        if (mounted.tab !== undefined) return
        mounted.tab = slots.inject('conversation.view', () => {
          try {
            const dispose = slots.register({
              name: 'conversation.view',
              id: VIEW_ID,
              order: 30,
              label: () => t.policyTab,
            }, props => react.createElement(ApprovalSettingsPanel, props))
            beacon('view-registered')
            return dispose
          } catch (error) {
            beacon('view-error', String(error?.message ?? error))
            throw error
          }
        })
      }

      /** 右侧栏 tab：审批时间线（含升级/降级操作）。座位按契约可选。 */
      const mountSidebar = () => {
        if (mounted.sidebar !== undefined) return
        mounted.sidebar = ctx.inject(['sidebarRightTabs'], raw => {
          const tabs = raw?.sidebarRightTabs
          if (tabs === undefined || typeof tabs.register !== 'function') return undefined
          const disposers = []
          const own = (result) => {
            if (typeof result === 'function') disposers.push(result)
          }
          try {
            own(tabs.register({
              id: SIDEBAR_ID,
              kind: SIDEBAR_KIND,
              title: () => t.timelineTab,
              guide: [{
                order: 30,
                title: () => t.timelineTab,
                description: () => t.guideDescription,
                icon: LogGlyph,
              }],
            }))
            own(raw.slots.inject('sidebar.right.pane.tab', () => raw.slots.register({
              name: 'sidebar.right.pane.tab',
              key: SIDEBAR_ID,
            }, props => react.createElement(ApprovalTimelinePanel, props))))
            // 标题席位：不加这一段时 chip 只有文字，跟别的插件（文件/上下文）不一致
            own(raw.slots.inject('sidebar.right.pane.tab.title', () => raw.slots.register({
              name: 'sidebar.right.pane.tab.title',
              key: SIDEBAR_ID,
            }, () => react.createElement(TimelineTabTitle))))
            beacon('sidebar-registered')
          } catch (error) {
            beacon('sidebar-error', String(error?.message ?? error))
            console.warn(LOG, '右侧栏 tab 注册失败', error)
            for (const dispose of disposers) dispose()
            return undefined
          }
          return () => {
            for (const dispose of disposers) dispose()
          }
        })
      }
      const unmount = () => {
        for (const name of ['tab', 'sidebar']) {
          const handle = mounted[name]
          mounted[name] = undefined
          if (handle === undefined) continue
          if (typeof handle === 'function') handle()
          else if (typeof handle.dispose === 'function') handle.dispose()
        }
      }

      /** 决定当前生效的放置方式；auto 优先右侧栏座位，没有座位时退回对话标签页。 */
      const effective = placement => placement === 'auto'
        ? (ctx.get('sidebarRightTabs') === undefined ? 'tab' : 'sidebar')
        : placement
      const remount = () => {
        const placement = effective(placementStore.value)
        if (placement === lastKey) return
        lastKey = placement
        unmount()
        if (placement === 'tab' || placement === 'all') mountTab()
        if (placement === 'sidebar' || placement === 'all') mountSidebar()
      }

      const unsubscribe = placementStore.subscribe(remount)
      remount()
      beacon('mounted', 'placement=' + placementStore.value + ' tab=' + String(mounted.tab !== undefined)
        + ' sidebar=' + String(mounted.sidebar !== undefined)
        + ' hasSidebarSeat=' + String(ctx.get('sidebarRightTabs') !== undefined))
      void runtimeStore.load().then(remount)
      void policyStore.load(undefined)
      // 审批观察器：当前会话一出现新审批、且时间线没打开，就自动展开它。它与面板无关
      // （用户停在「轨迹」标签页、或 placement 只挂右侧栏时同样要能触发），所以挂在插件入口；
      // 放在 remount() 之后启动，右侧栏 tab 才已经注册、页面一加载就能取到「历史记录」基线。
      if (approvalWatch.timer !== undefined) clearInterval(approvalWatch.timer)
      approvalWatch.timer = setInterval(() => { void watchApprovals() }, POLL_MS)
      void watchApprovals()

      ctx.effect(() => slots.inject('settings.plugin.item', () => {
        try {
          const dispose = slots.register({
            name: 'settings.plugin.item',
            key: 'dsh-auto-pass',
            id: 'dsh-auto-pass',
          }, () => react.createElement(SettingsCard, { tag: 'li', desc: t.panelCardDesc }))
          beacon('settings-registered')
          return dispose
        } catch (error) {
          beacon('settings-error', String(error?.message ?? error))
          throw error
        }
      }), 'dsh-auto-pass: placement settings card')

      ctx.effect(() => () => {
        unsubscribe()
        unmount()
        // 观察器随插件一起停：插件被卸载后不该再有后台轮询
        if (approvalWatch.timer !== undefined) {
          clearInterval(approvalWatch.timer)
          approvalWatch.timer = undefined
        }
      }, 'dsh-auto-pass: panel mounts')
      console.log(LOG, 'client loaded, placement=' + placementStore.value)
    }

    // remote 由 @deepseek-ai/dsh-api-remotes 提供（包级 dsh.client.inject 里已列为依赖），
    // 面板的模型候选走它（remote.session.modelCatalog）；官方设置页插件也是这么声明的。
    exports.inject = ['slots', 'remote']
    exports.apply = apply
    return module.exports
  },
})
